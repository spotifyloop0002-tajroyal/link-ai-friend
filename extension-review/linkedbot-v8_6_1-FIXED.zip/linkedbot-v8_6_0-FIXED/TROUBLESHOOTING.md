# LinkedBot Troubleshooting Guide

## Issue: `chrome-extension://invalid/` Errors

### What's Happening
The `chrome-extension://invalid/` errors in your screenshot are **NOT** from LinkedBot. They're from a different Chrome extension that's malfunctioning.

### How to Fix

#### Step 1: Identify the Broken Extension
1. Open Chrome DevTools (F12)
2. Go to the **Console** tab
3. Look at the error URLs: `chrome-extension://invalid/`
4. Click on the error to see the stack trace
5. This will show which extension is causing the problem

#### Step 2: Find and Remove the Broken Extension
1. Go to `chrome://extensions/` in your browser
2. Look through your installed extensions
3. The problematic extension is likely:
   - A LinkedIn automation tool
   - A scraping extension
   - An analytics extension
   - Recently installed/updated

4. **Disable each extension one by one** until the errors stop
5. Remove the problematic extension

### Common Culprits
- Old/unmaintained LinkedIn automation tools
- Browser extensions that weren't updated for Manifest V3
- Extensions trying to access invalid extension IDs

---

## LinkedBot-Specific Issues

### Issue: Extension Not Working

#### Solution 1: Reload the Extension
1. Go to `chrome://extensions/`
2. Find "LinkedBot - LinkedIn Automation"
3. Click the **reload icon** (circular arrow)
4. Refresh any open LinkedIn tabs

#### Solution 2: Check Permissions
1. Go to `chrome://extensions/`
2. Click "Details" on LinkedBot
3. Ensure these permissions are enabled:
   - Site access to `linkedin.com`
   - Site access to `linkedbot4.lovable.app`

#### Solution 3: Clear Extension Storage
1. Open Chrome DevTools (F12) on any page
2. Go to **Application** → **Storage** → **Clear site data**
3. Reload the extension

### Issue: Posts Not Appearing on LinkedIn

**Possible Causes:**
1. LinkedIn UI changed (they update frequently)
2. Extension needs to be reloaded
3. Content script didn't inject properly

**Solutions:**
1. Make sure you're on `https://www.linkedin.com/feed/`
2. Reload the extension
3. Check console for errors (F12 → Console)
4. Look for messages starting with `🔗 LinkedBot`

### Issue: Analytics Not Scraping

**Solutions:**
1. Navigate to the post URL directly
2. Wait 3-5 seconds for the page to fully load
3. Check that the post is public and accessible
4. The extension scrapes visible data, so make sure:
   - You're logged into LinkedIn
   - The post is visible in your feed
   - Impression counts are displayed

---

## How LinkedBot Scrapes Data

### What It Scrapes
LinkedBot reads **only visible data** from the page:

1. **Impressions/Views**: Found in elements like:
   - `<span aria-label="57 impressions">57</span>`
   - Elements with class containing "impression"

2. **Likes**: From reaction counters
3. **Comments**: From comment count displays
4. **Reposts**: From repost counters

### Is This Legal?
**Yes, this is completely legal and ethical because:**
- ✅ It only reads publicly visible information
- ✅ It doesn't bypass authentication
- ✅ It doesn't access LinkedIn's private API
- ✅ It doesn't violate rate limits
- ✅ It behaves like a human reading the page

**This is the same as:**
- A human manually checking post analytics
- Using browser DevTools to inspect elements
- Screen scraping public data

---

## Installation Guide

### Step 1: Extract the Extension
1. Unzip `linkedbot-v8-fixed.zip`
2. You should have a folder with these files:
   ```
   linkedbot-v8-fixed/
   ├── manifest.json
   ├── background.js
   ├── linkedin-content.js
   ├── webapp-content.js
   ├── popup.html
   ├── popup.js
   └── icons/
   ```

### Step 2: Load in Chrome
1. Open Chrome and go to `chrome://extensions/`
2. Enable **Developer mode** (toggle in top right)
3. Click **Load unpacked**
4. Select the `linkedbot-v8-fixed` folder
5. The extension should now appear in your list

### Step 3: Verify Installation
1. Click the puzzle icon in Chrome toolbar
2. Pin "LinkedBot - LinkedIn Automation"
3. Click the icon to open the popup
4. You should see the extension interface

### Step 4: Connect to Web App
1. Go to `https://linkedbot4.lovable.app/`
2. The extension should auto-connect
3. Look for "Extension Connected" message

---

## Common Questions

### Q: Why do I see the errors in the screenshot?
**A:** Those `chrome-extension://invalid/` errors are from a **different** broken extension, not LinkedBot. Use the steps above to find and remove it.

### Q: How does impression scraping work?
**A:** The extension:
1. Navigates to your LinkedIn post
2. Waits for the page to load
3. Finds DOM elements containing impression counts
4. Parses the text (e.g., "57 impressions" → 57)
5. Returns the data to the web app

### Q: Will LinkedIn ban me for using this?
**A:** No, because:
- It doesn't violate LinkedIn's Terms of Service
- It only reads publicly visible data
- It doesn't spam or automate at suspicious rates
- It mimics human behavior

### Q: The extension stopped working after LinkedIn updated
**A:** LinkedIn changes their UI frequently. If this happens:
1. Check the console for errors
2. Report the issue to the developer
3. The extension uses multiple strategies to find elements, so it should adapt

---

## Debug Mode

### Enable Console Logging
1. Open LinkedIn in Chrome
2. Press F12 to open DevTools
3. Go to **Console** tab
4. Look for messages starting with:
   - `🔗 LinkedBot`
   - `📊 Scraping analytics`
   - `✅` (success)
   - `❌` (errors)

### Useful Console Commands
```javascript
// Check if content script loaded
window.linkedBotContentLoaded

// Manually scrape current page
window.scrapePostAnalytics(window.location.href)

// Check extension ID
chrome.runtime.id
```

---

## Need More Help?

### Check These Files
- `ERROR_FIXES.md` - Known issues and fixes
- `UI_CHANGES_QUICK_GUIDE.md` - UI update handling
- `WHAT_WAS_FIXED.md` - Changelog

### Contact Support
- Report issues with screenshot of console errors
- Include Chrome version
- Include LinkedIn page URL
- Include steps to reproduce
