// ============================================================================
// LINKEDBOT BACKGROUND v5.0 - WITH ANALYTICS SCRAPING
// ============================================================================
// Features:
// 1. Post scheduling and immediate posting
// 2. Post URL capture
// 3. Analytics scraping (views, likes, comments, reposts)
// ============================================================================

console.log('🚀 LinkedBot v5.0 Background Service Worker Started');

// ============================================================================
// INITIALIZATION
// ============================================================================

chrome.runtime.onInstalled.addListener(async () => {
  console.log('✅ LinkedBot v5.0 installed');
  
  await chrome.storage.local.set({ 
    extensionId: chrome.runtime.id,
    isConnected: false
  });
  
  // Create persistent heartbeat
  await chrome.alarms.create('heartbeat', { 
    periodInMinutes: 1 
  });
  
  console.log('✅ Extension ready - ID:', chrome.runtime.id);
});

// ============================================================================
// MESSAGE HANDLER
// ============================================================================

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('📨 Message received:', request.action);
  
  // Wake up ping
  if (request.action === 'wakeUp') {
    sendResponse({ success: true, awake: true });
    return true;
  }
  
  // Get extension ID
  if (request.action === 'getExtensionId') {
    sendResponse({ 
      success: true, 
      extensionId: chrome.runtime.id 
    });
    return true;
  }
  
  // Set connected status
  if (request.action === 'setConnected') {
    chrome.storage.local.set({ isConnected: true })
      .then(() => sendResponse({ success: true }));
    return true;
  }
  
  // Set disconnected status
  if (request.action === 'setDisconnected') {
    chrome.storage.local.set({ isConnected: false })
      .then(() => sendResponse({ success: true }));
    return true;
  }
  
  // Get status
  if (request.action === 'getStatus') {
    chrome.storage.local.get(['isConnected'])
      .then((data) => {
        sendResponse({
          connected: data.isConnected || false,
          extensionId: chrome.runtime.id
        });
      });
    return true;
  }
  
  // Schedule posts
  if (request.action === 'schedulePosts') {
    handleSchedulePosts(request.posts)
      .then(result => sendResponse(result))
      .catch(error => sendResponse({ 
        success: false, 
        error: error.message 
      }));
    return true;
  }
  
  // Post immediately
  if (request.action === 'postNow') {
    handlePostNow(request.post)
      .then(result => sendResponse(result))
      .catch(error => sendResponse({ 
        success: false, 
        error: error.message 
      }));
    return true;
  }
  
  // Scrape analytics for single post
  if (request.action === 'scrapeAnalytics') {
    handleScrapeAnalytics(request.postUrl)
      .then(result => sendResponse(result))
      .catch(error => sendResponse({ 
        success: false, 
        error: error.message 
      }));
    return true;
  }
  
  // Scrape analytics for multiple posts
  if (request.action === 'scrapeBulkAnalytics') {
    handleScrapeBulkAnalytics(request.postUrls)
      .then(result => sendResponse(result))
      .catch(error => sendResponse({ 
        success: false, 
        error: error.message 
      }));
    return true;
  }
  
  // LinkedIn UI detected
  if (request.action === 'linkedinUIDetected') {
    console.log('🎨 LinkedIn UI detected:', request.version);
    chrome.storage.local.set({ 
      lastKnownLinkedInUI: request.version,
      lastUICheck: request.timestamp 
    });
    return true;
  }
  
  // LinkedIn UI changed - CRITICAL ALERT
  if (request.action === 'linkedinUIChanged') {
    console.error('🚨 LINKEDIN UI CHANGED!');
    console.error('Old UI:', request.oldVersion);
    console.error('New UI:', request.newVersion);
    console.error('Error:', request.error);
    
    // Store alert
    chrome.storage.local.set({
      linkedinUIAlert: {
        detected: request.timestamp,
        oldVersion: request.oldVersion,
        newVersion: request.newVersion,
        error: request.error,
        severity: 'critical'
      }
    });
    
    // Notify all webapp tabs
    notifyWebapp('linkedinUIChanged', {
      oldVersion: request.oldVersion,
      newVersion: request.newVersion,
      error: request.error,
      requiresUpdate: true,
      severity: 'critical'
    });
    
    return true;
  }
  
  // =========================================================================
  // LINKEDIN ACCOUNT VERIFICATION
  // =========================================================================
  
  // Verify LinkedIn account
  if (request.action === 'verifyLinkedInAccount') {
    handleVerifyLinkedInAccount(request.expectedLinkedInId)
      .then(result => sendResponse(result))
      .catch(error => sendResponse({
        success: false,
        error: error.message
      }));
    return true;
  }
  
  // Get current LinkedIn account (for checking)
  if (request.action === 'getCurrentLinkedInAccount') {
    handleGetCurrentLinkedInAccount()
      .then(result => sendResponse(result))
      .catch(error => sendResponse({
        success: false,
        error: error.message
      }));
    return true;
  }
  
  return true;
});

// ============================================================================
// ALARM HANDLER - Fires scheduled posts
// ============================================================================

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === 'heartbeat') {
    // Silent heartbeat to keep service worker alive
    return;
  }
  
  if (alarm.name.startsWith('post_')) {
    const postId = alarm.name.replace('post_', '');
    console.log(`⏰ Scheduled post firing: ${postId}`);
    
    const result = await chrome.storage.local.get('post_queue');
    const queue = result.post_queue || [];
    
    const postIndex = queue.findIndex(p => p.id === postId);
    if (postIndex === -1) {
      console.error('❌ Post not found in queue:', postId);
      return;
    }
    
    const post = queue[postIndex];
    
    // Post to LinkedIn
    try {
      const postResult = await postToLinkedIn(post);
      
      // Remove from queue
      queue.splice(postIndex, 1);
      await chrome.storage.local.set({ post_queue: queue });
      
      console.log('✅ Scheduled post completed:', postId);
      console.log('🔗 Scheduled post URL:', postResult.postUrl || 'not captured');
      
      // Notify webapp — include the LinkedIn URL
      notifyWebapp('postCompleted', { 
        postId: post.id,
        success: true,
        linkedinUrl: postResult.postUrl || null,
        postUrl: postResult.postUrl || null
      });
    } catch (error) {
      console.error('❌ Scheduled post failed:', error);
      
      // Update status but keep in queue
      post.status = 'failed';
      post.error = error.message;
      await chrome.storage.local.set({ post_queue: queue });
      
      // Notify webapp
      notifyWebapp('postFailed', { 
        postId: post.id,
        error: error.message 
      });
    }
  }
});

// ============================================================================
// SCHEDULE POSTS
// ============================================================================

async function handleSchedulePosts(posts) {
  console.log(`📅 Scheduling ${posts.length} posts`);
  
  // Send immediate acknowledgment to website
  notifyWebapp('postsReceived', {
    count: posts.length,
    postIds: posts.map(p => p.id),
    timestamp: new Date().toISOString(),
    message: `Extension received ${posts.length} post(s)`
  });
  
  if (!posts || posts.length === 0) {
    return { 
      success: false, 
      error: 'No posts provided' 
    };
  }
  
  const result = await chrome.storage.local.get('post_queue');
  const existingQueue = result.post_queue || [];
  
  const scheduledPosts = [];
  
  for (const post of posts) {
    // Accept either scheduleTime or scheduled_for
    const scheduleTime = post.scheduleTime || post.scheduled_for;
    
    if (!scheduleTime) {
      console.warn('⚠️ Post missing schedule time, skipping:', post.id);
      continue;
    }
    
    const scheduledDate = new Date(scheduleTime);
    
    if (isNaN(scheduledDate.getTime())) {
      console.error('❌ Invalid date for post:', post.id, scheduleTime);
      continue;
    }
    
    const queuedPost = {
      id: post.id,
      content: post.content,
      imageUrl: post.photo_url || post.imageUrl,
      scheduledTime: scheduledDate.toISOString(),
      status: 'scheduled'
    };
    
    scheduledPosts.push(queuedPost);
    
    // Create alarm
    const alarmName = `post_${post.id}`;
    await chrome.alarms.create(alarmName, { 
      when: scheduledDate.getTime() 
    });
    
    console.log(`✅ Scheduled post ${post.id} for ${scheduledDate.toLocaleString()}`);
  }
  
  const updatedQueue = [...existingQueue, ...scheduledPosts];
  await chrome.storage.local.set({ post_queue: updatedQueue });
  
  const nextPost = updatedQueue
    .sort((a, b) => new Date(a.scheduledTime) - new Date(b.scheduledTime))[0];
  
  console.log('═══════════════════════════════════════');
  console.log('✅ SCHEDULING COMPLETE');
  console.log('Posts scheduled:', scheduledPosts.length);
  console.log('Total in queue:', updatedQueue.length);
  console.log('Next post:', nextPost ? nextPost.scheduledTime : 'none');
  console.log('═══════════════════════════════════════');
  
  return {
    success: true,
    queueLength: updatedQueue.length,
    nextScheduled: nextPost ? nextPost.scheduledTime : null,
    message: `${scheduledPosts.length} posts scheduled`
  };
}

// ============================================================================
// POST NOW
// ============================================================================

async function handlePostNow(post) {
  console.log('📤 Posting immediately:', post.id);
  
  if (!post || !post.content) {
    return { 
      success: false, 
      error: 'Invalid post data' 
    };
  }
  
  try {
    const result = await postToLinkedIn(post);
    
    console.log('✅ Post completed:', post.id);
    console.log('🔗 Post URL:', result.postUrl || 'not captured');
    
    return {
      success: true,
      postId: post.id,
      linkedinUrl: result.postUrl || null,
      postUrl: result.postUrl || null,
      message: 'Posted successfully'
    };
  } catch (error) {
    console.error('❌ Post failed:', error);
    return {
      success: false,
      error: error.message
    };
  }
}

// ============================================================================
// SCRAPE ANALYTICS
// ============================================================================

async function handleScrapeAnalytics(postUrl) {
  console.log('📊 Scraping analytics for:', postUrl);
  
  if (!postUrl) {
    return {
      success: false,
      error: 'Post URL is required'
    };
  }
  
  try {
    // Find or create LinkedIn tab
    let linkedinTab = await findLinkedInTab();
    
    if (!linkedinTab) {
      console.log('🔗 Opening LinkedIn...');
      linkedinTab = await chrome.tabs.create({
        url: postUrl,
        active: false // Don't steal focus
      });
      await waitForTabLoad(linkedinTab.id);
      await sleep(3000);
    } else {
      console.log('✅ Using existing LinkedIn tab');
      await chrome.tabs.update(linkedinTab.id, { url: postUrl });
      await sleep(3000);
    }
    
    // Ensure content script is loaded
    await ensureContentScriptLoaded(linkedinTab.id);
    
    // Send scrape request to LinkedIn content script
    const result = await sendMessageToTab(linkedinTab.id, {
      action: 'scrapeAnalytics',
      postUrl: postUrl
    });
    
    if (!result || !result.success) {
      throw new Error(result?.error || 'Failed to scrape analytics');
    }
    
    console.log('✅ Analytics scraped:', result.analytics);
    
    return {
      success: true,
      analytics: result.analytics
    };
    
  } catch (error) {
    console.error('❌ Analytics scraping failed:', error);
    return {
      success: false,
      error: error.message
    };
  }
}

// ============================================================================
// SCRAPE BULK ANALYTICS
// ============================================================================

async function handleScrapeBulkAnalytics(postUrls) {
  console.log(`📊 Scraping analytics for ${postUrls.length} posts sequentially`);
  
  if (!postUrls || postUrls.length === 0) {
    return {
      success: false,
      error: 'No post URLs provided'
    };
  }
  
  try {
    // Find or create LinkedIn tab
    let linkedinTab = await findLinkedInTab();
    
    if (!linkedinTab) {
      console.log('🔗 Opening LinkedIn...');
      linkedinTab = await chrome.tabs.create({
        url: 'https://www.linkedin.com/feed/',
        active: false
      });
      await waitForTabLoad(linkedinTab.id);
      await sleep(3000);
    }
    
    // Ensure content script is loaded
    await ensureContentScriptLoaded(linkedinTab.id);
    
    // Scrape ONE at a time
    const results = [];
    
    for (let i = 0; i < postUrls.length; i++) {
      const postUrl = postUrls[i];
      console.log(`📍 Scraping post ${i + 1}/${postUrls.length}: ${postUrl}`);
      
      // Notify webapp about progress
      notifyWebapp('scrapingProgress', {
        current: i + 1,
        total: postUrls.length,
        url: postUrl,
        status: 'scraping'
      });
      
      try {
        // Scrape this post
        const result = await sendMessageToTab(linkedinTab.id, {
          action: 'scrapeAnalytics',
          postUrl: postUrl
        }, 30000);
        
        if (result && result.success) {
          console.log(`✅ Post ${i + 1} scraped successfully`);
          results.push({
            url: postUrl,
            success: true,
            analytics: result.analytics
          });
          
          // Notify webapp about successful scrape
          notifyWebapp('scrapingProgress', {
            current: i + 1,
            total: postUrls.length,
            url: postUrl,
            status: 'completed',
            analytics: result.analytics
          });
        } else {
          console.error(`❌ Post ${i + 1} scraping failed:`, result?.error);
          results.push({
            url: postUrl,
            success: false,
            error: result?.error || 'Unknown error'
          });
          
          // Notify webapp about failed scrape
          notifyWebapp('scrapingProgress', {
            current: i + 1,
            total: postUrls.length,
            url: postUrl,
            status: 'failed',
            error: result?.error
          });
        }
      } catch (error) {
        console.error(`❌ Error scraping post ${i + 1}:`, error);
        results.push({
          url: postUrl,
          success: false,
          error: error.message
        });
        
        notifyWebapp('scrapingProgress', {
          current: i + 1,
          total: postUrls.length,
          url: postUrl,
          status: 'failed',
          error: error.message
        });
      }
      
      // Wait 3 seconds between posts to avoid rate limiting
      if (i < postUrls.length - 1) {
        console.log('⏳ Waiting 3 seconds before next post...');
        await sleep(3000);
      }
    }
    
    const successful = results.filter(r => r.success).length;
    
    console.log(`✅ Bulk scraping complete: ${successful}/${postUrls.length} successful`);
    
    // Final completion notification
    notifyWebapp('scrapingComplete', {
      total: postUrls.length,
      successful: successful,
      failed: postUrls.length - successful
    });
    
    return {
      success: true,
      results: results,
      total: postUrls.length,
      successful: successful
    };
    
  } catch (error) {
    console.error('❌ Bulk analytics scraping failed:', error);
    return {
      success: false,
      error: error.message
    };
  }
}

// ============================================================================
// LINKEDIN ACCOUNT VERIFICATION HANDLERS
// ============================================================================

/**
 * Verify LinkedIn account matches expected account
 * Now opens the profile page to ensure accurate detection
 */
async function handleVerifyLinkedInAccount(expectedLinkedInId) {
  console.log('🔐 Verifying LinkedIn account...');
  console.log('Expected:', expectedLinkedInId);
  
  try {
    // Step 1: Find or create LinkedIn tab
    let linkedinTab = await findLinkedInTab();
    
    if (!linkedinTab) {
      console.log('🔗 No LinkedIn tab found - opening profile...');
      linkedinTab = await chrome.tabs.create({
        url: `https://www.linkedin.com/in/${expectedLinkedInId}/`,
        active: true
      });
      await waitForTabLoad(linkedinTab.id);
      await sleep(3000); // Wait for profile to load
    } else {
      // Navigate to the profile page for accurate detection
      console.log('🔄 Navigating to profile page for verification...');
      await chrome.tabs.update(linkedinTab.id, { 
        url: `https://www.linkedin.com/in/${expectedLinkedInId}/`,
        active: true 
      });
      await waitForTabLoad(linkedinTab.id);
      await sleep(3000); // Wait for profile to load
    }
    
    // Ensure verification script is loaded
    await ensureVerificationScriptLoaded(linkedinTab.id);
    
    // Get current LinkedIn account from the page
    const result = await sendMessageToTab(linkedinTab.id, {
      action: 'getLinkedInAccount'
    }, 10000);
    
    if (!result || !result.success) {
      return {
        success: false,
        error: 'DETECTION_FAILED',
        message: result?.error || 'Failed to detect LinkedIn account. Please make sure you are logged in.'
      };
    }
    
    const currentLinkedInId = result.linkedinId;
    
    if (!currentLinkedInId) {
      return {
        success: false,
        error: 'NOT_LOGGED_IN',
        message: 'You are not logged into LinkedIn. Please log in first.'
      };
    }
    
    console.log('Found LinkedIn account:', currentLinkedInId);
    
    // Compare with expected
    if (currentLinkedInId !== expectedLinkedInId) {
      return {
        success: false,
        error: 'ACCOUNT_MISMATCH',
        message: `LinkedIn account mismatch! You are logged in as "${currentLinkedInId}" but you need to be logged in as "${expectedLinkedInId}". Please log out and log in with the correct account.`,
        currentLinkedInId: currentLinkedInId,
        expectedLinkedInId: expectedLinkedInId
      };
    }
    
    // Store verified account
    await chrome.storage.local.set({
      verifiedLinkedInId: currentLinkedInId,
      verificationTimestamp: Date.now()
    });
    
    console.log('✅ LinkedIn account verified!');
    
    return {
      success: true,
      linkedinId: currentLinkedInId,
      message: 'LinkedIn account verified successfully!'
    };
    
  } catch (error) {
    console.error('❌ Verification failed:', error);
    return {
      success: false,
      error: 'VERIFICATION_ERROR',
      message: error.message
    };
  }
}

/**
 * Get current LinkedIn account (without verification)
 */
async function handleGetCurrentLinkedInAccount() {
  console.log('🔍 Getting current LinkedIn account...');
  
  try {
    // Find any LinkedIn tab
    let linkedinTab = await findLinkedInTab();
    
    if (!linkedinTab) {
      return {
        success: false,
        error: 'LINKEDIN_NOT_OPEN',
        message: 'LinkedIn is not open in this browser.'
      };
    }
    
    // Ensure verification script is loaded
    await ensureVerificationScriptLoaded(linkedinTab.id);
    
    // Get current LinkedIn account
    const result = await sendMessageToTab(linkedinTab.id, {
      action: 'getLinkedInAccount'
    }, 10000);
    
    if (!result || !result.success) {
      return {
        success: false,
        error: 'DETECTION_FAILED',
        message: result?.error || 'Failed to detect LinkedIn account'
      };
    }
    
    return {
      success: true,
      linkedinId: result.linkedinId,
      isLoggedIn: !!result.linkedinId
    };
    
  } catch (error) {
    console.error('❌ Failed to get LinkedIn account:', error);
    return {
      success: false,
      error: 'ERROR',
      message: error.message
    };
  }
}

/**
 * Ensure verification script is loaded in LinkedIn tab
 */
async function ensureVerificationScriptLoaded(tabId) {
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId },
      func: () => window.linkedBotVerificationLoaded || false
    });
    
    const isLoaded = results && results[0] && results[0].result === true;
    
    if (!isLoaded) {
      console.log('📌 Verification script not loaded — injecting...');
      await chrome.scripting.executeScript({
        target: { tabId },
        files: ['linkedin-verification.js']
      });
      await sleep(500);
    }
  } catch (error) {
    console.log('📌 Verification script check failed — injecting...');
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ['linkedin-verification.js']
    });
    await sleep(500);
  }
}

// ============================================================================
// POST TO LINKEDIN
// ============================================================================

async function postToLinkedIn(post) {
  console.log('📝 Creating LinkedIn post...');
  
  // =========================================================================
  // STEP 1: VERIFY LINKEDIN ACCOUNT BEFORE POSTING (IMPROVED)
  // =========================================================================
  
  console.log('🔐 Checking LinkedIn account verification...');
  
  // Get verified account from storage
  const verifiedData = await chrome.storage.local.get(['verifiedLinkedInId']);
  const verifiedLinkedInId = verifiedData.verifiedLinkedInId;
  
  if (!verifiedLinkedInId) {
    console.warn('⚠️ LinkedIn account not verified - proceeding anyway');
    console.warn('⚠️ For best results, verify your account on the website');
    // Don't throw error - just warn and continue
  } else {
    console.log('📋 Expected LinkedIn account:', verifiedLinkedInId);
  }
  
  // =========================================================================
  // STEP 2: OPEN OR FIND LINKEDIN TAB (DO THIS FIRST)
  // =========================================================================
  
  // MUST be on /feed/ — "Start a post" button only exists there
  let linkedinTab = await findLinkedInFeedTab();
  
  if (!linkedinTab) {
    // No /feed/ tab — check if there's any LinkedIn tab we can navigate
    linkedinTab = await findLinkedInTab();
    
    if (linkedinTab) {
      console.log('🔄 LinkedIn tab found but not on /feed/ — navigating to feed...');
      await chrome.tabs.update(linkedinTab.id, { url: 'https://www.linkedin.com/feed/', active: true });
      await waitForTabLoad(linkedinTab.id);
      await sleep(3000);
    } else {
      console.log('🔗 No LinkedIn tab at all — opening /feed/...');
      linkedinTab = await chrome.tabs.create({
        url: 'https://www.linkedin.com/feed/',
        active: true
      });
      await waitForTabLoad(linkedinTab.id);
      await sleep(5000); // Wait longer for fresh tab
    }
  } else {
    console.log('✅ Using existing LinkedIn /feed/ tab');
    await chrome.tabs.update(linkedinTab.id, { active: true });
    await sleep(1000);
  }
  
  // =========================================================================
  // STEP 3: NOW VERIFY ACCOUNT (AFTER TAB IS READY)
  // =========================================================================
  
  try {
    // Ensure verification script is loaded
    await ensureVerificationScriptLoaded(linkedinTab.id);
    
    // Get current logged-in account
    const accountCheck = await sendMessageToTab(linkedinTab.id, {
      action: 'getLinkedInAccount'
    }, 10000);
    
    if (accountCheck && accountCheck.success && accountCheck.linkedinId) {
      const currentLinkedInId = accountCheck.linkedinId;
      console.log('📋 Current LinkedIn account:', currentLinkedInId);
      
      // Only compare if we have a verified account
      if (verifiedLinkedInId) {
        // Compare accounts - WARNING instead of ERROR
        if (currentLinkedInId !== verifiedLinkedInId) {
          console.warn(`⚠️ Account mismatch! Current: "${currentLinkedInId}", Expected: "${verifiedLinkedInId}"`);
          console.warn('⚠️ Proceeding anyway - user may have multiple accounts');
          // Don't throw error - just warn
        } else {
          console.log('✅ LinkedIn account verified:', currentLinkedInId);
        }
      } else {
        console.log('✅ LinkedIn account detected:', currentLinkedInId);
        console.log('ℹ️ No verified account on file - skipping verification');
      }
    } else {
      console.warn('⚠️ Could not detect LinkedIn account - proceeding anyway');
    }
  } catch (verifyError) {
    console.warn('⚠️ Verification check failed:', verifyError.message);
    console.warn('⚠️ Proceeding with post anyway...');
  }
  
  // =========================================================================
  // STEP 4: PROCEED WITH POSTING
  // =========================================================================
  
  // Ensure content script is loaded on THIS tab
  await ensureContentScriptLoaded(linkedinTab.id);
  
  // Send post content to LinkedIn content script
  const result = await sendMessageToTab(linkedinTab.id, {
    action: 'fillPost',
    content: post.content,
    imageUrl: post.imageUrl,
    autoPost: true
  });
  
  if (!result || !result.success) {
    throw new Error(result?.error || 'Failed to create post on LinkedIn');
  }
  
  console.log('✅ Post created on LinkedIn');
  
  return {
    success: true,
    postId: post.id,
    postUrl: result.postUrl || result.linkedinUrl || null
  };
}

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

// Returns a LinkedIn tab that is already on /feed/. null if none.
async function findLinkedInFeedTab() {
  const tabs = await chrome.tabs.query({});
  return tabs.find(tab => 
    tab.url && tab.url.includes('linkedin.com') && tab.url.includes('/feed')
  ) || null;
}

// Returns ANY LinkedIn tab (for scraping — doesn't need /feed/).
async function findLinkedInTab() {
  const tabs = await chrome.tabs.query({});
  return tabs.find(tab => 
    tab.url && tab.url.includes('linkedin.com')
  ) || null;
}

async function waitForTabLoad(tabId) {
  return new Promise((resolve) => {
    const listener = (changedTabId, changeInfo) => {
      if (changedTabId === tabId && changeInfo.status === 'complete') {
        chrome.tabs.onUpdated.removeListener(listener);
        resolve();
      }
    };
    chrome.tabs.onUpdated.addListener(listener);
  });
}

async function ensureContentScriptLoaded(tabId) {
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId },
      func: () => window.linkedBotContentLoaded || false
    });
    
    // results = [{ result: true }] or [{ result: false }] — actually check it
    const isLoaded = results && results[0] && results[0].result === true;
    
    if (!isLoaded) {
      console.log('📌 Content script not loaded — injecting...');
      await chrome.scripting.executeScript({
        target: { tabId },
        files: ['linkedin-content.js']
      });
      await sleep(500);
    }
  } catch (error) {
    console.log('📌 Content script check failed — injecting...');
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ['linkedin-content.js']
    });
    await sleep(500);
  }
}

async function sendMessageToTab(tabId, message, timeoutMs = 30000) {
  return new Promise((resolve, reject) => {
    let responded = false;
    
    // Set timeout
    const timeout = setTimeout(() => {
      if (!responded) {
        responded = true;
        reject(new Error(`Message timeout after ${timeoutMs}ms`));
      }
    }, timeoutMs);
    
    chrome.tabs.sendMessage(tabId, message, (response) => {
      if (responded) return; // Already timed out
      
      responded = true;
      clearTimeout(timeout);
      
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else {
        resolve(response);
      }
    });
  });
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function notifyWebapp(event, data) {
  try {
    const tabs = await chrome.tabs.query({});
    const webappTabs = tabs.filter(tab => 
      tab.url && (
        tab.url.includes('linkedbot.online') ||
        tab.url.includes('linkedbot4.lovable.app') // Keep backward compatibility
      )
    );
    
    // Send POST_SUCCESS message when post is completed
    if (event === 'postCompleted' && data.success && data.postUrl) {
      for (const tab of webappTabs) {
        chrome.tabs.sendMessage(tab.id, {
          type: 'POST_SUCCESS',
          postId: data.postId,
          trackingId: data.postId,
          postUrl: data.postUrl,
          linkedinUrl: data.postUrl,
          timestamp: new Date().toISOString()
        }).catch(() => {
          // Tab might not have content script, ignore
        });
      }
      console.log('✅ POST_SUCCESS sent to webapp:', data.postUrl);
    }
    
    // Also send the original format for backward compatibility
    for (const tab of webappTabs) {
      chrome.tabs.sendMessage(tab.id, {
        action: 'extensionEvent',
        event: event,
        data: data
      }).catch(() => {
        // Tab might not have content script, ignore
      });
    }
  } catch (error) {
    console.log('Could not notify webapp:', error.message);
  }
}

console.log('✅ Background service worker ready with analytics scraping');