# 🔐 LINKEDIN VERIFICATION - QUICK REFERENCE

---

## 📨 MESSAGES YOU SEND (Website → Extension)

### 1. Verify LinkedIn Account
```javascript
window.postMessage({
  type: 'VERIFY_LINKEDIN_ACCOUNT',
  expectedLinkedInId: 'aryan-bhatnagar'  // User's registered LinkedIn ID
}, '*');
```

### 2. Get Current LinkedIn Account
```javascript
window.postMessage({
  type: 'GET_CURRENT_LINKEDIN_ACCOUNT'
}, '*');
```

---

## 📬 MESSAGES YOU RECEIVE (Extension → Website)

### 1. Verification Result
```javascript
window.addEventListener('message', (event) => {
  if (event.data.type === 'VERIFY_RESULT') {
    const { success, linkedinId, error, message, currentLinkedInId, expectedLinkedInId } = event.data;
    
    if (success) {
      // ✅ Verified!
      console.log('Verified:', linkedinId);
    } else {
      // ❌ Failed
      console.log('Error:', error);
      console.log('Message:', message);
    }
  }
});
```

### 2. Current Account Result
```javascript
window.addEventListener('message', (event) => {
  if (event.data.type === 'CURRENT_LINKEDIN_ACCOUNT') {
    const { success, linkedinId, isLoggedIn, error, message } = event.data;
    
    if (success && isLoggedIn) {
      console.log('Current account:', linkedinId);
    } else {
      console.log('Not logged in');
    }
  }
});
```

### 3. Post Result (with account check)
```javascript
window.addEventListener('message', (event) => {
  if (event.data.type === 'POST_RESULT') {
    const { success, postUrl, error } = event.data;
    
    if (!success && error.includes('Account mismatch')) {
      // User is on wrong LinkedIn account
      console.log('Account mismatch error!');
    }
  }
});
```

---

## 🚨 ERROR CODES

| Code | Meaning | Action |
|------|---------|--------|
| `LINKEDIN_NOT_OPEN` | LinkedIn.com is not open | Open linkedin.com |
| `NOT_LOGGED_IN` | Not logged into LinkedIn | Log in |
| `ACCOUNT_MISMATCH` | Wrong LinkedIn account | Switch accounts |
| `DETECTION_FAILED` | Can't detect account | Refresh & retry |

---

## ✅ TYPICAL FLOW

```javascript
// 1. During signup - extract LinkedIn ID
const url = "https://www.linkedin.com/in/aryan-bhatnagar/";
const linkedinId = url.match(/\/in\/([^\/\?]+)/)[1];
// Result: "aryan-bhatnagar"

// 2. Save to database
await saveUser({
  linkedin_public_id: linkedinId,
  linkedin_verified: false
});

// 3. Show "Verify" button
// User clicks it...

// 4. Send verification request
window.postMessage({
  type: 'VERIFY_LINKEDIN_ACCOUNT',
  expectedLinkedInId: linkedinId
}, '*');

// 5. Extension checks account and responds
// Listen for VERIFY_RESULT message

// 6. If verified successfully
await updateUser({
  linkedin_verified: true
});

// 7. Before every post
// Extension automatically checks account
// If mismatch → post blocked
```

---

## 🔒 SECURITY GUARANTEE

✅ User CANNOT:
- Post from a different LinkedIn account
- Post without verification
- Bypass the account check
- Switch accounts mid-session

✅ Extension WILL:
- Verify account before first post
- Check account before EVERY post
- Block posts if account doesn't match
- Send clear error messages

---

## 📋 WEBSITE CHECKLIST

- [ ] Extract LinkedIn ID during signup
- [ ] Save to database: `linkedin_public_id`
- [ ] Show "Verify LinkedIn" button
- [ ] Send `VERIFY_LINKEDIN_ACCOUNT` message
- [ ] Listen for `VERIFY_RESULT` message
- [ ] Handle success: Update database
- [ ] Handle errors: Show specific messages
- [ ] Test account mismatch scenario
- [ ] Test posting with verified account
- [ ] Test posting after account switch

---

## 🧪 TESTING

### Test Case 1: Normal Verification
1. User registers with LinkedIn URL
2. User clicks "Verify"
3. Extension checks account
4. ✅ Match → Success

### Test Case 2: LinkedIn Not Open
1. User clicks "Verify"
2. LinkedIn not open in browser
3. ❌ Error: "LinkedIn not open"
4. User opens LinkedIn
5. User retries → ✅ Success

### Test Case 3: Wrong Account
1. User registers as "john-doe"
2. User logged into LinkedIn as "jane-doe"
3. User clicks "Verify"
4. ❌ Error: "Account mismatch"
5. User switches to correct account
6. User retries → ✅ Success

### Test Case 4: Post Account Check
1. User verified as "john-doe"
2. User switches LinkedIn to "jane-doe"
3. User tries to post
4. ❌ Extension blocks: "Account mismatch"
5. User switches back to "john-doe"
6. User posts → ✅ Success

---

## 💻 MINIMAL CODE EXAMPLE

```javascript
// Extract LinkedIn ID
const linkedinId = linkedinUrl.match(/\/in\/([^\/\?]+)/)[1];

// Verify account
window.postMessage({
  type: 'VERIFY_LINKEDIN_ACCOUNT',
  expectedLinkedInId: linkedinId
}, '*');

// Listen for result
window.addEventListener('message', (event) => {
  if (event.data.type === 'VERIFY_RESULT') {
    if (event.data.success) {
      alert('✅ Verified!');
    } else {
      alert('❌ ' + event.data.message);
    }
  }
});
```

---

## 🎯 KEY POINTS

1. **Automatic**: Extension checks account before EVERY post
2. **Secure**: User cannot bypass or fake verification
3. **Clear errors**: Extension sends specific error codes
4. **Simple API**: Just 2 message types to send
5. **No backend needed**: Extension handles all verification

---

That's it! Your website now has secure LinkedIn account verification 🎉
