// ============================================================================
// LINKEDBOT POPUP v5.1 - IMPROVED QUEUE DISPLAY
// ============================================================================

document.addEventListener('DOMContentLoaded', async () => {
  console.log('Popup loaded');
  await loadPopupData();
});

async function loadPopupData() {
  try {
    // Get status from background
    const response = await chrome.runtime.sendMessage({ action: 'getStatus' });
    
    // Update connection status
    const statusDiv = document.getElementById('status');
    const statusText = document.getElementById('statusText');
    const extensionIdSpan = document.getElementById('extensionId');
    
    if (response.connected) {
      statusDiv.className = 'status connected';
      statusText.textContent = '✅ Connected to website';
    } else {
      statusDiv.className = 'status disconnected';
      statusText.textContent = '⚠️ Not connected to website';
    }
    
    extensionIdSpan.textContent = 'Extension ID: ' + (response.extensionId || 'Unknown');
    
    // Get queue info
    const storage = await chrome.storage.local.get('post_queue');
    const queue = storage.post_queue || [];
    
    // Update queue count
    document.getElementById('queueCount').textContent = queue.length;
    
    // Display all scheduled posts
    const queueList = document.getElementById('queueList');
    
    if (queue.length === 0) {
      queueList.innerHTML = '<div class="empty-state">No posts scheduled</div>';
      return;
    }
    
    // Sort by scheduled time (soonest first)
    const sortedQueue = queue.sort((a, b) => 
      new Date(a.scheduledTime) - new Date(b.scheduledTime)
    );
    
    // Display each post
    queueList.innerHTML = sortedQueue.map((post, index) => {
      const scheduledTime = new Date(post.scheduledTime);
      const now = new Date();
      const isOverdue = scheduledTime < now;
      
      // Calculate time until post
      const timeDiff = scheduledTime - now;
      const hoursUntil = Math.floor(timeDiff / (1000 * 60 * 60));
      const minutesUntil = Math.floor((timeDiff % (1000 * 60 * 60)) / (1000 * 60));
      
      let timeUntilText = '';
      if (isOverdue) {
        timeUntilText = '⚠️ Overdue';
      } else if (hoursUntil < 1) {
        timeUntilText = `⏱️ In ${minutesUntil} min`;
      } else if (hoursUntil < 24) {
        timeUntilText = `⏱️ In ${hoursUntil}h ${minutesUntil}m`;
      } else {
        const daysUntil = Math.floor(hoursUntil / 24);
        timeUntilText = `📅 In ${daysUntil} days`;
      }
      
      // Truncate content for display
      const contentPreview = post.content
        ? post.content.substring(0, 80) + (post.content.length > 80 ? '...' : '')
        : 'No content';
      
      return `
        <div class="post-item">
          <div class="post-time">
            ${index === 0 ? '🔜 ' : ''}${scheduledTime.toLocaleString('en-US', {
              month: 'short',
              day: 'numeric',
              hour: 'numeric',
              minute: '2-digit',
              hour12: true
            })}
          </div>
          <div class="post-content">${escapeHtml(contentPreview)}</div>
          <div class="post-status">${timeUntilText}</div>
        </div>
      `;
    }).join('');
    
  } catch (error) {
    console.error('Error loading popup:', error);
    document.getElementById('statusText').textContent = '❌ Error: ' + error.message;
  }
}

// Helper function to escape HTML
function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

// Auto-refresh every 10 seconds to keep queue updated
setInterval(() => {
  loadPopupData();
}, 10000);