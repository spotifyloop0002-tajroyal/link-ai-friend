// ============================================================================
// LINKEDBOT LINKEDIN CONTENT SCRIPT v8.0 - NO API VERSION
// ============================================================================
// Pure DOM-based solution - NO LinkedIn API required
// Better image upload handling
// ============================================================================

console.log('🔗 LinkedBot LinkedIn content script loaded v8.0 (DOM-Only)');

window.linkedBotContentLoaded = true;

// ============================================================================
// ADAPTIVE UI DETECTION SYSTEM
// ============================================================================

class LinkedInUIAdapter {
  
  /**
   * Find "Start a post" button using multiple strategies
   */
  static findStartPostButton() {
    const strategies = [
      // Strategy 1: Exact text match
      () => {
        for (const btn of document.querySelectorAll('button')) {
          const text = btn.textContent.trim().toLowerCase();
          if (text === 'start a post' || text === 'start posting') return btn;
        }
      },
      
      // Strategy 2: Partial text match
      () => {
        for (const btn of document.querySelectorAll('button')) {
          const text = btn.textContent.trim().toLowerCase();
          if (text.includes('start') && text.includes('post')) return btn;
        }
      },
      
      // Strategy 3: Known class patterns
      () => document.querySelector('.share-box-feed-entry__trigger'),
      
      // Strategy 4: Aria labels
      () => document.querySelector('button[aria-label*="Start a post"]'),
      
      // Strategy 5: Data attributes
      () => document.querySelector('[data-test-share-box] button'),
      
      // Strategy 6: Look for clickable area in share box
      () => {
        const shareBoxes = document.querySelectorAll('[class*="share"]');
        for (const box of shareBoxes) {
          const btn = box.querySelector('button');
          if (btn) return btn;
        }
      },
      
      // Strategy 7: Find by role and position (top of feed)
      () => {
        const buttons = document.querySelectorAll('button[type="button"]');
        for (const btn of buttons) {
          const rect = btn.getBoundingClientRect();
          if (rect.top < 400 && rect.top > 0) { 
            const text = btn.textContent.toLowerCase();
            if (text.includes('post') || text.includes('share')) return btn;
          }
        }
      }
    ];
    
    return this.tryStrategies(strategies);
  }
  
  /**
   * Find image upload button - IMPROVED VERSION
   */
  static findImageUploadButton() {
    const strategies = [
      // Strategy 1: Aria label with "media" or "photo"
      () => {
        const selectors = [
          'button[aria-label*="media" i]',
          'button[aria-label*="photo" i]',
          'button[aria-label*="image" i]',
          'button[aria-label*="Add a photo" i]'
        ];
        for (const sel of selectors) {
          const btn = document.querySelector(sel);
          if (btn && btn.offsetParent !== null) return btn;
        }
      },
      
      // Strategy 2: Look in modal toolbar
      () => {
        const modal = document.querySelector('[role="dialog"]');
        if (!modal) return null;
        
        const buttons = modal.querySelectorAll('button');
        for (const btn of buttons) {
          const label = (btn.getAttribute('aria-label') || '').toLowerCase();
          if (label.includes('media') || label.includes('photo') || label.includes('image')) {
            return btn;
          }
        }
      },
      
      // Strategy 3: SVG icon detection (camera/image icons)
      () => {
        const modal = document.querySelector('[role="dialog"]');
        if (!modal) return null;
        
        const buttons = modal.querySelectorAll('button');
        for (const btn of buttons) {
          const svg = btn.querySelector('svg');
          if (!svg) continue;
          
          // Check if button looks like image button
          const label = (btn.getAttribute('aria-label') || '').toLowerCase();
          const svgContent = svg.outerHTML.toLowerCase();
          
          if (label.includes('photo') || label.includes('media') || 
              svgContent.includes('image') || svgContent.includes('camera')) {
            return btn;
          }
        }
      },
      
      // Strategy 4: Find by class patterns
      () => {
        const classes = [
          '.share-creation-state__footer button',
          '.share-box-footer button',
          '[class*="media-button"]'
        ];
        for (const cls of classes) {
          const btn = document.querySelector(cls);
          if (btn) {
            const label = (btn.getAttribute('aria-label') || '').toLowerCase();
            if (label.includes('photo') || label.includes('media')) return btn;
          }
        }
      }
    ];
    
    return this.tryStrategies(strategies);
  }
  
  /**
   * Find file input - IMPROVED
   */
  static findFileInput() {
    const strategies = [
      // Strategy 1: Direct file input with image accept
      () => {
        const inputs = document.querySelectorAll('input[type="file"]');
        for (const input of inputs) {
          const accept = (input.getAttribute('accept') || '').toLowerCase();
          if (accept.includes('image')) return input;
        }
      },
      
      // Strategy 2: Any visible file input
      () => {
        const inputs = document.querySelectorAll('input[type="file"]');
        for (const input of inputs) {
          if (input.offsetParent !== null) return input;
        }
      },
      
      // Strategy 3: Hidden file input (trigger programmatically)
      () => {
        const inputs = document.querySelectorAll('input[type="file"]');
        return inputs[0]; // Return first one found
      }
    ];
    
    return this.tryStrategies(strategies);
  }
  
  /**
   * Find post button (handles both "Next" and "Post" buttons)
   */
  static findPostButton() {
    const strategies = [
      // Strategy 1: Exact text "Post"
      () => {
        const buttons = document.querySelectorAll('button');
        for (const btn of buttons) {
          if (btn.textContent.trim() === 'Post' && btn.offsetParent !== null) {
            return btn;
          }
        }
      },
      
      // Strategy 2: Button in modal footer
      () => {
        const modal = document.querySelector('[role="dialog"]');
        if (!modal) return null;
        
        const buttons = modal.querySelectorAll('button');
        for (const btn of buttons) {
          const text = btn.textContent.trim().toLowerCase();
          if (text === 'post' || text === 'publish') return btn;
        }
      },
      
      // Strategy 3: Primary action button
      () => {
        const buttons = document.querySelectorAll('button[data-test-modal-close-btn]');
        for (const btn of buttons) {
          const text = btn.textContent.trim().toLowerCase();
          if (text === 'post') return btn;
        }
      },
      
      // Strategy 4: ANY button with "Post" text in modal
      () => {
        const modal = document.querySelector('[role="dialog"]');
        if (!modal) return null;
        
        const allButtons = modal.querySelectorAll('button');
        for (const btn of allButtons) {
          if (btn.offsetParent !== null && btn.textContent.trim() === 'Post') {
            return btn;
          }
        }
      }
    ];
    
    return this.tryStrategies(strategies);
  }
  
  /**
   * Find "Next" button (appears after image upload in new UI)
   */
  static findNextButton() {
    const strategies = [
      // Strategy 1: Exact text "Next" in modal
      () => {
        const modal = document.querySelector('[role="dialog"]');
        if (!modal) return null;
        
        const buttons = modal.querySelectorAll('button');
        for (const btn of buttons) {
          const text = btn.textContent.trim();
          if (text === 'Next' && btn.offsetParent !== null) {
            return btn;
          }
        }
      },
      
      // Strategy 2: Any visible button with exact "Next" text
      () => {
        const buttons = document.querySelectorAll('button');
        for (const btn of buttons) {
          if (btn.textContent.trim() === 'Next' && btn.offsetParent !== null) {
            return btn;
          }
        }
      },
      
      // Strategy 3: Button with aria-label containing "Next"
      () => {
        const buttons = document.querySelectorAll('button[aria-label*="Next" i]');
        for (const btn of buttons) {
          if (btn.offsetParent !== null) return btn;
        }
      },
      
      // Strategy 4: Primary/submit button in modal footer containing "Next"
      () => {
        const modal = document.querySelector('[role="dialog"]');
        if (!modal) return null;
        
        const footerButtons = modal.querySelectorAll('[class*="footer"] button, [class*="actions"] button');
        for (const btn of footerButtons) {
          const text = btn.textContent.trim();
          if (text.toLowerCase().includes('next') && btn.offsetParent !== null) {
            return btn;
          }
        }
      },
      
      // Strategy 5: Look for blue/primary styled button with "Next"
      () => {
        const modal = document.querySelector('[role="dialog"]');
        if (!modal) return null;
        
        const buttons = modal.querySelectorAll('button[class*="primary"], button[class*="artdeco-button--primary"]');
        for (const btn of buttons) {
          const text = btn.textContent.trim();
          if (text === 'Next' && btn.offsetParent !== null) {
            return btn;
          }
        }
      }
    ];
    
    return this.tryStrategies(strategies);
  }
  
  /**
   * Try multiple strategies in order
   */
  static tryStrategies(strategies) {
    for (const strategy of strategies) {
      try {
        const result = strategy();
        if (result) {
          console.log('✅ Found element using strategy');
          return result;
        }
      } catch (e) {
        console.warn('Strategy failed:', e);
      }
    }
    console.warn('⚠️ All strategies failed');
    return null;
  }
}

// ============================================================================
// MESSAGE LISTENER
// ============================================================================

// ============================================================================
// GET LINKEDIN ACCOUNT ID
// ============================================================================

async function getLinkedInAccountId() {
  console.log('🔍 Getting LinkedIn account ID...');
  
  try {
    // Method 1: Voyager API (most reliable if it works)
    try {
      const csrfToken = getCsrfToken();
      const response = await fetch("https://www.linkedin.com/voyager/api/me", {
        credentials: "include",
        headers: {
          "accept": "application/vnd.linkedin.normalized+json+2.1",
          "csrf-token": csrfToken
        }
      });

      if (response.ok) {
        const data = await response.json();
        
        if (data && data.miniProfile && data.miniProfile.publicIdentifier) {
          console.log('✅ Found via Voyager API:', data.miniProfile.publicIdentifier);
          return data.miniProfile.publicIdentifier;
        }
        
        if (data && data.publicIdentifier) {
          console.log('✅ Found via Voyager API:', data.publicIdentifier);
          return data.publicIdentifier;
        }
      }
    } catch (error) {
      console.log('⚠️ Voyager API failed, trying alternate methods');
    }

    // Method 2: Check current page URL if on profile page
    try {
      const currentUrl = window.location.href;
      const profileMatch = currentUrl.match(/linkedin\.com\/in\/([^\/\?#]+)/);
      if (profileMatch && profileMatch[1]) {
        // Verify this is the logged-in user by checking if edit button exists
        const editButton = document.querySelector('[data-test-edit-profile-button]') ||
                          document.querySelector('button[aria-label*="Edit"]') ||
                          document.querySelector('button[aria-label*="edit"]');
        
        if (editButton) {
          console.log('✅ Found via profile page URL:', profileMatch[1]);
          return profileMatch[1];
        }
      }
    } catch (error) {
      console.log('⚠️ Profile URL check failed');
    }

    // Method 3: Extract from navigation "Me" menu
    try {
      // Look for the "Me" dropdown button
      const meButton = document.querySelector('[aria-label*="Me"]') ||
                      document.querySelector('button[id*="ember"]') ||
                      document.querySelector('[data-control-name="identity_welcome_message"]');
      
      if (meButton) {
        // Find the profile link near the me button
        const container = meButton.closest('nav') || meButton.closest('header') || document;
        const profileLinks = container.querySelectorAll('a[href*="/in/"]');
        
        for (const link of profileLinks) {
          const href = link.getAttribute('href');
          const match = href.match(/\/in\/([^\/\?#]+)/);
          if (match && match[1]) {
            console.log('✅ Found via Me menu:', match[1]);
            return match[1];
          }
        }
      }
    } catch (error) {
      console.log('⚠️ Me menu check failed');
    }

    // Method 4: Search all profile links in navigation/header
    try {
      const navElements = [
        ...document.querySelectorAll('nav a[href*="/in/"]'),
        ...document.querySelectorAll('header a[href*="/in/"]'),
        ...document.querySelectorAll('[class*="global-nav"] a[href*="/in/"]'),
        ...document.querySelectorAll('[class*="me-"] a[href*="/in/"]'),
        ...document.querySelectorAll('[data-control-name*="identity"] a[href*="/in/"]')
      ];
      
      for (const link of navElements) {
        const href = link.getAttribute('href');
        const match = href.match(/\/in\/([^\/\?#]+)/);
        
        if (match && match[1]) {
          console.log('✅ Found via navigation link:', match[1]);
          return match[1];
        }
      }
    } catch (error) {
      console.log('⚠️ Navigation links check failed');
    }

    // Method 5: Check localStorage for profile data
    try {
      const keys = Object.keys(localStorage);
      for (const key of keys) {
        if (key.includes('profile') || key.includes('user') || key.includes('member')) {
          try {
            const data = JSON.parse(localStorage.getItem(key));
            if (data && data.publicIdentifier) {
              console.log('✅ Found via localStorage:', data.publicIdentifier);
              return data.publicIdentifier;
            }
            if (data && typeof data === 'object') {
              const publicId = findPublicIdentifierInObject(data);
              if (publicId) {
                console.log('✅ Found via localStorage search:', publicId);
                return publicId;
              }
            }
          } catch (e) {
            // Not JSON, skip
          }
        }
      }
    } catch (error) {
      console.log('⚠️ localStorage check failed');
    }

    // Method 6: Look for any element with publicIdentifier data attribute
    try {
      const elements = document.querySelectorAll('[data-public-identifier]');
      if (elements.length > 0) {
        const id = elements[0].getAttribute('data-public-identifier');
        if (id) {
          console.log('✅ Found via data attribute:', id);
          return id;
        }
      }
    } catch (error) {
      console.log('⚠️ Data attribute check failed');
    }

    throw new Error('Could not detect LinkedIn account. Make sure you are logged in and on a LinkedIn page.');
    
  } catch (error) {
    console.error('❌ Failed to get LinkedIn account:', error);
    throw error;
  }
}

// Helper function to recursively search for publicIdentifier in object
function findPublicIdentifierInObject(obj, depth = 0) {
  if (depth > 3) return null; // Prevent infinite recursion
  
  if (!obj || typeof obj !== 'object') return null;
  
  if (obj.publicIdentifier && typeof obj.publicIdentifier === 'string') {
    return obj.publicIdentifier;
  }
  
  for (const key in obj) {
    if (obj.hasOwnProperty(key)) {
      const result = findPublicIdentifierInObject(obj[key], depth + 1);
      if (result) return result;
    }
  }
  
  return null;
}

function getCsrfToken() {
  const cookies = document.cookie.split(';');
  for (const cookie of cookies) {
    const [name, value] = cookie.trim().split('=');
    if (name === 'JSESSIONID') {
      return value.replace(/"/g, '');
    }
  }
  return '';
}

// ============================================================================
// MESSAGE LISTENER
// ============================================================================

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('📨 LinkedIn content received:', request.action);
  
  if (request.action === 'fillPost') {
    fillLinkedInPost(request.content, request.imageUrl, request.autoPost)
      .then(result => sendResponse(result))
      .catch(error => sendResponse({ 
        success: false, 
        error: error.message 
      }));
    return true;
  }
  
  if (request.action === 'scrapeAnalytics') {
    scrapePostAnalytics(request.postUrl)
      .then(result => sendResponse(result))
      .catch(error => sendResponse({ 
        success: false, 
        error: error.message 
      }));
    return true;
  }
  
  if (request.action === 'scrapeBulkAnalytics') {
    scrapeBulkAnalytics(request.postUrls)
      .then(result => sendResponse(result))
      .catch(error => sendResponse({ 
        success: false, 
        error: error.message 
      }));
    return true;
  }
  
  // =========================================================================
  // GET LINKEDIN ACCOUNT (FOR VERIFICATION)
  // =========================================================================
  if (request.action === 'getLinkedInAccount') {
    getLinkedInAccountId()
      .then(linkedinId => {
        sendResponse({
          success: true,
          linkedinId: linkedinId
        });
      })
      .catch(error => {
        sendResponse({
          success: false,
          error: error.message
        });
      });
    return true;
  }
  
  return true;
});

// ============================================================================
// FILL LINKEDIN POST - IMPROVED IMAGE HANDLING
// ============================================================================

async function fillLinkedInPost(content, imageUrl, autoPost = false) {
  console.log('📝 Filling LinkedIn post...');
  console.log('Content:', content);
  console.log('Image:', imageUrl);
  console.log('Auto-post:', autoPost);
  
  try {
    // Step 1: Click "Start a post"
    const startBtn = LinkedInUIAdapter.findStartPostButton();
    if (!startBtn) {
      throw new Error('Could not find "Start a post" button');
    }
    
    console.log('✅ Found start button');
    startBtn.click();
    await sleep(2000);
    
    // Step 2: Find text editor
    const editor = document.querySelector('[role="textbox"][contenteditable="true"]') ||
                   document.querySelector('.ql-editor[contenteditable="true"]') ||
                   document.querySelector('[contenteditable="true"]');
    
    if (!editor) {
      throw new Error('Could not find post editor');
    }
    
    console.log('✅ Found editor');
    
    // Step 3: Fill content
    editor.focus();
    await sleep(300);
    
    // Clear existing content
    editor.innerHTML = '';
    
    // Insert new content (preserve line breaks)
    const lines = content.split('\n');
    for (let i = 0; i < lines.length; i++) {
      const textNode = document.createTextNode(lines[i]);
      editor.appendChild(textNode);
      if (i < lines.length - 1) {
        editor.appendChild(document.createElement('br'));
      }
    }
    
    // Trigger input event
    editor.dispatchEvent(new Event('input', { bubbles: true }));
    editor.dispatchEvent(new Event('change', { bubbles: true }));
    
    console.log('✅ Content filled');
    await sleep(1000);
    
    // Step 4: Upload image if provided
    if (imageUrl) {
      console.log('📷 Uploading image...');
      
      try {
        // Download image as blob
        const response = await fetch(imageUrl);
        if (!response.ok) {
          throw new Error(`Failed to fetch image: ${response.status}`);
        }
        
        const blob = await response.blob();
        console.log('✅ Image downloaded:', blob.size, 'bytes');
        
        // Find image upload button
        const imageBtn = LinkedInUIAdapter.findImageUploadButton();
        if (!imageBtn) {
          console.warn('⚠️ Could not find image button - trying alternative method');
          
          // Alternative: Find file input directly
          const fileInput = LinkedInUIAdapter.findFileInput();
          if (!fileInput) {
            throw new Error('Could not find image upload method');
          }
          
          console.log('✅ Found file input (direct)');
          
          // Create File object from blob
          const file = new File([blob], 'image.jpg', { type: blob.type });
          
          // Create DataTransfer to set files
          const dataTransfer = new DataTransfer();
          dataTransfer.items.add(file);
          fileInput.files = dataTransfer.files;
          
          // Trigger change event
          fileInput.dispatchEvent(new Event('change', { bubbles: true }));
          
        } else {
          console.log('✅ Found image button');
          imageBtn.click();
          await sleep(1500);
          
          // Find file input
          const fileInput = LinkedInUIAdapter.findFileInput();
          if (!fileInput) {
            throw new Error('Could not find file input after clicking image button');
          }
          
          console.log('✅ Found file input');
          
          // Create File object from blob
          const file = new File([blob], 'image.jpg', { type: blob.type });
          
          // Set files using DataTransfer
          const dataTransfer = new DataTransfer();
          dataTransfer.items.add(file);
          fileInput.files = dataTransfer.files;
          
          // Trigger change event
          fileInput.dispatchEvent(new Event('change', { bubbles: true }));
        }
        
        console.log('✅ Image uploaded');
        await sleep(3000); // Initial wait for image to process
        
        // NEW: Check for "Next" button (appears in new LinkedIn UI after image upload)
        console.log('🔍 Checking for Next button...');
        let nextBtn = LinkedInUIAdapter.findNextButton();
        
        // Retry finding Next button up to 3 times with delays
        let retries = 0;
        while (!nextBtn && retries < 3) {
          console.log(`⏳ Next button not found yet, retrying... (${retries + 1}/3)`);
          await sleep(1500);
          nextBtn = LinkedInUIAdapter.findNextButton();
          retries++;
        }
        
        if (nextBtn) {
          console.log('✅ Found Next button - clicking...');
          // Check if button is enabled
          if (!nextBtn.disabled && !nextBtn.hasAttribute('disabled')) {
            nextBtn.click();
            await sleep(2500); // Wait for next screen
            console.log('✅ Next button clicked');
          } else {
            console.warn('⚠️ Next button found but disabled - waiting longer...');
            await sleep(2000);
            // Try clicking anyway after wait
            nextBtn.click();
            await sleep(2500);
            console.log('✅ Next button clicked (was disabled)');
          }
        } else {
          console.log('ℹ️ No Next button found (may not be needed in this UI version)');
        }
        
      } catch (imgError) {
        console.error('❌ Image upload failed:', imgError);
        // Continue without image
      }
    }
    
    // Step 5: Post if auto-post enabled
    let postUrl = null;
    
    if (autoPost) {
      console.log('🚀 Auto-posting...');
      
      // Try multiple times to find Post button (may take time to appear)
      let postBtn = null;
      let attempts = 0;
      const maxAttempts = 10; // Increased from implicit 1
      
      while (!postBtn && attempts < maxAttempts) {
        attempts++;
        console.log(`🔍 Looking for Post button (attempt ${attempts}/${maxAttempts})...`);
        
        postBtn = LinkedInUIAdapter.findPostButton();
        
        if (!postBtn) {
          console.log(`⏳ Post button not found, waiting 1 second...`);
          await sleep(1000);
        }
      }
      
      if (!postBtn) {
        throw new Error(`Could not find Post button after ${maxAttempts} attempts. Make sure the post modal is open and content is valid.`);
      }
      
      console.log('✅ Found post button');
      
      // Check if button is disabled
      if (postBtn.disabled || postBtn.hasAttribute('disabled') || postBtn.getAttribute('aria-disabled') === 'true') {
        console.warn('⚠️ Post button is disabled');
        throw new Error('Post button is disabled - content may be too short or image still uploading. Please wait and try again.');
      }
      
      postBtn.click();
      console.log('✅ Clicked post button');
      
      // Wait longer for post to complete
      await sleep(7000); // Increased from 5000
      
      // Extract post URL
      postUrl = await extractPostUrl();
      
      if (postUrl) {
        console.log('✅ Post created:', postUrl);
      } else {
        console.warn('⚠️ Post created but URL not captured');
      }
    }
    
    return {
      success: true,
      message: autoPost ? 'Post published' : 'Post filled, ready to publish',
      postUrl: postUrl,
      linkedinUrl: postUrl
    };
    
  } catch (error) {
    console.error('❌ fillLinkedInPost error:', error);
    return {
      success: false,
      error: error.message
    };
  }
}

// ============================================================================
// EXTRACT POST URL - IMPROVED
// ============================================================================

async function extractPostUrl() {
  console.log('🔗 Extracting post URL...');
  
  await sleep(3000); // Wait for post to appear
  
  try {
    // ========================================================================
    // Method 1: Check current URL (after redirect)
    // ========================================================================
    console.log('🔍 Method 1: Checking URL redirect...');
    if (window.location.href.includes('/feed/update/') || 
        window.location.href.includes('/posts/') ||
        window.location.href.includes('/activity-')) {
      console.log('✅ Method 1: URL from location:', window.location.href);
      return window.location.href;
    }
    
    // ========================================================================
    // Method 2: 3 DOTS MENU → Copy Link (MOST RELIABLE!)
    // ========================================================================
    console.log('🔍 Method 2: Using 3 dots menu (MOST RELIABLE)...');
    
    // Find the most recent post (first in feed)
    const feedPosts = document.querySelectorAll('[data-urn*="activity:"]');
    
    if (feedPosts.length > 0) {
      const latestPost = feedPosts[0];
      console.log('✅ Found latest post container');
      
      // Find the 3 dots button (overflow menu)
      const overflowSelectors = [
        'button[aria-label*="Open control menu"]',
        'button[aria-label*="More actions"]',
        'button[data-control-name*="overflow"]',
        'button.feed-shared-control-menu__trigger',
        'button[aria-label*="Open menu"]',
        'button.feed-shared-control-menu'
      ];
      
      let overflowButton = null;
      for (const selector of overflowSelectors) {
        const buttons = latestPost.querySelectorAll(selector);
        for (const btn of buttons) {
          if (btn.offsetParent !== null) { // Skip hidden buttons
            overflowButton = btn;
            break;
          }
        }
        if (overflowButton) break;
      }
      
      if (overflowButton) {
        console.log('✅ Found 3 dots button, clicking...');
        overflowButton.click();
        await sleep(1000);
        
        // Look for "Copy link to post" option
        const copyLinkSelectors = [
          'div[role="menuitem"]',
          'button[role="menuitem"]',
          'a[role="menuitem"]',
          '.artdeco-dropdown__item'
        ];
        
        let allMenuItems = [];
        for (const selector of copyLinkSelectors) {
          allMenuItems.push(...document.querySelectorAll(selector));
        }
        
        for (const menuItem of allMenuItems) {
          const text = menuItem.textContent.toLowerCase();
          if ((text.includes('copy') && text.includes('link')) || 
              text.includes('copy link to post')) {
            console.log('✅ Found "Copy link" option, clicking...');
            
            // Clear clipboard first
            try {
              await navigator.clipboard.writeText('');
            } catch (e) {
              console.log('⚠️ Could not clear clipboard');
            }
            
            // Click copy link
            menuItem.click();
            await sleep(800);
            
            // Read from clipboard
            try {
              const clipboardText = await navigator.clipboard.readText();
              
              if (clipboardText && clipboardText.includes('linkedin.com')) {
                console.log('✅ Method 2: URL from clipboard:', clipboardText);
                
                // Close menu (click outside or press ESC)
                document.body.click();
                
                return clipboardText;
              }
            } catch (e) {
              console.log('⚠️ Could not read clipboard:', e.message);
            }
          }
        }
        
        // Close menu if we didn't find copy link
        document.body.click();
      }
    }
    
    // ========================================================================
    // Method 3: Look for notification "View post" link
    // ========================================================================
    console.log('🔍 Method 3: Checking notification link...');
    await sleep(1000);
    const viewPostLink = document.querySelector('a[href*="/feed/update/"]');
    if (viewPostLink) {
      console.log('✅ Method 3: URL from notification:', viewPostLink.href);
      return viewPostLink.href;
    }
    
    // ========================================================================
    // Method 4: Extract from data-urn in feed
    // ========================================================================
    console.log('🔍 Method 4: Extracting from data-urn...');
    const feedPostsRetry = document.querySelectorAll('[data-urn*="activity:"]');
    if (feedPostsRetry.length > 0) {
      const latestPost = feedPostsRetry[0];
      const urn = latestPost.getAttribute('data-urn');
      if (urn && urn.includes('activity:')) {
        const activityId = urn.split('activity:')[1].split(',')[0];
        const url = `https://www.linkedin.com/feed/update/urn:li:activity:${activityId}/`;
        console.log('✅ Method 4: URL from data-urn:', url);
        return url;
      }
    }
    
    console.warn('⚠️ Could not extract post URL using any method');
    return null;
    
  } catch (e) {
    console.error('❌ extractPostUrl error:', e);
    return null;
  }
}

// ============================================================================
// SCRAPE ANALYTICS - PURE DOM (NO API)
// ============================================================================

async function scrapePostAnalytics(postUrl) {
  console.log('📊 Scraping analytics (DOM only):', postUrl);
  console.log('🔍 Current URL:', window.location.href);
  
  try {
    // Navigate to post if not already there
    if (!window.location.href.includes(postUrl)) {
      console.log('🔄 Navigating to post...');
      window.location.href = postUrl;
      await sleep(3000); // Wait for page load
    }
    
    console.log('⏳ Waiting for content to load...');
    await sleep(2000); // Extra wait for content
    
    const analytics = {
      url: postUrl,
      views: 0,
      likes: 0,
      comments: 0,
      reposts: 0,
      scrapedAt: new Date().toISOString()
    };
    
    console.log('🔍 Starting DOM scraping...');
    
    // Scrape from DOM
    scrapeViaDOM(analytics);
    
    console.log('✅ Analytics scraped:', analytics);
    console.log('📊 Final results:', {
      views: analytics.views,
      likes: analytics.likes,
      comments: analytics.comments,
      reposts: analytics.reposts
    });
    
    // Send message to webapp if available
    window.postMessage({
      type: 'ANALYTICS_SCRAPED',
      data: analytics
    }, '*');
    
    return {
      success: true,
      analytics: analytics
    };
    
  } catch (error) {
    console.error('❌ scrapePostAnalytics error:', error);
    return {
      success: false,
      error: error.message,
      analytics: {
        url: postUrl,
        views: 0,
        likes: 0,
        comments: 0,
        reposts: 0,
        error: error.message
      }
    };
  }
}

// ============================================================================
// SCRAPE VIA DOM - IMPROVED SELECTORS
// ============================================================================

function scrapeViaDOM(analytics) {
  console.log('🔍 Scraping via DOM...');
  
  // Strategy 1: Views/Impressions - ENHANCED FOR 2025 LINKEDIN UI
  const viewsSelectors = [
    // Look for the exact "X impressions" text pattern
    'span.social-details-social-counts__social-proof-fallback-number',
    'span.t-black--light',
    '[aria-label*="impression" i]',
    '[class*="impression" i]',
    '.social-details-social-counts__reactions-count',
    '.social-details-social-counts span',
    '[data-test-id="social-actions__view-count"]'
  ];
  
  // First, try to find elements containing "impressions" text
  let found = false;
  const allSpans = document.querySelectorAll('span');
  for (const span of allSpans) {
    const text = span.textContent.trim().toLowerCase();
    if (text.includes('impression')) {
      const count = parseCount(span.textContent);
      if (count > 0) {
        analytics.views = count;
        console.log('✅ Views/Impressions:', count, 'from text search:', span.textContent.trim());
        found = true;
        break;
      }
    }
  }
  
  // If not found, try the selector strategies
  if (!found) {
    for (const selector of viewsSelectors) {
      const el = document.querySelector(selector);
      if (el) {
        const text = el.textContent || el.getAttribute('aria-label') || '';
        const count = parseCount(text);
        if (count > 0) {
          analytics.views = count;
          console.log('✅ Views/Impressions:', count, 'from selector:', selector);
          break;
        }
      }
    }
  }
  
  // Strategy 2: Likes/Reactions - ENHANCED
  const likesSelectors = [
    'button[aria-label*="reaction" i] span.react-count',
    '[aria-label*="reaction" i]',
    '.social-details-social-counts__social-proof-text',
    '[class*="reaction-count"]',
    '.social-details-social-counts__count-value',
    '[data-test-id="social-actions__reaction-count"]',
    'button.reactions-react-button span'
  ];
  
  // First try to find the reaction count button
  found = false;
  const reactionButtons = document.querySelectorAll('button[aria-label*="reaction" i], button.social-details-social-counts__reactions');
  for (const btn of reactionButtons) {
    const ariaLabel = btn.getAttribute('aria-label') || '';
    const count = parseCount(ariaLabel);
    if (count > 0) {
      analytics.likes = count;
      console.log('✅ Likes/Reactions:', count, 'from button aria-label:', ariaLabel);
      found = true;
      break;
    }
  }
  
  // If not found, try selectors
  if (!found) {
    for (const selector of likesSelectors) {
      const el = document.querySelector(selector);
      if (el) {
        const text = el.textContent || el.getAttribute('aria-label') || '';
        const count = parseCount(text);
        if (count > 0) {
          analytics.likes = count;
          console.log('✅ Likes/Reactions:', count, 'from selector:', selector);
          break;
        }
      }
    }
  }
  
  // Strategy 3: Comments
  const commentsSelectors = [
    '[aria-label*="comment"]',
    'button[aria-label*="comment"]',
    '[data-test-id="social-actions__comments"]',
    '.social-details-social-counts__comments'
  ];
  
  for (const selector of commentsSelectors) {
    const el = document.querySelector(selector);
    if (el) {
      const text = el.textContent || el.getAttribute('aria-label') || '';
      const count = parseCount(text);
      if (count >= 0) { // 0 is valid for comments
        analytics.comments = count;
        console.log('✅ Comments:', count, 'from', selector);
        break;
      }
    }
  }
  
  // Strategy 4: Reposts/Shares
  const repostsSelectors = [
    '[aria-label*="repost"]',
    'button[aria-label*="repost"]',
    '[data-test-id="social-actions__reposts"]',
    '.social-details-social-counts__reposts'
  ];
  
  for (const selector of repostsSelectors) {
    const el = document.querySelector(selector);
    if (el) {
      const text = el.textContent || el.getAttribute('aria-label') || '';
      const count = parseCount(text);
      if (count >= 0) { // 0 is valid for reposts
        analytics.reposts = count;
        console.log('✅ Reposts:', count, 'from', selector);
        break;
      }
    }
  }
  
  console.log('📊 DOM scraping complete:', analytics);
}

// ============================================================================
// BULK SCRAPE
// ============================================================================

async function scrapeBulkAnalytics(postUrls) {
  console.log(`📊 Bulk scraping ${postUrls.length} posts...`);
  
  const results = [];
  
  for (let i = 0; i < postUrls.length; i++) {
    console.log(`📍 Scraping post ${i + 1}/${postUrls.length}`);
    
    const result = await scrapePostAnalytics(postUrls[i]);
    results.push({
      url: postUrls[i],
      ...result
    });
    
    // Wait between posts to avoid rate limiting
    if (i < postUrls.length - 1) {
      await sleep(3000);
    }
  }
  
  const successful = results.filter(r => r.success).length;
  
  return {
    success: true,
    results: results,
    total: postUrls.length,
    successful: successful
  };
}

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

function parseCount(text) {
  if (!text) return 0;
  
  // Remove all non-numeric except K, M, B and decimal point
  const cleaned = text.replace(/[^0-9KMBkmb.]/g, '');
  if (!cleaned) return 0;
  
  const upper = cleaned.toUpperCase();
  
  if (upper.includes('K')) {
    return Math.round(parseFloat(upper) * 1000);
  }
  if (upper.includes('M')) {
    return Math.round(parseFloat(upper) * 1000000);
  }
  if (upper.includes('B')) {
    return Math.round(parseFloat(upper) * 1000000000);
  }
  
  return parseInt(cleaned) || 0;
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

console.log('✅ LinkedBot v8.0 (DOM-Only, No API) loaded');
