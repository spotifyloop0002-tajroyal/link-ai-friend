// ============================================================================
// LINKEDBOT WEBAPP CONTENT SCRIPT v5.0 - AUTO-RECONNECT + ANALYTICS
// ============================================================================
// Features:
// 1. Auto-reconnect on page refresh
// 2. Send posts to LinkedIn
// 3. Request analytics scraping
// 4. Receive scraped data
// ============================================================================

console.log('🌐 LinkedBot webapp content script loaded v5.0');

// Mark script as loaded
window.linkedBotWebappLoaded = true;
window.linkedBotWebappVersion = '5.0';

let extensionContextValid = true;
let reconnectAttempts = 0;
const MAX_RECONNECT_ATTEMPTS = 3;

// ============================================================================
// CONTEXT VALIDATION
// ============================================================================

function checkExtensionContext() {
  try {
    const id = chrome.runtime?.id;
    return !!id;
  } catch (error) {
    return false;
  }
}

function notifyContextInvalidated() {
  if (!extensionContextValid) return;
  
  extensionContextValid = false;
  console.error('🔴 Extension reloaded - page refresh required');
  
  window.postMessage({
    type: 'EXTENSION_CONTEXT_INVALIDATED',
    message: 'Extension was reloaded. Please refresh the page.',
    requiresRefresh: true
  }, '*');
}

// ============================================================================
// SAFE MESSAGE SENDING
// ============================================================================

async function safeSendMessage(message) {
  if (!checkExtensionContext()) {
    notifyContextInvalidated();
    return { 
      success: false, 
      error: 'Extension reloaded. Refresh page.',
      requiresRefresh: true
    };
  }

  try {
    // Wake up service worker
    if (message.action !== 'wakeUp') {
      try {
        await chrome.runtime.sendMessage({ action: 'wakeUp' });
        await new Promise(resolve => setTimeout(resolve, 50));
      } catch (wakeError) {
        // Ignore wake errors
      }
    }

    if (!checkExtensionContext()) {
      notifyContextInvalidated();
      return { success: false, error: 'Context lost', requiresRefresh: true };
    }

    const response = await chrome.runtime.sendMessage(message);
    return { success: true, data: response };
    
  } catch (error) {
    if (error.message.includes('Extension context') || !checkExtensionContext()) {
      notifyContextInvalidated();
      return { success: false, error: 'Extension reloaded', requiresRefresh: true };
    }
    
    return { success: false, error: error.message };
  }
}

// ============================================================================
// AUTO-RECONNECT LOGIC
// ============================================================================

async function attemptConnection() {
  console.log('🔌 Attempting to connect extension...');
  console.log('📋 Extension context valid:', checkExtensionContext());
  
  try {
    const result = await safeSendMessage({ action: 'getExtensionId' });
    console.log('📨 Connection result:', result);
    
    if (result.success) {
      reconnectAttempts = 0; // Reset on success
      
      window.postMessage({
        type: 'EXTENSION_CONNECTED',
        extensionId: result.data.extensionId,
        autoReconnect: true
      }, '*');
      
      await safeSendMessage({ action: 'setConnected' });
      console.log('✅ Extension auto-connected');
      
      // After reconnecting, trigger analytics scraping if needed
      window.postMessage({
        type: 'EXTENSION_READY_FOR_SCRAPING'
      }, '*');
      
      return true;
    } else {
      reconnectAttempts++;
      console.error(`❌ Connection attempt ${reconnectAttempts} failed:`, result.error);
      
      if (reconnectAttempts < MAX_RECONNECT_ATTEMPTS) {
        // Retry after delay
        console.log(`🔄 Retrying in ${reconnectAttempts}s...`);
        setTimeout(attemptConnection, reconnectAttempts * 1000);
      } else {
        console.error('❌ Max reconnect attempts reached');
        window.postMessage({
          type: 'EXTENSION_CONNECTED',
          extensionId: null,
          error: 'Failed to connect after multiple attempts',
          requiresRefresh: result.requiresRefresh
        }, '*');
      }
      return false;
    }
  } catch (error) {
    console.error('❌ Connection error:', error);
    reconnectAttempts++;
    
    if (reconnectAttempts < MAX_RECONNECT_ATTEMPTS) {
      setTimeout(attemptConnection, reconnectAttempts * 1000);
    }
    return false;
  }
}

// ============================================================================
// LISTEN FOR MESSAGES FROM EXTENSION
// ============================================================================

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  // Handle POST_SUCCESS message specifically
  if (request.type === 'POST_SUCCESS') {
    console.log('✅ POST_SUCCESS received:', request.postUrl);
    
    window.postMessage({
      type: 'POST_SUCCESS',
      postId: request.postId,
      trackingId: request.trackingId,
      postUrl: request.postUrl,
      linkedinUrl: request.linkedinUrl || request.postUrl,
      timestamp: request.timestamp
    }, '*');
    
    sendResponse({ success: true });
    return true;
  }
  
  // Handle general extension events
  if (request.action === 'extensionEvent') {
    console.log('📨 Extension event:', request.event);
    
    window.postMessage({
      type: 'EXTENSION_EVENT',
      event: request.event,
      data: request.data
    }, '*');
    
    sendResponse({ success: true });
  }
  return true;
});

// ============================================================================
// LISTEN FOR MESSAGES FROM WEBPAGE
// ============================================================================

window.addEventListener('message', async (event) => {
  // Only accept messages from same window
  if (event.source !== window) return;
  
  const message = event.data;

  // =========================================================================
  // CONNECTION
  // =========================================================================
  
  if (message.type === 'CONNECT_EXTENSION') {
    console.log('🔌 Manual connection request...');
    reconnectAttempts = 0; // Reset counter
    await attemptConnection();
    return;
  }

  // =========================================================================
  // DISCONNECT
  // =========================================================================
  
  if (message.type === 'DISCONNECT_EXTENSION') {
    await safeSendMessage({ action: 'setDisconnected' });
    window.postMessage({ 
      type: 'EXTENSION_DISCONNECTED', 
      reason: 'manual' 
    }, '*');
    return;
  }

  // =========================================================================
  // CHECK STATUS
  // =========================================================================
  
  if (message.type === 'CHECK_EXTENSION') {
    const result = await safeSendMessage({ action: 'getStatus' });
    
    window.postMessage({
      type: 'EXTENSION_STATUS',
      connected: result.success ? result.data.connected : false,
      extensionId: result.success ? result.data.extensionId : null,
      error: result.success ? null : result.error,
      requiresRefresh: result.requiresRefresh
    }, '*');
    return;
  }

  // =========================================================================
  // SCHEDULE POSTS
  // =========================================================================
  
  if (message.type === 'SCHEDULE_POSTS') {
    console.log('📥 Scheduling posts:', message.posts?.length || 0);
    
    const result = await safeSendMessage({
      action: 'schedulePosts',
      posts: message.posts
    });

    window.postMessage({
      type: 'SCHEDULE_RESULT',
      success: result.success,
      queueLength: result.success ? result.data.queueLength : 0,
      nextScheduled: result.success ? result.data.nextScheduled : null,
      message: result.success ? result.data.message : null,
      error: result.success ? null : result.error,
      requiresRefresh: result.requiresRefresh
    }, '*');
    return;
  }

  // =========================================================================
  // POST NOW
  // =========================================================================
  
  if (message.type === 'POST_NOW') {
    console.log('📤 Posting immediately:', message.post?.id);
    
    const result = await safeSendMessage({
      action: 'postNow',
      post: message.post
    });

    window.postMessage({
      type: 'POST_RESULT',
      success: result.success,
      postId: message.post.id,
      linkedinUrl: result.success ? result.data.linkedinUrl : null,
      postUrl: result.success ? result.data.postUrl : null,
      error: result.success ? null : result.error,
      requiresRefresh: result.requiresRefresh
    }, '*');
    return;
  }

  // =========================================================================
  // SCRAPE ANALYTICS - SINGLE POST
  // =========================================================================
  
  if (message.type === 'SCRAPE_ANALYTICS') {
    console.log('📊 Requesting analytics scrape for:', message.postUrl);
    
    const result = await safeSendMessage({
      action: 'scrapeAnalytics',
      postUrl: message.postUrl
    });

    window.postMessage({
      type: 'ANALYTICS_RESULT',
      success: result.success,
      postUrl: message.postUrl,
      analytics: result.success ? result.data.analytics : null,
      error: result.success ? null : result.error,
      requiresRefresh: result.requiresRefresh
    }, '*');
    return;
  }

  // =========================================================================
  // SCRAPE ANALYTICS - BULK
  // =========================================================================
  
  if (message.type === 'SCRAPE_BULK_ANALYTICS') {
    console.log('📊 Requesting bulk analytics scrape for', message.postUrls?.length, 'posts');
    
    const result = await safeSendMessage({
      action: 'scrapeBulkAnalytics',
      postUrls: message.postUrls
    });

    window.postMessage({
      type: 'BULK_ANALYTICS_RESULT',
      success: result.success,
      results: result.success ? result.data.results : null,
      total: result.success ? result.data.total : 0,
      successful: result.success ? result.data.successful : 0,
      error: result.success ? null : result.error,
      requiresRefresh: result.requiresRefresh
    }, '*');
    return;
  }

  // =========================================================================
  // VERIFY LINKEDIN ACCOUNT
  // =========================================================================
  
  if (message.type === 'VERIFY_LINKEDIN_ACCOUNT') {
    console.log('🔐 Verifying LinkedIn account:', message.expectedLinkedInId);
    
    const result = await safeSendMessage({
      action: 'verifyLinkedInAccount',
      expectedLinkedInId: message.expectedLinkedInId
    });

    window.postMessage({
      type: 'VERIFY_RESULT',
      success: result.success ? result.data.success : false,
      linkedinId: result.success ? result.data.linkedinId : null,
      error: result.success ? result.data.error : result.error,
      message: result.success ? result.data.message : result.error,
      currentLinkedInId: result.success ? result.data.currentLinkedInId : null,
      expectedLinkedInId: result.success ? result.data.expectedLinkedInId : null,
      requiresRefresh: result.requiresRefresh
    }, '*');
    return;
  }

  // =========================================================================
  // GET CURRENT LINKEDIN ACCOUNT
  // =========================================================================
  
  if (message.type === 'GET_CURRENT_LINKEDIN_ACCOUNT') {
    console.log('🔍 Getting current LinkedIn account...');
    
    const result = await safeSendMessage({
      action: 'getCurrentLinkedInAccount'
    });

    window.postMessage({
      type: 'CURRENT_LINKEDIN_ACCOUNT',
      success: result.success ? result.data.success : false,
      linkedinId: result.success ? result.data.linkedinId : null,
      isLoggedIn: result.success ? result.data.isLoggedIn : false,
      error: result.success ? result.data.error : result.error,
      message: result.success ? result.data.message : result.error,
      requiresRefresh: result.requiresRefresh
    }, '*');
    return;
  }
});

// ============================================================================
// AUTO-RECONNECT ON PAGE LOAD/REFRESH
// ============================================================================

// Method 1: On DOMContentLoaded (fires early)
document.addEventListener('DOMContentLoaded', () => {
  console.log('📄 DOM loaded - checking extension...');
  if (checkExtensionContext()) {
    attemptConnection();
  } else {
    notifyContextInvalidated();
  }
});

// Method 2: On window load (backup, fires later)
window.addEventListener('load', () => {
  setTimeout(() => {
    if (checkExtensionContext() && reconnectAttempts === 0) {
      console.log('🔍 Window loaded - auto-checking extension...');
      attemptConnection();
    } else if (!checkExtensionContext()) {
      notifyContextInvalidated();
    }
  }, 500);
});

// Method 3: Immediate check (for dynamic page loads)
setTimeout(() => {
  if (checkExtensionContext() && reconnectAttempts === 0) {
    console.log('⚡ Immediate check - connecting extension...');
    attemptConnection();
  }
}, 100);

// Method 4: Periodic health check (every 30 seconds)
setInterval(() => {
  if (checkExtensionContext()) {
    // Silently verify connection is still alive
    safeSendMessage({ action: 'getStatus' }).then(result => {
      if (!result.success) {
        console.warn('⚠️ Lost connection - attempting reconnect...');
        attemptConnection();
      }
    });
  }
}, 30000);

console.log('✅ Webapp content script ready v5.0 with auto-reconnect and analytics');