# 🔐 LINKEDIN ACCOUNT VERIFICATION - IMPLEMENTATION GUIDE

This guide shows how to integrate LinkedIn account verification into your LinkedBot website.

---

## 📋 OVERVIEW

The extension now **automatically verifies** that users can only post from the LinkedIn account they registered with on your website.

### Security Flow:

```
1. User signs up → enters LinkedIn profile URL
2. Website extracts LinkedIn ID (e.g., "aryan-bhatnagar")
3. User clicks "Verify LinkedIn" button
4. Extension checks logged-in LinkedIn account
5. Extension compares: current account === registered account
6. If match ✅ → verified
7. If mismatch ❌ → shows error
8. Before every post → extension re-checks account
```

---

## 🌐 PART 1: WEBSITE IMPLEMENTATION

### Step 1: During Signup/Login

```javascript
// User enters LinkedIn profile URL
const linkedinProfileUrl = "https://www.linkedin.com/in/aryan-bhatnagar/";

// Extract public identifier
function extractLinkedInId(url) {
  const match = url.match(/\/in\/([^\/\?]+)/);
  return match ? match[1] : null;
}

const linkedinId = extractLinkedInId(linkedinProfileUrl);
// Result: "aryan-bhatnagar"

// Save to database
await db.users.update(userId, {
  linkedin_profile_url: linkedinProfileUrl,
  linkedin_public_id: linkedinId,
  linkedin_verified: false
});
```

### Step 2: Show "Verify LinkedIn" Button

```html
<!-- In your dashboard -->
<div class="verification-section">
  <h3>LinkedIn Account Verification</h3>
  
  <p>Registered Account: <strong>linkedin.com/in/aryan-bhatnagar</strong></p>
  
  <button id="verifyLinkedInBtn" class="btn-verify">
    🔐 Verify LinkedIn Account
  </button>
  
  <div id="verificationStatus"></div>
</div>
```

### Step 3: Handle Verification Click

```javascript
document.getElementById('verifyLinkedInBtn').addEventListener('click', async () => {
  const statusDiv = document.getElementById('verificationStatus');
  statusDiv.innerHTML = '🔄 Checking...';
  
  // Get user's registered LinkedIn ID from your database
  const user = await getCurrentUser();
  const expectedLinkedInId = user.linkedin_public_id; // e.g., "aryan-bhatnagar"
  
  // Send verification request to extension
  window.postMessage({
    type: 'VERIFY_LINKEDIN_ACCOUNT',
    expectedLinkedInId: expectedLinkedInId
  }, '*');
});
```

### Step 4: Listen for Verification Result

```javascript
window.addEventListener('message', async (event) => {
  if (event.source !== window) return;
  
  const message = event.data;
  
  // ========================================================================
  // VERIFICATION RESULT
  // ========================================================================
  if (message.type === 'VERIFY_RESULT') {
    const statusDiv = document.getElementById('verificationStatus');
    
    if (message.success) {
      // ✅ VERIFIED!
      statusDiv.innerHTML = `
        <div class="alert alert-success">
          ✅ LinkedIn account verified successfully!<br>
          Account: <strong>${message.linkedinId}</strong>
        </div>
      `;
      
      // Update database
      await updateUserVerificationStatus(true);
      
      // Enable posting features
      enablePostingFeatures();
      
    } else {
      // ❌ VERIFICATION FAILED
      
      if (message.error === 'LINKEDIN_NOT_OPEN') {
        statusDiv.innerHTML = `
          <div class="alert alert-error">
            ❌ LinkedIn is not open in this browser.<br>
            Please open <a href="https://www.linkedin.com" target="_blank">linkedin.com</a> 
            and log in, then try again.
          </div>
        `;
      }
      
      else if (message.error === 'NOT_LOGGED_IN') {
        statusDiv.innerHTML = `
          <div class="alert alert-error">
            ❌ You are not logged into LinkedIn.<br>
            Please log in at <a href="https://www.linkedin.com" target="_blank">linkedin.com</a>, 
            then try again.
          </div>
        `;
      }
      
      else if (message.error === 'ACCOUNT_MISMATCH') {
        statusDiv.innerHTML = `
          <div class="alert alert-error">
            ❌ Wrong LinkedIn account!<br>
            <strong>Expected:</strong> ${message.expectedLinkedInId}<br>
            <strong>You're logged in as:</strong> ${message.currentLinkedInId}<br><br>
            Please log into the correct account or update your profile.
          </div>
        `;
      }
      
      else {
        statusDiv.innerHTML = `
          <div class="alert alert-error">
            ❌ Verification failed: ${message.message}
          </div>
        `;
      }
    }
  }
});
```

---

## 🔒 PART 2: POSTING WITH VERIFICATION

### Before Every Post

The extension **automatically checks** the LinkedIn account before posting. If the user switches to a different account, posting will fail.

### Handle Post Errors

```javascript
window.addEventListener('message', (event) => {
  if (event.source !== window) return;
  
  const message = event.data;
  
  // ========================================================================
  // POST RESULT
  // ========================================================================
  if (message.type === 'POST_RESULT') {
    if (!message.success) {
      
      // Check if it's an account mismatch error
      if (message.error.includes('Account mismatch')) {
        showAlert('error', `
          ❌ Cannot post: You're logged into the wrong LinkedIn account!
          <br><br>
          ${message.error}
        `);
        
        // Optionally: mark user as unverified
        await updateUserVerificationStatus(false);
      }
      
      else {
        showAlert('error', `Post failed: ${message.error}`);
      }
    }
  }
});
```

---

## 🎯 PART 3: OPTIONAL - CHECK CURRENT ACCOUNT

You can check which LinkedIn account the user is currently logged into:

```javascript
// Send request
window.postMessage({
  type: 'GET_CURRENT_LINKEDIN_ACCOUNT'
}, '*');

// Listen for response
window.addEventListener('message', (event) => {
  if (event.source !== window) return;
  
  if (event.data.type === 'CURRENT_LINKEDIN_ACCOUNT') {
    const message = event.data;
    
    if (message.success && message.isLoggedIn) {
      console.log('Current LinkedIn account:', message.linkedinId);
    } else {
      console.log('Not logged into LinkedIn');
    }
  }
});
```

---

## 🗄️ PART 4: DATABASE SCHEMA

Add these fields to your users table:

```sql
ALTER TABLE users ADD COLUMN linkedin_profile_url VARCHAR(255);
ALTER TABLE users ADD COLUMN linkedin_public_id VARCHAR(100);
ALTER TABLE users ADD COLUMN linkedin_verified BOOLEAN DEFAULT FALSE;
ALTER TABLE users ADD COLUMN linkedin_verified_at TIMESTAMP NULL;
```

Or in your model:

```javascript
// User model
{
  email: String,
  password: String,
  linkedin_profile_url: String,      // https://www.linkedin.com/in/aryan-bhatnagar/
  linkedin_public_id: String,        // aryan-bhatnagar
  linkedin_verified: Boolean,        // true/false
  linkedin_verified_at: Date,        // timestamp
}
```

---

## 🚫 ERROR CODES REFERENCE

| Error Code | Meaning | User Action Required |
|------------|---------|---------------------|
| `LINKEDIN_NOT_OPEN` | LinkedIn.com is not open | Open LinkedIn in browser |
| `NOT_LOGGED_IN` | Not logged into LinkedIn | Log in to LinkedIn |
| `ACCOUNT_MISMATCH` | Wrong LinkedIn account | Switch to correct account |
| `DETECTION_FAILED` | Can't detect account | Refresh page, try again |
| `VERIFICATION_ERROR` | General error | Contact support |

---

## 🔐 SECURITY FEATURES

✅ **What this prevents:**
- User cannot post from a different LinkedIn account
- User cannot post without verification
- User cannot bypass verification
- User cannot switch accounts mid-session

✅ **How it works:**
- Extension stores verified account in local storage
- Before every post, extension checks current account
- If mismatch detected → post is blocked
- Error is sent back to website

---

## 📱 COMPLETE EXAMPLE

See `WEBSITE_INTEGRATION_EXAMPLE.html` for a complete working example.

---

## 🧪 TESTING CHECKLIST

- [ ] User enters LinkedIn URL during signup
- [ ] LinkedIn ID is extracted and saved
- [ ] "Verify LinkedIn" button appears
- [ ] Clicking button checks LinkedIn account
- [ ] Success: Shows verified message
- [ ] Error: Shows specific error message
- [ ] User tries to post from wrong account → blocked
- [ ] Error message shows account mismatch
- [ ] User switches to correct account → posting works

---

## 🆘 TROUBLESHOOTING

**"Extension not connected"**
- Make sure extension is installed
- Refresh the website page

**"LinkedIn not open"**
- Open linkedin.com in a new tab
- Must be in the same browser

**"Account mismatch"**
- User is logged into different LinkedIn account
- Tell them to log out and log into correct account

**Verification stuck**
- Extension might need reload
- Try refreshing both LinkedIn and website

---

## 🎉 DONE!

Your LinkedBot website now has secure LinkedIn account verification! 

Users can only post from their verified account, preventing multi-account abuse.
