// ============================================================================
// LINKEDIN ACCOUNT VERIFICATION MODULE
// ============================================================================
// This module handles LinkedIn account verification to ensure users
// can only post from the LinkedIn account they registered with
// ============================================================================

console.log('🔐 LinkedIn Verification Module Loaded');

window.linkedBotVerificationLoaded = true;

// ============================================================================
// GET LOGGED-IN LINKEDIN ACCOUNT
// ============================================================================

/**
 * Extracts the public identifier of the currently logged-in LinkedIn user
 * Returns: "aryan-bhatnagar" or null if not logged in
 */
async function getLoggedInLinkedInId() {
  try {
    // Method 1: Voyager API (most reliable if it works)
    try {
      const response = await fetch("https://www.linkedin.com/voyager/api/me", {
        credentials: "include",
        headers: {
          "accept": "application/vnd.linkedin.normalized+json+2.1",
          "csrf-token": getCsrfToken()
        }
      });

      if (response.ok) {
        const data = await response.json();
        
        if (data && data.miniProfile && data.miniProfile.publicIdentifier) {
          return data.miniProfile.publicIdentifier;
        }
        
        if (data && data.publicIdentifier) {
          return data.publicIdentifier;
        }
      }
    } catch (error) {
      console.log('⚠️ Voyager API failed, trying alternate methods');
    }

    // Method 2: Check current page URL if on profile page
    try {
      const currentUrl = window.location.href;
      const profileMatch = currentUrl.match(/linkedin\.com\/in\/([^\/\?#]+)/);
      if (profileMatch && profileMatch[1]) {
        // Verify this is the logged-in user by checking if edit button exists
        const editButton = document.querySelector('[data-test-edit-profile-button]') ||
                          document.querySelector('button[aria-label*="Edit"]') ||
                          document.querySelector('button[aria-label*="edit"]');
        
        if (editButton) {
          return profileMatch[1];
        }
      }
    } catch (error) {
      console.log('⚠️ Profile URL check failed');
    }

    // Method 3: Extract from navigation "Me" menu
    try {
      const meButton = document.querySelector('[aria-label*="Me"]') ||
                      document.querySelector('button[id*="ember"]') ||
                      document.querySelector('[data-control-name="identity_welcome_message"]');
      
      if (meButton) {
        const container = meButton.closest('nav') || meButton.closest('header') || document;
        const profileLinks = container.querySelectorAll('a[href*="/in/"]');
        
        for (const link of profileLinks) {
          const href = link.getAttribute('href');
          const match = href.match(/\/in\/([^\/\?#]+)/);
          if (match && match[1]) {
            return match[1];
          }
        }
      }
    } catch (error) {
      console.log('⚠️ Me menu check failed');
    }

    // Method 4: Search all profile links in navigation/header
    try {
      const navElements = [
        ...document.querySelectorAll('nav a[href*="/in/"]'),
        ...document.querySelectorAll('header a[href*="/in/"]'),
        ...document.querySelectorAll('[class*="global-nav"] a[href*="/in/"]'),
        ...document.querySelectorAll('[class*="me-"] a[href*="/in/"]'),
        ...document.querySelectorAll('[data-control-name*="identity"] a[href*="/in/"]')
      ];
      
      for (const link of navElements) {
        const href = link.getAttribute('href');
        const match = href.match(/\/in\/([^\/\?#]+)/);
        
        if (match && match[1]) {
          return match[1];
        }
      }
    } catch (error) {
      console.log('⚠️ Navigation links check failed');
    }

    // Method 5: Check localStorage for profile data
    try {
      const keys = Object.keys(localStorage);
      for (const key of keys) {
        if (key.includes('profile') || key.includes('user') || key.includes('member')) {
          try {
            const data = JSON.parse(localStorage.getItem(key));
            if (data && data.publicIdentifier) {
              return data.publicIdentifier;
            }
          } catch (e) {
            // Not JSON, skip
          }
        }
      }
    } catch (error) {
      console.log('⚠️ localStorage check failed');
    }

    // Method 6: Look for any element with publicIdentifier data attribute
    try {
      const elements = document.querySelectorAll('[data-public-identifier]');
      if (elements.length > 0) {
        const id = elements[0].getAttribute('data-public-identifier');
        if (id) {
          return id;
        }
      }
    } catch (error) {
      console.log('⚠️ Data attribute check failed');
    }
  } catch (error) {
    console.error('❌ Failed to extract LinkedIn ID from page:', error);
  }

  // Method 7: Check meta tags
  try {
    const metaTag = document.querySelector('meta[property="profile:username"]');
    if (metaTag) {
      return metaTag.getAttribute('content');
    }
  } catch (error) {
    console.log('⚠️ Meta tag method failed');
  }

  return null;
}

/**
 * Get CSRF token from cookies (required for Voyager API)
 */
function getCsrfToken() {
  const cookies = document.cookie.split(';');
  for (const cookie of cookies) {
    const [name, value] = cookie.trim().split('=');
    if (name === 'JSESSIONID') {
      return value.replace(/"/g, '');
    }
  }
  return '';
}

// ============================================================================
// VERIFICATION STATUS STORAGE
// ============================================================================

/**
 * Store verified LinkedIn account in extension storage
 */
async function storeVerifiedAccount(linkedinId) {
  try {
    await chrome.storage.local.set({
      verifiedLinkedInId: linkedinId,
      verificationTimestamp: Date.now()
    });
    console.log('✅ Verified LinkedIn account stored:', linkedinId);
    return true;
  } catch (error) {
    console.error('❌ Failed to store verification:', error);
    return false;
  }
}

/**
 * Get stored verified LinkedIn account
 */
async function getVerifiedAccount() {
  try {
    const result = await chrome.storage.local.get(['verifiedLinkedInId', 'verificationTimestamp']);
    return {
      linkedinId: result.verifiedLinkedInId || null,
      timestamp: result.verificationTimestamp || null
    };
  } catch (error) {
    console.error('❌ Failed to get verification:', error);
    return { linkedinId: null, timestamp: null };
  }
}

/**
 * Clear verification (logout)
 */
async function clearVerification() {
  try {
    await chrome.storage.local.remove(['verifiedLinkedInId', 'verificationTimestamp']);
    console.log('🔓 Verification cleared');
    return true;
  } catch (error) {
    console.error('❌ Failed to clear verification:', error);
    return false;
  }
}

// ============================================================================
// ACCOUNT VERIFICATION CHECK
// ============================================================================

/**
 * Verify current LinkedIn account matches verified account
 * Returns: { valid: boolean, currentId: string, verifiedId: string, error: string }
 */
async function verifyLinkedInAccount() {
  console.log('🔍 Checking LinkedIn account...');
  
  // Get currently logged-in LinkedIn account
  const currentId = await getLoggedInLinkedInId();
  
  if (!currentId) {
    return {
      valid: false,
      currentId: null,
      verifiedId: null,
      error: 'NOT_LOGGED_IN',
      message: 'You are not logged into LinkedIn. Please log in first.'
    };
  }
  
  console.log('📋 Current LinkedIn account:', currentId);
  
  // Get verified account from storage
  const verified = await getVerifiedAccount();
  
  if (!verified.linkedinId) {
    return {
      valid: false,
      currentId: currentId,
      verifiedId: null,
      error: 'NOT_VERIFIED',
      message: 'LinkedIn account not verified. Please verify your account first.'
    };
  }
  
  console.log('📋 Verified LinkedIn account:', verified.linkedinId);
  
  // Compare accounts
  if (currentId !== verified.linkedinId) {
    return {
      valid: false,
      currentId: currentId,
      verifiedId: verified.linkedinId,
      error: 'ACCOUNT_MISMATCH',
      message: `You are logged into a different LinkedIn account. Expected: ${verified.linkedinId}, Found: ${currentId}`
    };
  }
  
  // All good!
  return {
    valid: true,
    currentId: currentId,
    verifiedId: verified.linkedinId,
    error: null,
    message: 'LinkedIn account verified successfully!'
  };
}

// ============================================================================
// EXPORT FUNCTIONS
// ============================================================================

// Make functions available globally for other scripts
window.LinkedBotVerification = {
  getLoggedInLinkedInId,
  storeVerifiedAccount,
  getVerifiedAccount,
  clearVerification,
  verifyLinkedInAccount
};

console.log('✅ LinkedIn Verification Module Ready');
