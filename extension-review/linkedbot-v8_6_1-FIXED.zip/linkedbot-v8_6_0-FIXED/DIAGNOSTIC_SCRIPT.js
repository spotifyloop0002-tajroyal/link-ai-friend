// ============================================================================
// LINKEDIN ANALYTICS DIAGNOSTIC SCRIPT
// ============================================================================
// Paste this into the console on a LinkedIn post page to test scraping
// ============================================================================

(function() {
  console.clear();
  console.log('🔍 LINKEDIN ANALYTICS DIAGNOSTIC TOOL');
  console.log('=====================================\n');
  
  // Helper function
  function parseCount(text) {
    if (!text) return 0;
    const cleaned = text.replace(/[^0-9KMBkmb.]/g, '');
    if (!cleaned) return 0;
    const upper = cleaned.toUpperCase();
    if (upper.includes('K')) return Math.round(parseFloat(upper) * 1000);
    if (upper.includes('M')) return Math.round(parseFloat(upper) * 1000000);
    if (upper.includes('B')) return Math.round(parseFloat(upper) * 1000000000);
    return parseInt(cleaned) || 0;
  }
  
  // ========================================================================
  // 1. SEARCH FOR IMPRESSIONS
  // ========================================================================
  console.log('1️⃣ SEARCHING FOR IMPRESSIONS/VIEWS...\n');
  
  let impressionsFound = false;
  let impressionsCount = 0;
  
  // Method 1: Search all spans for "impression" text
  console.log('   Method 1: Text search in all <span> elements');
  const allSpans = document.querySelectorAll('span');
  for (const span of allSpans) {
    const text = span.textContent.trim().toLowerCase();
    if (text.includes('impression')) {
      const count = parseCount(span.textContent);
      console.log('   ✅ FOUND:', span.textContent.trim());
      console.log('   📍 Element:', span);
      console.log('   🔢 Parsed count:', count);
      console.log('   📦 Classes:', span.className);
      impressionsFound = true;
      impressionsCount = count;
      break;
    }
  }
  
  if (!impressionsFound) {
    console.log('   ❌ No impressions found via text search');
  }
  
  console.log('\n   Method 2: Search by aria-label');
  const ariaImpressions = document.querySelectorAll('[aria-label*="impression" i]');
  if (ariaImpressions.length > 0) {
    ariaImpressions.forEach((el, i) => {
      const label = el.getAttribute('aria-label');
      const count = parseCount(label);
      console.log(`   ✅ Element ${i+1}:`, label);
      console.log('   🔢 Parsed count:', count);
      if (count > impressionsCount) {
        impressionsCount = count;
        impressionsFound = true;
      }
    });
  } else {
    console.log('   ❌ No elements with aria-label containing "impression"');
  }
  
  console.log('\n   Method 3: Search by class name');
  const classImpressions = document.querySelectorAll('[class*="impression" i]');
  if (classImpressions.length > 0) {
    console.log(`   ℹ️ Found ${classImpressions.length} elements with "impression" in class`);
    classImpressions.forEach((el, i) => {
      if (i < 3) { // Show first 3
        console.log(`   📍 Element ${i+1}:`, el.textContent.trim().substring(0, 50));
        console.log('   📦 Classes:', el.className);
      }
    });
  } else {
    console.log('   ❌ No elements with class containing "impression"');
  }
  
  console.log('\n   📊 IMPRESSIONS RESULT:', impressionsFound ? `${impressionsCount} impressions` : 'NOT FOUND');
  
  // ========================================================================
  // 2. SEARCH FOR LIKES/REACTIONS
  // ========================================================================
  console.log('\n\n2️⃣ SEARCHING FOR LIKES/REACTIONS...\n');
  
  let likesFound = false;
  let likesCount = 0;
  
  // Method 1: Reaction buttons
  console.log('   Method 1: Reaction buttons');
  const reactionButtons = document.querySelectorAll('button[aria-label*="reaction" i]');
  if (reactionButtons.length > 0) {
    reactionButtons.forEach((btn, i) => {
      const label = btn.getAttribute('aria-label');
      const count = parseCount(label);
      console.log(`   ✅ Button ${i+1}:`, label);
      console.log('   🔢 Parsed count:', count);
      if (count > likesCount) {
        likesCount = count;
        likesFound = true;
      }
    });
  } else {
    console.log('   ❌ No reaction buttons found');
  }
  
  // Method 2: Social counts
  console.log('\n   Method 2: Social counts elements');
  const socialCounts = document.querySelectorAll('.social-details-social-counts__reactions, .social-details-social-counts__social-proof-text');
  if (socialCounts.length > 0) {
    socialCounts.forEach((el, i) => {
      console.log(`   ✅ Element ${i+1}:`, el.textContent.trim().substring(0, 50));
      const count = parseCount(el.textContent);
      console.log('   🔢 Parsed count:', count);
      if (count > likesCount) {
        likesCount = count;
        likesFound = true;
      }
    });
  } else {
    console.log('   ❌ No social counts elements found');
  }
  
  console.log('\n   📊 LIKES RESULT:', likesFound ? `${likesCount} likes` : 'NOT FOUND');
  
  // ========================================================================
  // 3. SEARCH FOR COMMENTS
  // ========================================================================
  console.log('\n\n3️⃣ SEARCHING FOR COMMENTS...\n');
  
  let commentsFound = false;
  let commentsCount = 0;
  
  const commentButtons = document.querySelectorAll('button[aria-label*="comment" i]');
  if (commentButtons.length > 0) {
    commentButtons.forEach((btn, i) => {
      const label = btn.getAttribute('aria-label');
      const count = parseCount(label);
      console.log(`   ✅ Button ${i+1}:`, label);
      console.log('   🔢 Parsed count:', count);
      if (count >= 0) {
        commentsCount = count;
        commentsFound = true;
      }
    });
  } else {
    console.log('   ❌ No comment buttons found');
  }
  
  console.log('\n   📊 COMMENTS RESULT:', commentsFound ? `${commentsCount} comments` : 'NOT FOUND');
  
  // ========================================================================
  // 4. SEARCH FOR REPOSTS
  // ========================================================================
  console.log('\n\n4️⃣ SEARCHING FOR REPOSTS...\n');
  
  let repostsFound = false;
  let repostsCount = 0;
  
  const repostButtons = document.querySelectorAll('button[aria-label*="repost" i]');
  if (repostButtons.length > 0) {
    repostButtons.forEach((btn, i) => {
      const label = btn.getAttribute('aria-label');
      const count = parseCount(label);
      console.log(`   ✅ Button ${i+1}:`, label);
      console.log('   🔢 Parsed count:', count);
      if (count >= 0) {
        repostsCount = count;
        repostsFound = true;
      }
    });
  } else {
    console.log('   ❌ No repost buttons found');
  }
  
  console.log('\n   📊 REPOSTS RESULT:', repostsFound ? `${repostsCount} reposts` : 'NOT FOUND');
  
  // ========================================================================
  // FINAL SUMMARY
  // ========================================================================
  console.log('\n\n🎯 FINAL ANALYTICS SUMMARY');
  console.log('=====================================');
  console.log('📊 Views/Impressions:', impressionsCount);
  console.log('❤️ Likes/Reactions:', likesCount);
  console.log('💬 Comments:', commentsCount);
  console.log('🔄 Reposts:', repostsCount);
  console.log('\n');
  
  // Return data
  const results = {
    views: impressionsCount,
    likes: likesCount,
    comments: commentsCount,
    reposts: repostsCount,
    scrapedAt: new Date().toISOString(),
    url: window.location.href
  };
  
  console.log('📋 Copy this data:');
  console.log(JSON.stringify(results, null, 2));
  
  return results;
})();
