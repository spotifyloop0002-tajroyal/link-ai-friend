// ============================================================================
// LINKEDBOT POPUP v4.0
// ============================================================================

document.addEventListener('DOMContentLoaded', async () => {
  console.log('Popup loaded');
  
  try {
    // Get status from background
    const response = await chrome.runtime.sendMessage({ action: 'getStatus' });
    
    // Update UI
    const statusDiv = document.getElementById('status');
    const statusText = document.getElementById('statusText');
    const extensionIdSpan = document.getElementById('extensionId');
    
    if (response.connected) {
      statusDiv.className = 'status connected';
      statusText.textContent = '✅ Connected to website';
    } else {
      statusDiv.className = 'status disconnected';
      statusText.textContent = '⚠️ Not connected';
    }
    
    extensionIdSpan.textContent = response.extensionId || 'Unknown';
    
    // Get queue info
    const storage = await chrome.storage.local.get('post_queue');
    const queue = storage.post_queue || [];
    
    document.getElementById('queueLength').textContent = queue.length;
    
    if (queue.length > 0) {
      const sortedQueue = queue.sort((a, b) => 
        new Date(a.scheduledTime) - new Date(b.scheduledTime)
      );
      const nextPost = sortedQueue[0];
      const nextTime = new Date(nextPost.scheduledTime);
      document.getElementById('nextPost').textContent = nextTime.toLocaleString();
    } else {
      document.getElementById('nextPost').textContent = 'None scheduled';
    }
    
  } catch (error) {
    console.error('Error loading popup:', error);
    document.getElementById('statusText').textContent = '❌ Error: ' + error.message;
  }
});
