// ============================================================================
// LINKEDBOT WEBAPP CONTENT SCRIPT v4.0 - CLEAN & SIMPLE
// ============================================================================
// Listens to website messages and forwards to extension background
// ============================================================================

console.log('🌐 LinkedBot webapp content script loaded v4.0');

let extensionContextValid = true;

// ============================================================================
// CONTEXT VALIDATION
// ============================================================================

function checkExtensionContext() {
  try {
    const id = chrome.runtime?.id;
    return !!id;
  } catch (error) {
    return false;
  }
}

function notifyContextInvalidated() {
  if (!extensionContextValid) return;
  
  extensionContextValid = false;
  console.error('🔴 Extension reloaded - page refresh required');
  
  window.postMessage({
    type: 'EXTENSION_CONTEXT_INVALIDATED',
    message: 'Extension was reloaded. Please refresh the page.',
    requiresRefresh: true
  }, '*');
}

// ============================================================================
// SAFE MESSAGE SENDING
// ============================================================================

async function safeSendMessage(message) {
  if (!checkExtensionContext()) {
    notifyContextInvalidated();
    return { 
      success: false, 
      error: 'Extension reloaded. Refresh page.',
      requiresRefresh: true
    };
  }

  try {
    // Wake up service worker
    if (message.action !== 'wakeUp') {
      try {
        await chrome.runtime.sendMessage({ action: 'wakeUp' });
        await new Promise(resolve => setTimeout(resolve, 50));
      } catch (wakeError) {
        // Ignore wake errors
      }
    }

    if (!checkExtensionContext()) {
      notifyContextInvalidated();
      return { success: false, error: 'Context lost', requiresRefresh: true };
    }

    const response = await chrome.runtime.sendMessage(message);
    return { success: true, data: response };
    
  } catch (error) {
    if (error.message.includes('Extension context') || !checkExtensionContext()) {
      notifyContextInvalidated();
      return { success: false, error: 'Extension reloaded', requiresRefresh: true };
    }
    
    return { success: false, error: error.message };
  }
}

// ============================================================================
// LISTEN FOR MESSAGES FROM EXTENSION
// ============================================================================

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'extensionEvent') {
    console.log('📨 Extension event:', request.event);
    
    window.postMessage({
      type: 'EXTENSION_EVENT',
      event: request.event,
      data: request.data
    }, '*');
    
    sendResponse({ success: true });
  }
  return true;
});

// ============================================================================
// LISTEN FOR MESSAGES FROM WEBPAGE
// ============================================================================

window.addEventListener('message', async (event) => {
  // Only accept messages from same window
  if (event.source !== window) return;
  
  const message = event.data;

  // =========================================================================
  // CONNECTION
  // =========================================================================
  
  if (message.type === 'CONNECT_EXTENSION') {
    console.log('🔌 Connecting extension...');
    
    const result = await safeSendMessage({ action: 'getExtensionId' });
    
    if (result.success) {
      window.postMessage({
        type: 'EXTENSION_CONNECTED',
        extensionId: result.data.extensionId
      }, '*');
      
      await safeSendMessage({ action: 'setConnected' });
      console.log('✅ Extension connected');
    } else {
      window.postMessage({
        type: 'EXTENSION_CONNECTED',
        extensionId: null,
        error: result.error,
        requiresRefresh: result.requiresRefresh
      }, '*');
      console.error('❌ Connection failed:', result.error);
    }
    return;
  }

  // =========================================================================
  // DISCONNECT
  // =========================================================================
  
  if (message.type === 'DISCONNECT_EXTENSION') {
    await safeSendMessage({ action: 'setDisconnected' });
    window.postMessage({ 
      type: 'EXTENSION_DISCONNECTED', 
      reason: 'manual' 
    }, '*');
    return;
  }

  // =========================================================================
  // CHECK STATUS
  // =========================================================================
  
  if (message.type === 'CHECK_EXTENSION') {
    const result = await safeSendMessage({ action: 'getStatus' });
    
    window.postMessage({
      type: 'EXTENSION_STATUS',
      connected: result.success ? result.data.connected : false,
      extensionId: result.success ? result.data.extensionId : null,
      error: result.success ? null : result.error,
      requiresRefresh: result.requiresRefresh
    }, '*');
    return;
  }

  // =========================================================================
  // SCHEDULE POSTS
  // =========================================================================
  
  if (message.type === 'SCHEDULE_POSTS') {
    console.log('📥 Scheduling posts:', message.posts?.length || 0);
    
    const result = await safeSendMessage({
      action: 'schedulePosts',
      posts: message.posts
    });

    window.postMessage({
      type: 'SCHEDULE_RESULT',
      success: result.success,
      queueLength: result.success ? result.data.queueLength : 0,
      nextScheduled: result.success ? result.data.nextScheduled : null,
      message: result.success ? result.data.message : null,
      error: result.success ? null : result.error,
      requiresRefresh: result.requiresRefresh
    }, '*');
    return;
  }

  // =========================================================================
  // POST NOW
  // =========================================================================
  
  if (message.type === 'POST_NOW') {
    console.log('📤 Posting immediately:', message.post?.id);
    
    const result = await safeSendMessage({
      action: 'postNow',
      post: message.post
    });

    window.postMessage({
      type: 'POST_RESULT',
      success: result.success,
      postId: message.post.id,
      error: result.success ? null : result.error,
      requiresRefresh: result.requiresRefresh
    }, '*');
    return;
  }
});

// ============================================================================
// AUTO-CHECK ON LOAD
// ============================================================================

window.addEventListener('load', () => {
  setTimeout(() => {
    if (checkExtensionContext()) {
      console.log('🔍 Auto-checking extension status...');
      window.postMessage({ type: 'CHECK_EXTENSION' }, '*');
    } else {
      notifyContextInvalidated();
    }
  }, 1000);
});

console.log('✅ Webapp content script ready v4.0');
