# LOVABLE PROMPT: Add LinkedIn Post URL Display

## What Changed in Extension

The Chrome extension now **captures and returns the LinkedIn post URL** after publishing.

### Extension Response Format (NEW)

When a post is published, the extension now returns:

```javascript
{
  type: 'POST_RESULT',
  success: true,
  postId: 'post_123',
  linkedinUrl: 'https://www.linkedin.com/feed/update/urn:li:activity:1234567890/',
  postUrl: 'https://www.linkedin.com/feed/update/urn:li:activity:1234567890/', // Same as linkedinUrl
  message: 'Posted successfully'
}
```

## Required Changes in Your Website

### 1. Update Message Listener to Capture URL

**Find** your message listener code (probably in a hook or component):

```javascript
window.addEventListener('message', (event) => {
  if (event.data.type === 'POST_RESULT') {
    if (event.data.success) {
      // OLD: Just show success
      toast.success('Posted to LinkedIn!');
      
      // NEW: Capture the URL
      const linkedinUrl = event.data.linkedinUrl || event.data.postUrl;
      
      if (linkedinUrl) {
        // Save URL to database
        updatePostWithLinkedinUrl(event.data.postId, linkedinUrl);
        
        // Show success with URL
        toast.success('Posted to LinkedIn!');
      }
    }
  }
});
```

### 2. Create Function to Save LinkedIn URL to Database

```javascript
async function updatePostWithLinkedinUrl(postId, linkedinUrl) {
  try {
    const { error } = await supabase
      .from('posts')
      .update({ 
        linkedin_url: linkedinUrl,
        status: 'published',
        published_at: new Date().toISOString()
      })
      .eq('id', postId);
    
    if (error) throw error;
    
    console.log('✅ LinkedIn URL saved:', linkedinUrl);
  } catch (error) {
    console.error('Failed to save LinkedIn URL:', error);
  }
}
```

### 3. Update Database Schema (if needed)

**Check if your `posts` table has this column:**

```sql
ALTER TABLE posts 
ADD COLUMN IF NOT EXISTS linkedin_url TEXT;
```

If using Supabase Studio:
1. Go to Table Editor
2. Select `posts` table
3. Add new column: `linkedin_url` (type: `text`, nullable: `true`)

### 4. Display LinkedIn URL in UI

**In your Post component** (where you show the 3-dot menu):

```tsx
// In the Generated Posts section
{post.linkedin_url && (
  <a 
    href={post.linkedin_url}
    target="_blank"
    rel="noopener noreferrer"
    className="text-blue-600 hover:text-blue-800 text-sm flex items-center gap-1"
  >
    <ExternalLink className="w-4 h-4" />
    View on LinkedIn
  </a>
)}
```

**OR in the dropdown menu (3-dot area you showed):**

```tsx
<DropdownMenuItem asChild>
  {post.linkedin_url ? (
    <a 
      href={post.linkedin_url}
      target="_blank"
      rel="noopener noreferrer"
      className="flex items-center gap-2"
    >
      <ExternalLink className="w-4 h-4" />
      View on LinkedIn
    </a>
  ) : (
    <span className="text-gray-400 flex items-center gap-2">
      <ExternalLink className="w-4 h-4" />
      Not posted yet
    </span>
  )}
</DropdownMenuItem>
```

### 5. Complete Integration Example

Here's a complete example of the flow:

```typescript
// Hook or component handling extension messages
useEffect(() => {
  const handleExtensionMessage = async (event: MessageEvent) => {
    if (event.data.type === 'POST_RESULT') {
      const { success, postId, linkedinUrl, postUrl, error } = event.data;
      
      if (success) {
        const url = linkedinUrl || postUrl;
        
        // Update local state immediately
        setPosts(prev => prev.map(p => 
          p.id === postId 
            ? { ...p, linkedin_url: url, status: 'published' }
            : p
        ));
        
        // Save to database
        if (url) {
          try {
            await supabase
              .from('posts')
              .update({ 
                linkedin_url: url,
                status: 'published',
                published_at: new Date().toISOString()
              })
              .eq('id', postId);
            
            toast.success('Posted to LinkedIn! 🎉');
          } catch (err) {
            console.error('Failed to save URL:', err);
            toast.success('Posted to LinkedIn (URL not saved)');
          }
        }
      } else {
        toast.error(`Failed: ${error}`);
        
        // Update status to failed
        await supabase
          .from('posts')
          .update({ status: 'failed' })
          .eq('id', postId);
      }
    }
  };
  
  window.addEventListener('message', handleExtensionMessage);
  return () => window.removeEventListener('message', handleExtensionMessage);
}, []);
```

### 6. UI Components to Add

**Import icon:**
```tsx
import { ExternalLink } from 'lucide-react';
```

**In your Post Card:**
```tsx
<div className="flex items-center justify-between">
  <div className="flex items-center gap-2">
    <Badge variant={post.status === 'published' ? 'success' : 'warning'}>
      {post.status}
    </Badge>
    
    {post.linkedin_url && (
      <Button
        variant="ghost"
        size="sm"
        asChild
      >
        <a 
          href={post.linkedin_url}
          target="_blank"
          rel="noopener noreferrer"
        >
          <ExternalLink className="w-4 h-4 mr-2" />
          View Post
        </a>
      </Button>
    )}
  </div>
  
  {/* Your 3-dot menu */}
  <DropdownMenu>
    {/* ... */}
  </DropdownMenu>
</div>
```

## Testing Checklist

1. ✅ Post a new post from your website
2. ✅ Check console for `linkedinUrl` in the response
3. ✅ Verify URL is saved to database
4. ✅ Check that "View on LinkedIn" link appears
5. ✅ Click link and verify it opens the correct post
6. ✅ Test with scheduled posts (should save URL when they fire)

## Expected Flow

```
User clicks "Post Now"
    ↓
Website sends message to extension
    ↓
Extension posts to LinkedIn
    ↓
Extension captures post URL
    ↓
Extension sends back: { success: true, linkedinUrl: '...' }
    ↓
Website receives message
    ↓
Website updates database with linkedin_url
    ↓
Website shows "View on LinkedIn" link
    ↓
User clicks link → Opens LinkedIn post ✅
```

## Notes

- The URL may sometimes be `null` if extraction fails (rare)
- Always check for URL presence before showing link
- The URL format is: `https://www.linkedin.com/feed/update/urn:li:activity:{ID}/`
- Store as plain text in database
- Add index on `linkedin_url` if you plan to search by it

## Alternative: If URL Extraction Fails

If the extension can't extract the URL automatically, you can:

1. **Show a success message** without the URL
2. **Ask user to copy** the URL manually from LinkedIn
3. **Add a button** to manually enter/update the LinkedIn URL

Example fallback UI:
```tsx
{post.status === 'published' && !post.linkedin_url && (
  <Button
    variant="outline"
    size="sm"
    onClick={() => setShowUrlInput(true)}
  >
    Add LinkedIn URL
  </Button>
)}
```

That's it! The extension now captures and returns LinkedIn post URLs. 🎉
