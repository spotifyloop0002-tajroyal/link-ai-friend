// ============================================================================
// LINKEDBOT BACKGROUND v4.0 - CLEAN & SIMPLE
// ============================================================================
// CORE PRINCIPLE: Extension owns posting. Website sends instructions.
// NO user_id validation. NO Supabase. NO auth blocking.
// ============================================================================

console.log('🚀 LinkedBot v4.0 Background Service Worker Started');

// ============================================================================
// INITIALIZATION
// ============================================================================

chrome.runtime.onInstalled.addListener(async () => {
  console.log('✅ LinkedBot v4.0 installed');
  
  await chrome.storage.local.set({ 
    extensionId: chrome.runtime.id,
    isConnected: false
  });
  
  // Create persistent heartbeat
  await chrome.alarms.create('heartbeat', { 
    periodInMinutes: 1 
  });
  
  console.log('✅ Extension ready - ID:', chrome.runtime.id);
});

// ============================================================================
// MESSAGE HANDLER
// ============================================================================

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('📨 Message received:', request.action);
  
  // Wake up ping
  if (request.action === 'wakeUp') {
    sendResponse({ success: true, awake: true });
    return true;
  }
  
  // Get extension ID
  if (request.action === 'getExtensionId') {
    sendResponse({ 
      success: true, 
      extensionId: chrome.runtime.id 
    });
    return true;
  }
  
  // Set connected status
  if (request.action === 'setConnected') {
    chrome.storage.local.set({ isConnected: true })
      .then(() => sendResponse({ success: true }));
    return true;
  }
  
  // Set disconnected status
  if (request.action === 'setDisconnected') {
    chrome.storage.local.set({ isConnected: false })
      .then(() => sendResponse({ success: true }));
    return true;
  }
  
  // Get status
  if (request.action === 'getStatus') {
    chrome.storage.local.get(['isConnected'])
      .then((data) => {
        sendResponse({
          connected: data.isConnected || false,
          extensionId: chrome.runtime.id
        });
      });
    return true;
  }
  
  // Schedule posts
  if (request.action === 'schedulePosts') {
    handleSchedulePosts(request.posts)
      .then(result => sendResponse(result))
      .catch(error => sendResponse({ 
        success: false, 
        error: error.message 
      }));
    return true;
  }
  
  // Post immediately
  if (request.action === 'postNow') {
    handlePostNow(request.post)
      .then(result => sendResponse(result))
      .catch(error => sendResponse({ 
        success: false, 
        error: error.message 
      }));
    return true;
  }
  
  return true;
});

// ============================================================================
// ALARM HANDLER - Fires scheduled posts
// ============================================================================

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === 'heartbeat') {
    // Silent heartbeat to keep service worker alive
    return;
  }
  
  if (alarm.name.startsWith('post_')) {
    const postId = alarm.name.replace('post_', '');
    console.log(`⏰ Scheduled post firing: ${postId}`);
    
    const result = await chrome.storage.local.get('post_queue');
    const queue = result.post_queue || [];
    
    const postIndex = queue.findIndex(p => p.id === postId);
    if (postIndex === -1) {
      console.error('❌ Post not found in queue:', postId);
      return;
    }
    
    const post = queue[postIndex];
    
    // Post to LinkedIn
    try {
      await postToLinkedIn(post);
      
      // Remove from queue
      queue.splice(postIndex, 1);
      await chrome.storage.local.set({ post_queue: queue });
      
      console.log('✅ Scheduled post completed:', postId);
      
      // Notify webapp
      notifyWebapp('postCompleted', { 
        postId: post.id,
        success: true 
      });
    } catch (error) {
      console.error('❌ Scheduled post failed:', error);
      
      // Update status but keep in queue
      post.status = 'failed';
      post.error = error.message;
      await chrome.storage.local.set({ post_queue: queue });
      
      // Notify webapp
      notifyWebapp('postFailed', { 
        postId: post.id,
        error: error.message 
      });
    }
  }
});

// ============================================================================
// SCHEDULE POSTS
// ============================================================================

async function handleSchedulePosts(posts) {
  console.log(`📅 Scheduling ${posts.length} posts`);
  
  if (!posts || posts.length === 0) {
    return { 
      success: false, 
      error: 'No posts provided' 
    };
  }
  
  const result = await chrome.storage.local.get('post_queue');
  const existingQueue = result.post_queue || [];
  
  const scheduledPosts = [];
  
  for (const post of posts) {
    // Accept either scheduleTime or scheduled_for
    const scheduleTime = post.scheduleTime || post.scheduled_for;
    
    if (!scheduleTime) {
      console.warn('⚠️ Post missing schedule time, skipping:', post.id);
      continue;
    }
    
    const scheduledDate = new Date(scheduleTime);
    
    if (isNaN(scheduledDate.getTime())) {
      console.error('❌ Invalid date for post:', post.id, scheduleTime);
      continue;
    }
    
    const queuedPost = {
      id: post.id,
      content: post.content,
      imageUrl: post.photo_url || post.imageUrl,
      scheduledTime: scheduledDate.toISOString(),
      status: 'scheduled'
    };
    
    scheduledPosts.push(queuedPost);
    
    // Create alarm
    const alarmName = `post_${post.id}`;
    await chrome.alarms.create(alarmName, { 
      when: scheduledDate.getTime() 
    });
    
    console.log(`✅ Scheduled post ${post.id} for ${scheduledDate.toLocaleString()}`);
  }
  
  const updatedQueue = [...existingQueue, ...scheduledPosts];
  await chrome.storage.local.set({ post_queue: updatedQueue });
  
  const nextPost = updatedQueue
    .sort((a, b) => new Date(a.scheduledTime) - new Date(b.scheduledTime))[0];
  
  console.log('═══════════════════════════════════════');
  console.log('✅ SCHEDULING COMPLETE');
  console.log('Posts scheduled:', scheduledPosts.length);
  console.log('Total in queue:', updatedQueue.length);
  console.log('Next post:', nextPost ? nextPost.scheduledTime : 'none');
  console.log('═══════════════════════════════════════');
  
  return {
    success: true,
    queueLength: updatedQueue.length,
    nextScheduled: nextPost ? nextPost.scheduledTime : null,
    message: `${scheduledPosts.length} posts scheduled`
  };
}

// ============================================================================
// POST NOW
// ============================================================================

async function handlePostNow(post) {
  console.log('📤 Posting immediately:', post.id);
  
  if (!post || !post.content) {
    return { 
      success: false, 
      error: 'Invalid post data' 
    };
  }
  
  try {
    const result = await postToLinkedIn(post);
    
    console.log('✅ Post completed:', post.id);
    console.log('🔗 Post URL:', result.postUrl || 'not captured');
    
    return {
      success: true,
      postId: post.id,
      linkedinUrl: result.postUrl || null,
      postUrl: result.postUrl || null,
      message: 'Posted successfully'
    };
  } catch (error) {
    console.error('❌ Post failed:', error);
    return {
      success: false,
      error: error.message
    };
  }
}

// ============================================================================
// POST TO LINKEDIN
// ============================================================================

async function postToLinkedIn(post) {
  console.log('📝 Creating LinkedIn post...');
  
  // Find or create LinkedIn tab
  let linkedinTab = await findLinkedInTab();
  
  if (!linkedinTab) {
    console.log('🔗 Opening LinkedIn...');
    linkedinTab = await chrome.tabs.create({
      url: 'https://www.linkedin.com/feed/',
      active: true
    });
    await waitForTabLoad(linkedinTab.id);
    await sleep(3000); // Give LinkedIn time to fully load
  } else {
    console.log('✅ Using existing LinkedIn tab');
    await chrome.tabs.update(linkedinTab.id, { active: true });
    await sleep(1000);
  }
  
  // Ensure content script is loaded
  await ensureContentScriptLoaded(linkedinTab.id);
  
  // Send post content to LinkedIn content script
  const result = await sendMessageToTab(linkedinTab.id, {
    action: 'fillPost',
    content: post.content,
    imageUrl: post.imageUrl,
    autoPost: true // Actually click the Post button
  });
  
  if (!result || !result.success) {
    throw new Error(result?.error || 'Failed to create post on LinkedIn');
  }
  
  console.log('✅ Post created on LinkedIn');
  
  return {
    success: true,
    postId: post.id,
    postUrl: result.postUrl || result.linkedinUrl || null
  };
}

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

async function findLinkedInTab() {
  const tabs = await chrome.tabs.query({});
  return tabs.find(tab => 
    tab.url && tab.url.includes('linkedin.com')
  );
}

async function waitForTabLoad(tabId) {
  return new Promise((resolve) => {
    const listener = (changedTabId, changeInfo) => {
      if (changedTabId === tabId && changeInfo.status === 'complete') {
        chrome.tabs.onUpdated.removeListener(listener);
        resolve();
      }
    };
    chrome.tabs.onUpdated.addListener(listener);
  });
}

async function ensureContentScriptLoaded(tabId) {
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      func: () => window.linkedBotContentLoaded || false
    });
  } catch (error) {
    // If script not loaded, inject it
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ['linkedin-content.js']
    });
  }
}

async function sendMessageToTab(tabId, message) {
  return new Promise((resolve, reject) => {
    chrome.tabs.sendMessage(tabId, message, (response) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else {
        resolve(response);
      }
    });
  });
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function notifyWebapp(event, data) {
  try {
    const tabs = await chrome.tabs.query({});
    const webappTabs = tabs.filter(tab => 
      tab.url && tab.url.includes('linkedbot4.lovable.app')
    );
    
    for (const tab of webappTabs) {
      chrome.tabs.sendMessage(tab.id, {
        action: 'extensionEvent',
        event: event,
        data: data
      }).catch(() => {
        // Tab might not have content script, ignore
      });
    }
  } catch (error) {
    console.log('Could not notify webapp:', error.message);
  }
}

console.log('✅ Background service worker ready');
