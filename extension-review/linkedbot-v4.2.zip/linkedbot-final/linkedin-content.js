// ============================================================================
// LINKEDBOT LINKEDIN CONTENT SCRIPT v4.2 - WITH POST URL CAPTURE
// ============================================================================
// Handles DOM interactions on LinkedIn - filling posts and capturing URLs
// ============================================================================

console.log('🔗 LinkedBot LinkedIn content script loaded v4.2 - URL CAPTURE');

// Mark as loaded
window.linkedBotContentLoaded = true;

// ============================================================================
// MESSAGE LISTENER
// ============================================================================

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('📨 LinkedIn content received:', request.action);
  
  if (request.action === 'fillPost') {
    fillAndPostToLinkedIn(request)
      .then(result => sendResponse(result))
      .catch(error => sendResponse({ 
        success: false, 
        error: error.message 
      }));
    return true;
  }
  
  return true;
});

// ============================================================================
// FILL AND POST TO LINKEDIN
// ============================================================================

async function fillAndPostToLinkedIn(request) {
  console.log('📝 Starting post creation on LinkedIn...');
  
  try {
    // Step 1: Click "Start a post" button to open the composer
    console.log('🔍 Looking for Start a post button...');
    
    let startPostButton = null;
    
    // Try multiple strategies to find the button
    const strategies = [
      // Strategy 1: Direct text content search
      () => {
        const buttons = document.querySelectorAll('button');
        for (const btn of buttons) {
          const text = btn.textContent.trim();
          if (text === 'Start a post' || text.includes('Start a post')) {
            console.log('✅ Found via text content');
            return btn;
          }
        }
        return null;
      },
      
      // Strategy 2: Common class selectors
      () => document.querySelector('button.share-box-feed-entry__trigger'),
      
      // Strategy 3: Aria label
      () => document.querySelector('button[aria-label*="Start a post"]'),
      
      // Strategy 4: Container-based search
      () => {
        const container = document.querySelector('.share-box-feed-entry');
        if (container) {
          return container.querySelector('button');
        }
        return null;
      },
      
      // Strategy 5: Look for any button in the share creation area
      () => {
        const shareBox = document.querySelector('.share-creation-state');
        if (shareBox) {
          return shareBox.querySelector('button');
        }
        return null;
      }
    ];
    
    // Try each strategy
    for (let i = 0; i < strategies.length; i++) {
      console.log(`Trying strategy ${i + 1}...`);
      try {
        const button = strategies[i]();
        if (button) {
          startPostButton = button;
          console.log(`✅ Found button with strategy ${i + 1}`);
          break;
        }
      } catch (e) {
        console.log(`Strategy ${i + 1} failed:`, e.message);
      }
    }
    
    // If still not found, wait a bit and try again
    if (!startPostButton) {
      console.log('⏳ Button not found immediately, waiting...');
      await sleep(2000);
      
      // Try text search one more time
      const buttons = document.querySelectorAll('button');
      for (const btn of buttons) {
        const text = btn.textContent.trim();
        if (text === 'Start a post' || text.includes('Start a post')) {
          startPostButton = btn;
          console.log('✅ Found after waiting');
          break;
        }
      }
    }
    
    if (!startPostButton) {
      throw new Error('Could not find "Start a post" button. Make sure you are on LinkedIn feed page.');
    }
    
    console.log('✅ Found Start Post button, clicking...');
    startPostButton.click();
    await sleep(2000);
    
    // Step 2: Find the text editor
    console.log('🔍 Looking for editor...');
    
    let editor = null;
    const editorSelectors = [
      '.ql-editor[contenteditable="true"]',
      'div[contenteditable="true"][role="textbox"]',
      'div[data-placeholder][contenteditable="true"]',
      '.share-creation-state__text-editor'
    ];
    
    for (const selector of editorSelectors) {
      editor = await waitForElement(selector, 3000);
      if (editor) {
        console.log('✅ Found editor with selector:', selector);
        break;
      }
    }
    
    if (!editor) {
      throw new Error('Could not find post editor. The post composer may not have opened.');
    }
    
    console.log('✅ Found editor, filling content...');
    
    // Fill content
    editor.focus();
    await sleep(300);
    
    // Clear any existing content
    editor.innerHTML = '';
    
    // Insert content as paragraphs
    const paragraphs = request.content.split('\n\n');
    for (const paragraph of paragraphs) {
      if (paragraph.trim()) {
        const p = document.createElement('p');
        p.textContent = paragraph.trim();
        editor.appendChild(p);
      }
    }
    
    // Trigger input event
    editor.dispatchEvent(new Event('input', { bubbles: true }));
    editor.dispatchEvent(new Event('change', { bubbles: true }));
    await sleep(500);
    
    console.log('✅ Content filled');
    
    // Step 3: Handle image if provided
    if (request.imageUrl) {
      console.log('📷 Image provided, skipping (not implemented)');
    }
    
    // Step 4: Click Post button if autoPost is true
    if (request.autoPost) {
      console.log('🚀 Auto-posting enabled, clicking Post button...');
      await sleep(1500);
      
      // Find the Post button
      let postButton = null;
      const postButtonSelectors = [
        'button[aria-label*="Post"]',
        'button.share-actions__primary-action',
        'button[data-test-share-box-post-button]'
      ];
      
      for (const selector of postButtonSelectors) {
        postButton = await waitForElement(selector, 2000);
        if (postButton) {
          console.log('✅ Found post button with selector:', selector);
          break;
        }
      }
      
      // If not found by selector, search by text
      if (!postButton) {
        const buttons = document.querySelectorAll('button');
        for (const btn of buttons) {
          if (btn.textContent.trim() === 'Post') {
            postButton = btn;
            console.log('✅ Found post button by text');
            break;
          }
        }
      }
      
      if (!postButton) {
        throw new Error('Could not find Post button');
      }
      
      // Check if button is disabled
      if (postButton.disabled || postButton.getAttribute('aria-disabled') === 'true') {
        throw new Error('Post button is disabled');
      }
      
      console.log('✅ Clicking Post button...');
      postButton.click();
      await sleep(3000);
      
      console.log('🔍 Waiting for post to appear and extracting URL...');
      
      // Wait for the post to appear in the feed and extract URL
      const postUrl = await extractPostUrl();
      
      console.log('✅ Post published!');
      
      return {
        success: true,
        message: 'Post published',
        postUrl: postUrl || null,
        linkedinUrl: postUrl || null
      };
    } else {
      console.log('ℹ️ Auto-post disabled, content filled but not posted');
      return {
        success: true,
        message: 'Content filled',
        postUrl: null
      };
    }
    
  } catch (error) {
    console.error('❌ Post creation failed:', error);
    return {
      success: false,
      error: error.message
    };
  }
}

// ============================================================================
// EXTRACT POST URL
// ============================================================================

async function extractPostUrl() {
  console.log('🔍 Extracting post URL...');
  
  // Strategy 1: Look for the newest post (just posted)
  // Wait for the feed to update
  await sleep(2000);
  
  try {
    // Method 1: Find the most recent post in feed
    // LinkedIn shows "Post successfully deleted" message area after posting
    // The new post appears at the top of feed
    
    const feedPosts = document.querySelectorAll('[data-urn*="activity"]');
    console.log(`📊 Found ${feedPosts.length} posts in feed`);
    
    if (feedPosts.length > 0) {
      // Get the first post (most recent)
      const firstPost = feedPosts[0];
      
      // Try to find the post link
      const linkSelectors = [
        'a[href*="/posts/"]',
        'a[href*="activity-"]',
        '.feed-shared-actor__meta a',
        '.update-components-actor__meta-link'
      ];
      
      for (const selector of linkSelectors) {
        const link = firstPost.querySelector(selector);
        if (link && link.href && link.href.includes('linkedin.com')) {
          console.log('✅ Found post URL:', link.href);
          return link.href;
        }
      }
    }
    
    // Method 2: Look for "Edit post" button which appears after posting
    await sleep(1000);
    const editButtons = document.querySelectorAll('button[aria-label*="Edit post"]');
    if (editButtons.length > 0) {
      // Find the parent post container
      const postContainer = editButtons[0].closest('[data-urn]');
      if (postContainer) {
        const urn = postContainer.getAttribute('data-urn');
        if (urn) {
          // Extract activity ID from URN
          const activityMatch = urn.match(/activity:(\d+)/);
          if (activityMatch) {
            const activityId = activityMatch[1];
            const postUrl = `https://www.linkedin.com/feed/update/urn:li:activity:${activityId}/`;
            console.log('✅ Constructed post URL from URN:', postUrl);
            return postUrl;
          }
        }
      }
    }
    
    // Method 3: Look in browser navigation/history
    // Check if we can get the post URL from any recent navigation
    const recentPosts = document.querySelectorAll('article.relative time[datetime]');
    if (recentPosts.length > 0) {
      const newestPost = recentPosts[0].closest('article');
      if (newestPost) {
        const link = newestPost.querySelector('a[href*="activity"]');
        if (link) {
          console.log('✅ Found post URL via article:', link.href);
          return link.href;
        }
      }
    }
    
    console.warn('⚠️ Could not extract post URL - using fallback');
    return null;
    
  } catch (error) {
    console.error('❌ Error extracting post URL:', error);
    return null;
  }
}

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

function waitForElement(selector, timeout = 5000) {
  return new Promise((resolve) => {
    const element = document.querySelector(selector);
    if (element) {
      resolve(element);
      return;
    }
    
    const observer = new MutationObserver(() => {
      const element = document.querySelector(selector);
      if (element) {
        observer.disconnect();
        resolve(element);
      }
    });
    
    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
    
    setTimeout(() => {
      observer.disconnect();
      resolve(null);
    }, timeout);
  });
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// ============================================================================
// DEBUG
// ============================================================================

console.log('📄 Page URL:', window.location.href);
setTimeout(() => {
  const buttons = document.querySelectorAll('button');
  console.log('📊 Total buttons on page:', buttons.length);
}, 2000);

console.log('✅ LinkedIn content script ready v4.2 - URL CAPTURE');
