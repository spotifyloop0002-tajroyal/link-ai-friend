// ============================================================================
// LinkedIn Content Script - COMPLETE FIXED VERSION
// ============================================================================

console.log('🔵 LinkedIn Content Script Loaded (COMPLETE FIXED)');

// ----------------------------------------------------------------------------
// MESSAGE LISTENER
// ----------------------------------------------------------------------------

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('📨 Received:', request.action);

  if (request.action === 'ping') {
    sendResponse({ success: true, message: 'Content script ready' });
    return true;
  }

  if (request.action === 'fillPost') {
    fillLinkedInPost(request)
      .then(result => sendResponse(result))
      .catch(error => {
        console.error('❌ Error:', error);
        sendResponse({ success: false, error: error.message });
      });
    return true;
  }
});

// ----------------------------------------------------------------------------
// MAIN FUNCTION - COMPLETE FIXED
// ----------------------------------------------------------------------------

async function fillLinkedInPost({ content, autoPost, hasImage, imageBase64, imageType }) {
  try {
    console.log('📝 Starting LinkedIn post flow');
    console.log('🖼️ Has image:', hasImage);

    // Ensure feed page
    if (!location.href.includes('/feed')) {
      console.log('🔄 Redirecting to feed');
      location.href = 'https://www.linkedin.com/feed/';
      await wait(6000);
    }

    window.scrollTo({ top: 0, behavior: 'smooth' });
    await wait(1000);

    // ========================================================================
    // STEP 1: FIND & CLICK "START A POST"
    // ========================================================================

    console.log('🔍 Finding "Start a post" button');

    const startPostBtn = await findStartPostButton(20000);
    if (!startPostBtn) throw new Error('"Start a post" button not found');

    await humanClick(startPostBtn);
    console.log('✅ Clicked "Start a post"');
    await wait(2500);

    // ========================================================================
    // STEP 2: UPLOAD IMAGE (IF PROVIDED)
    // ========================================================================

    if (hasImage && imageBase64) {
      console.log('📸 Starting image upload flow...');
      
      try {
        const imageButton = await findImageUploadButton(10000);
        
        if (!imageButton) {
          throw new Error('Image upload button not found');
        }

        console.log('✅ Found image button, clicking...');
        await humanClick(imageButton);
        await wait(1500);

        console.log('🔍 Finding file input...');
        const fileInput = await findFileInput(5000);
        
        if (!fileInput) {
          throw new Error('File input not found after clicking image button');
        }

        console.log('✅ Found file input, uploading image...');
        const blob = await base64ToBlob(imageBase64, imageType || 'image/png');
        const file = new File([blob], 'image.png', { type: imageType || 'image/png' });
        
        const dataTransfer = new DataTransfer();
        dataTransfer.items.add(file);
        fileInput.files = dataTransfer.files;
        
        fileInput.dispatchEvent(new Event('change', { bubbles: true }));
        
        console.log('✅ Image uploaded, waiting for editor...');
        await wait(4000);

        console.log('🔍 Looking for "Next" button in image editor...');
        const nextButton = await findNextButton(15000);
        
        if (nextButton) {
          console.log('✅ Found "Next" button, clicking...');
          await humanClick(nextButton);
          console.log('✅ Clicked "Next" button');
          await wait(3000);
        } else {
          console.warn('⚠️ "Next" button not found - checking if editor already loaded...');
          await wait(2000);
        }

        const doneButton = await findDoneButton(5000);
        if (doneButton) {
          console.log('✅ Found "Done" button, clicking...');
          await humanClick(doneButton);
          await wait(2500);
        }

        console.log('✅ Image flow complete');

      } catch (imageError) {
        console.error('❌ Image upload failed:', imageError);
        return {
          success: false,
          error: `Image upload failed: ${imageError.message}`
        };
      }
    }

    // ========================================================================
    // STEP 3: FILL TEXT CONTENT
    // ========================================================================

    console.log('🔍 Looking for text editor...');

    const editor = await waitForAnyElement([
      'div[role="textbox"][contenteditable="true"]',
      'div[contenteditable="true"][aria-label]',
      'div[contenteditable="true"]',
      'div[data-test-ql-editor]',
      'div.ql-editor',
      'div.editor-content',
      'div[contenteditable="true"][data-placeholder]'
    ], 30000);

    if (!editor) {
      console.error('❌ Post editor not found after 30s');
      throw new Error('Post editor not found');
    }

    console.log('✅ Editor found, filling content...');
    editor.focus();
    await wait(500);

    document.execCommand('selectAll', false, null);
    document.execCommand('delete', false, null);
    await wait(300);

    const lines = content.split('\n');
    for (let i = 0; i < lines.length; i++) {
      document.execCommand('insertText', false, lines[i]);
      if (i < lines.length - 1) {
        document.execCommand('insertLineBreak', false, null);
      }
    }

    triggerInputEvents(editor);
    console.log('✅ Content filled');
    await wait(1500);

    // ========================================================================
    // STEP 4: AUTO POST
    // ========================================================================

    if (autoPost) {
      console.log('🚀 Auto-post enabled, finding Post button...');
      await wait(1000);

      const postBtn = await findPostButton(20000);

      if (!postBtn) {
        console.warn('⚠️ Post button not found');
        return {
          success: true,
          message: 'Content filled. Click Post manually.',
          autoPosted: false
        };
      }

      console.log('✅ Found Post button, clicking...');
      await humanClick(postBtn);
      
      // Wait and verify post was published
      await wait(3000);
      
      const postSuccess = await verifyPostPublished();
      
      if (postSuccess) {
        console.log('✅ Post verified as published');
        return {
          success: true,
          message: 'Post published successfully' + (hasImage ? ' with image' : ''),
          autoPosted: true,
          verified: true
        };
      } else {
        console.warn('⚠️ Could not verify post publication');
        return {
          success: true,
          message: 'Post likely published' + (hasImage ? ' with image' : ''),
          autoPosted: true,
          verified: false
        };
      }
    }

    return {
      success: true,
      message: 'Post filled successfully' + (hasImage ? ' with image' : ''),
      autoPosted: false
    };

  } catch (error) {
    console.error('❌ fillLinkedInPost failed:', error);
    throw error;
  }
}

// ----------------------------------------------------------------------------
// VERIFY POST WAS PUBLISHED
// ----------------------------------------------------------------------------

async function verifyPostPublished(timeout = 10000) {
  const start = Date.now();
  
  return new Promise(resolve => {
    const interval = setInterval(() => {
      const modal = document.querySelector('[role="dialog"]');
      if (!modal) {
        clearInterval(interval);
        console.log('✅ Post dialog closed - post published');
        resolve(true);
        return;
      }
      
      const successIndicators = [
        document.querySelector('[data-test-modal-close-btn]'),
        document.querySelector('.artdeco-toast-item--success'),
        document.querySelector('[aria-label*="Post successful"]')
      ];
      
      if (successIndicators.some(el => el !== null)) {
        clearInterval(interval);
        console.log('✅ Success indicator found');
        resolve(true);
        return;
      }
      
      if (Date.now() - start > timeout) {
        clearInterval(interval);
        console.warn('⏰ Verification timeout');
        resolve(false);
      }
    }, 500);
  });
}

// ----------------------------------------------------------------------------
// IMAGE UPLOAD HELPERS
// ----------------------------------------------------------------------------

async function findImageUploadButton(timeout = 10000) {
  const start = Date.now();

  return new Promise(resolve => {
    const interval = setInterval(() => {
      const buttons = document.querySelectorAll('button');
      
      for (const btn of buttons) {
        const ariaLabel = btn.getAttribute('aria-label')?.toLowerCase() || '';
        const text = btn.innerText?.toLowerCase() || '';
        
        if (
          ariaLabel.includes('add a photo') ||
          ariaLabel.includes('add photo') ||
          ariaLabel.includes('photo') ||
          ariaLabel.includes('image') ||
          ariaLabel.includes('media') ||
          text.includes('photo')
        ) {
          if (isVisible(btn)) {
            clearInterval(interval);
            resolve(btn);
            return;
          }
        }
        
        const svg = btn.querySelector('svg');
        if (svg) {
          const use = svg.querySelector('use');
          if (use) {
            const href = use.getAttribute('xlink:href') || use.getAttribute('href') || '';
            if (href.includes('image') || href.includes('photo') || href.includes('media')) {
              if (isVisible(btn)) {
                clearInterval(interval);
                resolve(btn);
                return;
              }
            }
          }
        }
      }

      if (Date.now() - start > timeout) {
        clearInterval(interval);
        resolve(null);
      }
    }, 500);
  });
}

async function findNextButton(timeout = 15000) {
  const start = Date.now();

  return new Promise(resolve => {
    const interval = setInterval(() => {
      const buttons = document.querySelectorAll('button');
      
      for (const btn of buttons) {
        const text = btn.innerText?.trim() || '';
        const ariaLabel = btn.getAttribute('aria-label')?.toLowerCase() || '';
        
        if (
          text === 'Next' ||
          text === 'next' ||
          text.toLowerCase() === 'next' ||
          ariaLabel.includes('next')
        ) {
          if (isVisible(btn) && !btn.disabled) {
            clearInterval(interval);
            console.log('🎯 Found Next button:', text);
            resolve(btn);
            return;
          }
        }
      }

      if (Date.now() - start > timeout) {
        console.warn('⏰ Next button search timed out');
        clearInterval(interval);
        resolve(null);
      }
    }, 300);
  });
}

async function findDoneButton(timeout = 5000) {
  const start = Date.now();

  return new Promise(resolve => {
    const interval = setInterval(() => {
      const buttons = document.querySelectorAll('button');
      
      for (const btn of buttons) {
        const text = btn.innerText?.trim() || '';
        
        if (
          text === 'Done' ||
          text === 'done' ||
          text.toLowerCase() === 'done'
        ) {
          if (isVisible(btn) && !btn.disabled) {
            clearInterval(interval);
            resolve(btn);
            return;
          }
        }
      }

      if (Date.now() - start > timeout) {
        clearInterval(interval);
        resolve(null);
      }
    }, 300);
  });
}

async function findFileInput(timeout = 5000) {
  const start = Date.now();

  return new Promise(resolve => {
    const interval = setInterval(() => {
      const inputs = document.querySelectorAll('input[type="file"]');
      
      for (const input of inputs) {
        const accept = input.getAttribute('accept') || '';
        if (accept.includes('image')) {
          clearInterval(interval);
          resolve(input);
          return;
        }
      }

      if (Date.now() - start > timeout) {
        clearInterval(interval);
        resolve(null);
      }
    }, 200);
  });
}

async function base64ToBlob(base64, mimeType) {
  const base64Data = base64.replace(/^data:image\/\w+;base64,/, '');
  const byteCharacters = atob(base64Data);
  const byteArrays = [];

  for (let offset = 0; offset < byteCharacters.length; offset += 512) {
    const slice = byteCharacters.slice(offset, offset + 512);
    const byteNumbers = new Array(slice.length);
    
    for (let i = 0; i < slice.length; i++) {
      byteNumbers[i] = slice.charCodeAt(i);
    }
    
    const byteArray = new Uint8Array(byteNumbers);
    byteArrays.push(byteArray);
  }

  return new Blob(byteArrays, { type: mimeType });
}

// ----------------------------------------------------------------------------
// EXISTING HELPER FUNCTIONS
// ----------------------------------------------------------------------------

async function findStartPostButton(timeout = 15000) {
  const start = Date.now();

  return new Promise(resolve => {
    const interval = setInterval(() => {
      const strongTags = document.querySelectorAll('strong');
      for (const el of strongTags) {
        if (el.innerText?.trim() === 'Start a post') {
          const btn = el.closest('button');
          if (btn && isVisible(btn)) {
            clearInterval(interval);
            resolve(btn);
            return;
          }
        }
      }

      const buttons = document.querySelectorAll('button');
      for (const btn of buttons) {
        if (btn.innerText?.includes('Start a post') && isVisible(btn)) {
          clearInterval(interval);
          resolve(btn);
          return;
        }
      }

      if (Date.now() - start > timeout) {
        clearInterval(interval);
        resolve(null);
      }
    }, 500);
  });
}

async function findPostButton(timeout = 20000) {
  const start = Date.now();

  return new Promise(resolve => {
    const interval = setInterval(() => {
      const buttons = document.querySelectorAll('button');

      for (const btn of buttons) {
        const text = btn.innerText?.trim();
        
        if (
          text === 'Post' &&
          !btn.disabled &&
          isVisible(btn)
        ) {
          clearInterval(interval);
          resolve(btn);
          return;
        }
      }

      if (Date.now() - start > timeout) {
        clearInterval(interval);
        resolve(null);
      }
    }, 500);
  });
}

async function waitForAnyElement(selectors, timeout = 30000) {
  const start = Date.now();

  return new Promise(resolve => {
    const interval = setInterval(() => {
      for (const selector of selectors) {
        const el = document.querySelector(selector);
        if (el && isVisible(el)) {
          clearInterval(interval);
          console.log('✅ Found editor with selector:', selector);
          resolve(el);
          return;
        }
      }

      if (Date.now() - start > timeout) {
        console.error('❌ Editor search timed out after 30s');
        clearInterval(interval);
        resolve(null);
      }
    }, 500);
  });
}

async function humanClick(element) {
  element.scrollIntoView({ behavior: 'smooth', block: 'center' });
  await wait(500);

  element.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
  element.dispatchEvent(new MouseEvent('mouseup', { bubbles: true }));
  element.dispatchEvent(new MouseEvent('click', { bubbles: true }));

  element.click();
}

function triggerInputEvents(element) {
  element.dispatchEvent(new InputEvent('input', { bubbles: true }));
  element.dispatchEvent(new Event('change', { bubbles: true }));
}

function isVisible(el) {
  if (!el) return false;
  const rect = el.getBoundingClientRect();
  return rect.width > 0 && rect.height > 0;
}

function wait(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

console.log('✅ LinkedIn Content Script Ready (COMPLETE FIXED)');