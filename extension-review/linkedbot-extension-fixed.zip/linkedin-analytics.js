// ============================================================================
// LINKEDIN ANALYTICS - COMPLETE FINAL VERSION
// ============================================================================

console.log('📊 LinkedIn Analytics Loaded (FINAL VERSION)');

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('📨 Analytics received:', request.action);

  if (request.action === 'pingAnalytics') {
    sendResponse({ success: true, message: 'Analytics ready' });
    return true;
  }

  if (request.action === 'extractAnalyticsByUrl') {
    extractAnalyticsByUrl(request.url)
      .then(result => sendResponse(result))
      .catch(error => sendResponse({ success: false, found: false, error: error.message }));
    return true;
  }

  if (request.action === 'scrapeProfileAnalytics') {
    scrapeProfileAnalytics()
      .then(result => sendResponse(result))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true;
  }

  if (request.action === 'scanAllPosts') {
    scanAllUserPosts(request.limit || 50)
      .then(result => sendResponse(result))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true;
  }

  if (request.action === 'getLastPostUrl') {
    getLastPostedUrl()
      .then(result => sendResponse(result))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true;
  }
});

// ============================================================================
// ✅ FIXED: GET LAST POSTED URL
// ============================================================================

async function getLastPostedUrl() {
  try {
    console.log('🔗 Getting last posted URL from feed...');
    
    if (!location.href.includes('/feed')) {
      location.href = 'https://www.linkedin.com/feed/';
      await waitForPageLoad(10000);
    }

    window.scrollTo({ top: 0, behavior: 'instant' });
    await wait(3000);

    await waitForElement('[data-urn*="activity"], .feed-shared-update-v2', 10000);
    await wait(2000);

    const recentPosts = document.querySelectorAll('[data-urn*="activity"], [data-id*="activity"], .feed-shared-update-v2');
    
    if (recentPosts.length === 0) {
      throw new Error('No posts found on feed');
    }

    console.log(`🔍 Found ${recentPosts.length} posts, checking for most recent...`);

    for (let i = 0; i < Math.min(recentPosts.length, 5); i++) {
      const post = recentPosts[i];
      
      const timeElement = post.querySelector('time');
      if (timeElement) {
        const timeText = (timeElement.innerText || '').toLowerCase();
        
        console.log(`Post ${i}: "${timeText}"`);
        
        const isRecent = 
          timeText.includes('now') || 
          timeText.includes('just now') ||
          timeText.includes('second') ||
          timeText.includes('sec') ||
          /\d+\s*(second|sec|minute|min|m)s?/i.test(timeText) ||
          timeText.match(/^[0-9]+\s*m$/);
        
        if (isRecent) {
          const postUrl = await extractFullPostUrl(post);
          
          if (postUrl) {
            console.log('✅ Found recent post URL:', postUrl);
            return { 
              success: true, 
              url: postUrl,
              method: 'recent_timestamp'
            };
          }
        }
      }
    }

    console.log('⚠️ No recent timestamp, using first post');
    const firstPostUrl = await extractFullPostUrl(recentPosts[0]);
    
    if (firstPostUrl) {
      console.log('✅ First post URL:', firstPostUrl);
      return { 
        success: true, 
        url: firstPostUrl,
        method: 'first_post_fallback'
      };
    }

    throw new Error('Could not extract post URL');

  } catch (error) {
    console.error('❌ Failed to get post URL:', error);
    return { 
      success: false, 
      error: error.message 
    };
  }
}

// ============================================================================
// ✅ FIXED: EXTRACT FULL POST URL WITHOUT VALIDATION
// ============================================================================

async function extractFullPostUrl(postElement) {
  try {
    console.log('🔍 Extracting full post URL...');
    
    // METHOD 1: Get permalink from timestamp (MOST RELIABLE)
    const timeElement = postElement.querySelector('time');
    if (timeElement) {
      const timeLink = timeElement.closest('a');
      if (timeLink && timeLink.href) {
        // ✅ RETURN THE FULL URL - NO VALIDATION, NO STRIPPING PARAMS
        console.log('✅ Method 1 - Full URL from timestamp:', timeLink.href);
        return timeLink.href;
      }
    }

    // METHOD 2: Search for any /posts/ or /feed/update/ links
    const allLinks = postElement.querySelectorAll('a[href]');
    for (const link of allLinks) {
      const href = link.href;
      
      if (href.includes('/posts/') && href.includes('activity-')) {
        console.log('✅ Method 2 - Posts URL:', href);
        return href;
      }
      
      if (href.includes('/feed/update/') && href.includes('activity')) {
        console.log('✅ Method 2 - Feed update URL:', href);
        return href;
      }
    }

    // METHOD 3: Construct URL from data-urn
    const dataUrn = postElement.getAttribute('data-urn') || 
                    postElement.getAttribute('data-id');
    
    if (dataUrn) {
      const activityMatch = dataUrn.match(/activity:(\d{19})/);
      if (activityMatch) {
        const activityId = activityMatch[1];
        
        const authorLink = postElement.querySelector('a[href*="/in/"]');
        if (authorLink) {
          const authorUrl = authorLink.href;
          const usernameMatch = authorUrl.match(/linkedin\.com\/in\/([^\/\?]+)/);
          
          if (usernameMatch) {
            const username = usernameMatch[1];
            const constructedUrl = `https://www.linkedin.com/posts/${username}_activity-${activityId}`;
            console.log('✅ Method 3 - Constructed permalink:', constructedUrl);
            return constructedUrl;
          }
        }
        
        const feedUrl = `https://www.linkedin.com/feed/update/urn:li:activity:${activityId}/`;
        console.log('✅ Method 3 - Feed update URL:', feedUrl);
        return feedUrl;
      }
    }

    console.warn('⚠️ All methods failed to extract URL');
    return null;
    
  } catch (error) {
    console.error('❌ Error extracting URL:', error);
    return null;
  }
}

// ============================================================================
// EXTRACT ANALYTICS FROM POST URL
// ============================================================================

async function extractAnalyticsByUrl(postUrl) {
  try {
    console.log('📊 Extracting analytics from URL:', postUrl);

    if (!location.href.includes(postUrl)) {
      console.log('🔄 Navigating to post...');
      location.href = postUrl;
      await waitForPageLoad(15000);
      console.log('✅ Page loaded');
    }

    await waitForElement('.feed-shared-update-v2, [data-urn*="activity"]', 10000);
    console.log('✅ Post container loaded');
    
    await wait(2000);

    const metrics = {
      views: 0,
      likes: 0,
      comments: 0,
      shares: 0
    };

    // EXTRACT VIEWS/IMPRESSIONS
    const impressionsElements = document.querySelectorAll('[aria-label*="impression"], [aria-label*="view"]');
    for (const el of impressionsElements) {
      const label = el.getAttribute('aria-label') || '';
      const viewsMatch = label.match(/([0-9,]+)\s*(impression|view)/i);
      if (viewsMatch) {
        metrics.views = parseCount(viewsMatch[1]);
        console.log('👁️ Views:', metrics.views);
        break;
      }
    }

    // EXTRACT LIKES/REACTIONS
    const reactionElements = document.querySelectorAll('[aria-label*="reaction"], span[aria-hidden="true"]');
    for (const el of reactionElements) {
      const text = el.innerText || el.getAttribute('aria-label') || '';
      if (text.match(/\d+/) && (text.toLowerCase().includes('reaction') || el.closest('button'))) {
        metrics.likes = parseCount(text);
        console.log('👍 Likes:', metrics.likes);
        break;
      }
    }

    // EXTRACT COMMENTS
    const commentElements = document.querySelectorAll('[aria-label*="comment"]');
    for (const el of commentElements) {
      const label = el.getAttribute('aria-label') || el.innerText || '';
      const commentMatch = label.match(/([0-9,]+)\s*comment/i);
      if (commentMatch) {
        metrics.comments = parseCount(commentMatch[1]);
        console.log('💬 Comments:', metrics.comments);
        break;
      }
    }

    // EXTRACT SHARES/REPOSTS
    const shareElements = document.querySelectorAll('[aria-label*="repost"], [aria-label*="share"]');
    for (const el of shareElements) {
      const label = el.getAttribute('aria-label') || el.innerText || '';
      const shareMatch = label.match(/([0-9,]+)\s*(repost|share)/i);
      if (shareMatch) {
        metrics.shares = parseCount(shareMatch[1]);
        console.log('🔄 Shares:', metrics.shares);
        break;
      }
    }

    // FALLBACK: Try social counts bar
    if (metrics.views === 0 || metrics.likes === 0) {
      const socialCounts = document.querySelector('.social-details-social-counts');
      if (socialCounts) {
        const countsText = socialCounts.innerText;
        
        const likesMatch = countsText.match(/(\d+)\s*reaction/i);
        if (likesMatch && metrics.likes === 0) {
          metrics.likes = parseCount(likesMatch[1]);
        }

        const commentsMatch = countsText.match(/(\d+)\s*comment/i);
        if (commentsMatch && metrics.comments === 0) {
          metrics.comments = parseCount(commentsMatch[1]);
        }
      }
    }

    console.log('✅ Analytics extracted:', metrics);

    return {
      success: true,
      found: true,
      views: metrics.views,
      likes: metrics.likes,
      comments: metrics.comments,
      shares: metrics.shares,
      postUrl: postUrl,
      extractedAt: new Date().toISOString()
    };

  } catch (error) {
    console.error('❌ Analytics extraction failed:', error);
    return {
      success: false,
      found: false,
      error: error.message
    };
  }
}

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

async function waitForPageLoad(timeout = 15000) {
  const start = Date.now();
  
  return new Promise((resolve) => {
    const checkInterval = setInterval(() => {
      if (document.readyState === 'complete') {
        clearInterval(checkInterval);
        console.log('✅ Page readyState: complete');
        resolve(true);
        return;
      }
      
      if (Date.now() - start > timeout) {
        clearInterval(checkInterval);
        console.warn('⏰ Page load timeout');
        resolve(false);
      }
    }, 100);
  });
}

async function waitForElement(selector, timeout = 10000) {
  const start = Date.now();
  
  return new Promise((resolve) => {
    const checkInterval = setInterval(() => {
      const element = document.querySelector(selector);
      if (element && isVisible(element)) {
        clearInterval(checkInterval);
        console.log('✅ Found element:', selector);
        resolve(element);
        return;
      }
      
      if (Date.now() - start > timeout) {
        clearInterval(checkInterval);
        console.warn('⏰ Element wait timeout:', selector);
        resolve(null);
      }
    }, 200);
  });
}

async function scrapeProfileAnalytics() {
  try {
    console.log('🔍 Starting profile analytics scrape...');
    
    if (!location.href.includes('/in/')) {
      console.log('🔄 Navigating to profile...');
      
      const meButton = await findElement('[aria-label*="Me"]', 10000);
      if (meButton) {
        await humanClick(meButton);
        await wait(1000);
        
        const viewProfileLink = await findElementByText('View profile', 'a', 5000);
        if (viewProfileLink) {
          await humanClick(viewProfileLink);
          await wait(3000);
        }
      }
    }
    
    const followersCount = await scrapeFollowersCount();
    const connectionsCount = await scrapeConnectionsCount();
    
    const profileUrl = location.href;
    const usernameMatch = profileUrl.match(/linkedin\.com\/in\/([^\/]+)/);
    const username = usernameMatch ? usernameMatch[1] : null;
    
    const profileData = {
      username,
      profileUrl,
      followersCount,
      connectionsCount,
      scrapedAt: new Date().toISOString()
    };
    
    console.log('✅ Profile analytics scraped:', profileData);
    
    return { success: true, data: profileData };
    
  } catch (error) {
    console.error('❌ Profile scraping failed:', error);
    throw error;
  }
}

async function scanAllUserPosts(limit = 50) {
  try {
    console.log(`📚 Scanning last ${limit} posts...`);
    
    if (!location.href.includes('/recent-activity/all/')) {
      const postsTab = await findElementByText('Posts', 'a', 10000);
      if (postsTab) {
        await humanClick(postsTab);
        await wait(3000);
      }
    }
    
    const scrollTimes = Math.ceil(limit / 10);
    await scrollToLoadContent(scrollTimes);
    
    const postContainers = document.querySelectorAll('[data-id*="urn:li:activity"]');
    console.log(`🔍 Found ${postContainers.length} post containers`);
    
    const scannedPosts = [];
    const postsToScan = Math.min(postContainers.length, limit);
    
    for (let i = 0; i < postsToScan; i++) {
      const container = postContainers[i];
      
      try {
        const postData = await scanSinglePost(container);
        if (postData) {
          scannedPosts.push(postData);
        }
      } catch (error) {
        console.warn(`⚠️ Failed to scan post ${i}:`, error);
      }
    }
    
    const writingStyle = analyzeWritingStyle(scannedPosts);
    
    console.log(`✅ Scanned ${scannedPosts.length} posts`);
    
    return {
      success: true,
      data: {
        posts: scannedPosts,
        writingStyle: writingStyle,
        totalScanned: scannedPosts.length
      }
    };
    
  } catch (error) {
    console.error('❌ Post scanning failed:', error);
    throw error;
  }
}

async function scanSinglePost(container) {
  try {
    const postId = container.getAttribute('data-id') || 
                   container.id || 
                   'post-' + Date.now();
    
    let content = '';
    const contentElements = container.querySelectorAll('[dir="ltr"]');
    for (const el of contentElements) {
      const text = el.innerText?.trim();
      if (text && text.length > content.length) {
        content = text;
      }
    }
    
    let postUrl = null;
    const links = container.querySelectorAll('a[href*="/feed/update/"]');
    if (links.length > 0) {
      postUrl = links[0].href;
    }
    
    let timestamp = null;
    const timeElement = container.querySelector('time');
    if (timeElement) {
      timestamp = timeElement.getAttribute('datetime');
    }
    
    const likes = await scrapeMetric(container, ['reaction', 'like'], '👍');
    const comments = await scrapeMetric(container, ['comment'], '💬');
    const reposts = await scrapeMetric(container, ['repost', 'share'], '🔄');
    const views = await scrapeMetric(container, ['view', 'impression'], '👁️');
    
    const hashtags = extractHashtags(content);
    const hasEmojis = /[\u{1F600}-\u{1F64F}]|[\u{1F300}-\u{1F5FF}]|[\u{1F680}-\u{1F6FF}]|[\u{2600}-\u{26FF}]/u.test(content);
    
    return {
      postId,
      content,
      postUrl,
      timestamp,
      likes,
      comments,
      reposts,
      views,
      hashtags,
      hasEmojis,
      wordCount: content.split(/\s+/).length,
      scrapedAt: new Date().toISOString()
    };
    
  } catch (error) {
    return null;
  }
}

function analyzeWritingStyle(posts) {
  if (posts.length === 0) {
    return {
      avgPostLength: 0,
      commonHashtags: [],
      usesEmojis: false,
      usesHashtags: false,
      avgHashtagsPerPost: 0,
      tone: 'professional'
    };
  }
  
  const totalWords = posts.reduce((sum, p) => sum + p.wordCount, 0);
  const avgPostLength = Math.floor(totalWords / posts.length);
  
  const allHashtags = posts.flatMap(p => p.hashtags || []);
  const hashtagFrequency = {};
  allHashtags.forEach(tag => {
    hashtagFrequency[tag] = (hashtagFrequency[tag] || 0) + 1;
  });
  
  const commonHashtags = Object.entries(hashtagFrequency)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 10)
    .map(([tag]) => tag);
  
  const usesEmojis = posts.some(p => p.hasEmojis);
  const usesHashtags = allHashtags.length > 0;
  const avgHashtagsPerPost = allHashtags.length / posts.length;
  
  let tone = 'professional';
  const allContent = posts.map(p => p.content.toLowerCase()).join(' ');
  
  if (allContent.includes('excited') || allContent.includes('amazing')) {
    tone = 'enthusiastic';
  } else if (allContent.includes('insight') || allContent.includes('data')) {
    tone = 'analytical';
  } else if (allContent.includes('story') || allContent.includes('journey')) {
    tone = 'storytelling';
  }
  
  return {
    avgPostLength,
    commonHashtags,
    usesEmojis,
    usesHashtags,
    avgHashtagsPerPost: Math.round(avgHashtagsPerPost * 10) / 10,
    tone,
    totalPostsAnalyzed: posts.length
  };
}

function extractHashtags(text) {
  const hashtagRegex = /#[\w]+/g;
  return (text.match(hashtagRegex) || []).map(tag => tag.substring(1));
}

async function scrapeFollowersCount() {
  try {
    const followerElements = document.querySelectorAll('span, div, li');
    
    for (const el of followerElements) {
      const text = el.innerText?.trim();
      
      if (text && (text.includes('follower') || text.includes('Follower'))) {
        const match = text.match(/([0-9,\.]+[KMB]?)\s*follower/i);
        if (match) {
          return parseCount(match[1]);
        }
      }
    }
    
    return 0;
  } catch (error) {
    return 0;
  }
}

async function scrapeConnectionsCount() {
  try {
    const elements = document.querySelectorAll('span, div, li');
    
    for (const el of elements) {
      const text = el.innerText?.trim();
      
      if (text && text.includes('connection')) {
        const match = text.match(/([0-9,\.]+[KMB]?)\s*connection/i);
        if (match) {
          return parseCount(match[1]);
        }
      }
    }
    
    return 0;
  } catch (error) {
    return 0;
  }
}

async function scrapeMetric(container, keywords, emoji) {
  try {
    const elements = container.querySelectorAll('span, button, div');
    
    for (const el of elements) {
      const ariaLabel = el.getAttribute('aria-label')?.toLowerCase();
      const text = el.innerText?.toLowerCase();
      
      for (const keyword of keywords) {
        if ((ariaLabel && ariaLabel.includes(keyword)) || 
            (text && text.includes(keyword))) {
          
          const fullText = ariaLabel || text || '';
          const match = fullText.match(/([0-9,\.]+[KMB]?)/);
          
          if (match) {
            return parseCount(match[1]);
          }
        }
      }
    }
    
    return 0;
  } catch (error) {
    return 0;
  }
}

function parseCount(str) {
  if (!str) return 0;
  
  if (typeof str === 'string') {
    str = str.replace(/,/g, '');
    
    const multipliers = {
      'K': 1000,
      'M': 1000000,
      'B': 1000000000
    };
    
    const match = str.match(/([0-9\.]+)([KMB]?)/i);
    if (!match) return 0;
    
    const num = parseFloat(match[1]);
    const suffix = match[2].toUpperCase();
    
    return Math.floor(num * (multipliers[suffix] || 1));
  }
  
  return parseInt(str) || 0;
}

async function scrollToLoadContent(times = 3) {
  for (let i = 0; i < times; i++) {
    window.scrollTo({
      top: document.body.scrollHeight,
      behavior: 'smooth'
    });
    await wait(2000);
  }
  
  window.scrollTo({ top: 0, behavior: 'smooth' });
  await wait(1000);
}

async function findElement(selector, timeout = 10000) {
  const start = Date.now();
  
  return new Promise(resolve => {
    const interval = setInterval(() => {
      const el = document.querySelector(selector);
      
      if (el && isVisible(el)) {
        clearInterval(interval);
        resolve(el);
        return;
      }
      
      if (Date.now() - start > timeout) {
        clearInterval(interval);
        resolve(null);
      }
    }, 500);
  });
}

async function findElementByText(text, tagName = '*', timeout = 10000) {
  const start = Date.now();
  
  return new Promise(resolve => {
    const interval = setInterval(() => {
      const elements = document.querySelectorAll(tagName);
      
      for (const el of elements) {
        if (el.innerText?.toLowerCase().includes(text.toLowerCase()) && isVisible(el)) {
          clearInterval(interval);
          resolve(el);
          return;
        }
      }
      
      if (Date.now() - start > timeout) {
        clearInterval(interval);
        resolve(null);
      }
    }, 500);
  });
}

async function humanClick(element) {
  element.scrollIntoView({ behavior: 'smooth', block: 'center' });
  await wait(300);
  
  element.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
  element.dispatchEvent(new MouseEvent('mouseup', { bubbles: true }));
  element.dispatchEvent(new MouseEvent('click', { bubbles: true }));
  
  element.click();
}

function isVisible(el) {
  if (!el) return false;
  const rect = el.getBoundingClientRect();
  return rect.width > 0 && rect.height > 0;
}

function wait(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

console.log('✅ LinkedIn Analytics Ready (FINAL VERSION)');