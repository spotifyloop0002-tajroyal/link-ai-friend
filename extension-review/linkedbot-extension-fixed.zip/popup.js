// Popup script - Updated for linkedbot4.lovable.app
document.addEventListener('DOMContentLoaded', async () => {
  await checkStatus();
  
  document.getElementById('open-webapp').addEventListener('click', () => {
    chrome.tabs.create({ url: 'https://linkedbot4.lovable.app' });
  });
  
  document.getElementById('disconnect').addEventListener('click', async () => {
    if (confirm('Are you sure you want to disconnect the extension?')) {
      await chrome.runtime.sendMessage({ action: 'setDisconnected' });
      await checkStatus();
    }
  });
  
  setInterval(checkStatus, 3000);
});

async function checkStatus() {
  try {
    const response = await chrome.runtime.sendMessage({ action: 'getStatus' });
    
    document.getElementById('loading').classList.add('hidden');
    
    if (response.connected) {
      showConnected(response.extensionId);
    } else {
      showNotConnected();
    }
  } catch (error) {
    console.error('Error checking status:', error);
    showNotConnected();
  }
}

function showConnected(extensionId) {
  document.getElementById('not-connected').classList.add('hidden');
  document.getElementById('connected').classList.remove('hidden');
  document.getElementById('extension-id').textContent = extensionId || 'Unknown';
}

function showNotConnected() {
  document.getElementById('connected').classList.add('hidden');
  document.getElementById('not-connected').classList.remove('hidden');
}