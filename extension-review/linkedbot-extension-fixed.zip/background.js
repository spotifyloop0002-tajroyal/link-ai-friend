// ============================================================================
// LINKEDBOT BACKGROUND - SECURITY FIXED VERSION WITH USER ISOLATION
// ============================================================================

const SUPABASE_URL = 'https://glrgfnqdzwbpkcsoxsgd.supabase.co';

const API_ENDPOINTS = {
  syncPost: `${SUPABASE_URL}/functions/v1/sync-post`,
  syncAnalytics: `${SUPABASE_URL}/functions/v1/sync-analytics`,
  syncProfile: `${SUPABASE_URL}/functions/v1/sync-profile`
};

const ANALYTICS_INTERVAL = 30 * 60 * 1000; // 30 minutes

let extensionId = null;
let currentUserId = null; // 🔒 Track current user for data isolation

// ============================================================================
// 🔒 USER-ISOLATED STORAGE KEYS
// ============================================================================
// Store data per-user to prevent cross-contamination
function getPostQueueKey(userId) {
  return `post_queue_${userId}`;
}

function getPostTrackingKey(userId) {
  return `post_tracking_${userId}`;
}

// ============================================================================
// 🔒 USER SESSION MANAGEMENT
// ============================================================================
async function setCurrentUser(userId) {
  if (!userId) {
    console.warn('⚠️ Attempted to set null/undefined userId');
    return;
  }
  
  const previousUserId = currentUserId;
  currentUserId = userId;
  
  await chrome.storage.local.set({ currentUserId: userId });
  console.log('👤 Current user set:', userId);
  
  // If user changed, clear stale data from previous user
  if (previousUserId && previousUserId !== userId) {
    console.warn('🔄 User changed! Clearing cached data from previous user:', previousUserId);
    await clearUserData(previousUserId);
  }
}

async function getCurrentUser() {
  if (currentUserId) return currentUserId;
  
  const result = await chrome.storage.local.get('currentUserId');
  currentUserId = result.currentUserId || null;
  return currentUserId;
}

async function clearUserData(userId) {
  // Clear queue and tracking for specific user
  const queueKey = getPostQueueKey(userId);
  const trackingKey = getPostTrackingKey(userId);
  
  await chrome.storage.local.remove([queueKey, trackingKey]);
  console.log(`✅ Cleared cached data for user: ${userId}`);
}

async function clearAllUserData() {
  // Nuclear option - clear everything
  await chrome.storage.local.clear();
  currentUserId = null;
  console.log('🧹 All user data cleared');
}

// ============================================================================
// INITIALIZATION
// ============================================================================

chrome.runtime.onInstalled.addListener(async () => {
  console.log('🚀 LinkedBot extension installed (SECURITY FIXED VERSION)');
  
  extensionId = chrome.runtime.id;
  await chrome.storage.local.set({ 
    extensionId, 
    isConnected: false,
    autoPostEnabled: true
  });
  
  await createPersistentHeartbeat();
  await startAnalyticsTracking();
  
  console.log('✅ Extension ID:', extensionId);
});

// ============================================================================
// PERSISTENT HEARTBEAT
// ============================================================================

async function createPersistentHeartbeat() {
  await chrome.alarms.clear('heartbeat');
  
  await chrome.alarms.create('heartbeat', { 
    delayInMinutes: 0.4,
    periodInMinutes: 0.4
  });
  
  console.log('💓 Persistent heartbeat created (25s interval)');
}

// ============================================================================
// ANALYTICS TRACKING SYSTEM
// ============================================================================

async function startAnalyticsTracking() {
  await chrome.alarms.clear('analytics_tracker');
  
  await chrome.alarms.create('analytics_tracker', {
    delayInMinutes: 1,
    periodInMinutes: 30
  });
  
  console.log('📊 Analytics tracking started (30 min intervals)');
}

async function trackAllRecentPosts() {
  try {
    console.log('📊 Starting analytics tracking cycle...');
    
    const userId = await getCurrentUser();
    if (!userId) {
      console.warn('⚠️ No current user - skipping analytics tracking');
      return;
    }
    
    const trackingKey = getPostTrackingKey(userId);
    const result = await chrome.storage.local.get(trackingKey);
    const allTracking = result[trackingKey] || [];
    
    const oneDayAgo = Date.now() - 24 * 60 * 60 * 1000;
    const recentPosts = allTracking.filter(tracking => {
      if (!tracking.postedAt || !tracking.linkedinUrl) return false;
      const postedTime = new Date(tracking.postedAt).getTime();
      return postedTime > oneDayAgo;
    });
    
    console.log(`📊 Found ${recentPosts.length} posts to track for user ${userId}`);
    
    for (const tracking of recentPosts) {
      await trackPostAnalyticsByUrl(tracking.linkedinUrl, tracking.trackingId);
      await sleep(5000);
    }
    
    console.log('✅ Analytics tracking cycle complete');
  } catch (error) {
    console.error('❌ Analytics tracking error:', error);
  }
}

// ============================================================================
// STARTUP
// ============================================================================

chrome.runtime.onStartup.addListener(async () => {
  console.log('🚀 Extension started - resuming operations');
  
  await createPersistentHeartbeat();
  await startAnalyticsTracking();
  
  setTimeout(() => trackAllRecentPosts(), 10000);
});

// ============================================================================
// MESSAGE LISTENER - WITH USER SESSION HANDLING
// ============================================================================

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  
  // 🔑 CRITICAL: wakeUp MUST BE FIRST HANDLER
  if (request.action === 'wakeUp') {
    console.log('👋 Service worker woken up');
    sendResponse({ success: true, ready: true, timestamp: Date.now() });
    return true;
  }
  
  if (request.action === 'getExtensionId') {
    sendResponse({ extensionId: chrome.runtime.id });
    return true;
  }
  
  // 🔒 NEW: Set current user (called when user logs in on webapp)
  if (request.action === 'setCurrentUser') {
    setCurrentUser(request.userId)
      .then(() => sendResponse({ success: true, userId: request.userId }))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true;
  }
  
  // 🔒 NEW: Clear user data (called when user logs out)
  if (request.action === 'clearUserSession') {
    clearAllUserData()
      .then(() => sendResponse({ success: true }))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true;
  }
  
  if (request.action === 'setConnected') {
    chrome.storage.local.set({ isConnected: true }).then(() => {
      sendResponse({ success: true });
    });
    return true;
  }
  
  if (request.action === 'setDisconnected') {
    chrome.storage.local.set({ isConnected: false }).then(() => {
      sendResponse({ success: true });
    });
    return true;
  }
  
  if (request.action === 'getStatus') {
    chrome.storage.local.get(['isConnected', 'autoPostEnabled', 'currentUserId']).then((data) => {
      sendResponse({
        connected: data.isConnected || false,
        extensionId: chrome.runtime.id,
        autoPostEnabled: data.autoPostEnabled !== undefined ? data.autoPostEnabled : true,
        currentUserId: data.currentUserId || null
      });
    });
    return true;
  }
  
  if (request.action === 'schedulePosts') {
    handleSchedulePosts(request.posts)
      .then(result => sendResponse(result))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true;
  }
  
  if (request.action === 'postNow') {
    publishPostToLinkedIn(request.post)
      .then(result => sendResponse(result))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true;
  }
  
  if (request.action === 'scrapeAnalytics') {
    scrapeLinkedInAnalytics()
      .then(result => sendResponse(result))
      .catch(error => sendResponse({ 
        success: false, 
        error: error.message,
        data: { profile: null, posts: [] }
      }));
    return true;
  }
  
  if (request.action === 'scanUserPosts') {
    scanAllUserPosts()
      .then(result => sendResponse(result))
      .catch(error => sendResponse({ 
        success: false, 
        error: error.message,
        data: { posts: [], writingStyle: {} }
      }));
    return true;
  }
  
  if (request.action === 'getPostedUrl') {
    getLastPostedUrl()
      .then(result => sendResponse(result))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true;
  }
  
  if (request.action === 'saveProfileUrl') {
    const profileUrl = request.url;
    
    if (!profileUrl || !profileUrl.includes('linkedin.com/in/')) {
      sendResponse({ success: false, error: 'Invalid LinkedIn profile URL' });
      return true;
    }
    
    const cleanUrl = profileUrl.split('?')[0].replace(/\/$/, '');
    
    chrome.storage.local.set({ linkedinProfileUrl: cleanUrl }).then(() => {
      console.log('✅ Profile URL saved:', cleanUrl);
      notifyWebapp('profileUrlSaved', { url: cleanUrl });
      sendResponse({ success: true, url: cleanUrl });
    });
    
    return true;
  }
  
  if (request.action === 'getProfileUrl') {
    chrome.storage.local.get('linkedinProfileUrl').then((data) => {
      sendResponse({ success: true, url: data.linkedinProfileUrl || null });
    });
    return true;
  }
  
  return true;
});

// ============================================================================
// ALARM LISTENER
// ============================================================================

chrome.alarms.onAlarm.addListener(async (alarm) => {
  
  if (alarm.name === 'heartbeat') {
    // Silent heartbeat
    return;
  }

  if (alarm.name === 'analytics_tracker') {
    console.log('📊 Analytics tracking alarm fired');
    await trackAllRecentPosts();
    return;
  }

  if (alarm.name.startsWith('post_')) {
    const trackingId = alarm.name.replace('post_', '');
    console.log(`⏰ Alarm fired: ${trackingId}`);
    
    const userId = await getCurrentUser();
    if (!userId) {
      console.error('❌ No current user - cannot process alarm');
      return;
    }
    
    const queueKey = getPostQueueKey(userId);
    const result = await chrome.storage.local.get(queueKey);
    const queue = result[queueKey] || [];
    
    const postIndex = queue.findIndex(p => p.trackingId === trackingId);
    if (postIndex === -1) {
      console.error('❌ Post not found in queue:', trackingId);
      return;
    }
    
    const post = queue[postIndex];
    
    await notifyWebapp('alarmFired', {
      postId: post.id,
      trackingId: post.trackingId,
      userId: userId, // Include userId in notification
      message: '⏰ Time to post!'
    });
    
    const autoPostEnabled = await chrome.storage.local.get('autoPostEnabled');
    const shouldAutoPost = autoPostEnabled.autoPostEnabled !== undefined 
      ? autoPostEnabled.autoPostEnabled 
      : true;
    
    if (shouldAutoPost) {
      console.log('🤖 Auto-post enabled - posting now');
      const result = await postToLinkedIn(post);
      
      if (result.success) {
        queue.splice(postIndex, 1);
        await chrome.storage.local.set({ [queueKey]: queue });
      }
    } else {
      console.log('⏸️ Auto-post disabled - user must manually approve');
      await notifyWebapp('manualApprovalRequired', {
        postId: post.id,
        trackingId: post.trackingId,
        userId: userId
      });
    }
  }
});

// ============================================================================
// POST SCHEDULING
// ============================================================================

async function handleSchedulePosts(posts) {
  if (!posts || posts.length === 0) {
    return { success: false, error: 'No posts provided' };
  }

  const userId = await getCurrentUser();
  if (!userId) {
    return { success: false, error: 'No user session - please log in' };
  }

  console.log(`📅 Scheduling ${posts.length} posts for user ${userId}`);
  
  const queueKey = getPostQueueKey(userId);
  const result = await chrome.storage.local.get(queueKey);
  const existingQueue = result[queueKey] || [];
  
  const newPosts = [];
  
  for (const post of posts) {
    // 🔒 Validate userId matches current user
    if (post.user_id !== userId) {
      console.error('❌ SECURITY: Post userId does not match current user!', {
        postUserId: post.user_id,
        currentUserId: userId
      });
      continue;
    }
    
    const trackingId = post.id;
    const scheduledTime = new Date(post.scheduled_for);
    
    if (isNaN(scheduledTime.getTime())) {
      console.error('❌ Invalid date:', post.scheduled_for);
      continue;
    }
    
    const queuedPost = {
      id: post.id,
      trackingId: trackingId,
      userId: userId, // 🔒 Store userId with post
      content: post.content,
      imageUrl: post.photo_url,
      scheduledTime: scheduledTime.toISOString(),
      status: 'scheduled'
    };
    
    newPosts.push(queuedPost);
    
    const alarmName = `post_${trackingId}`;
    await chrome.alarms.create(alarmName, { when: scheduledTime.getTime() });
    
    console.log(`✅ Scheduled: ${trackingId} for ${scheduledTime.toLocaleString()}`);
  }
  
  const updatedQueue = [...existingQueue, ...newPosts];
  await chrome.storage.local.set({ [queueKey]: updatedQueue });
  
  const nextPost = updatedQueue.sort((a, b) => 
    new Date(a.scheduledTime) - new Date(b.scheduledTime)
  )[0];
  
  return {
    success: true,
    queueLength: updatedQueue.length,
    nextScheduled: nextPost ? nextPost.scheduledTime : null,
    message: `${newPosts.length} posts scheduled successfully`
  };
}

// ============================================================================
// POSTING TO LINKEDIN
// ============================================================================

async function postToLinkedIn(post) {
  try {
    console.log('📤 Publishing post:', post.trackingId);
    
    const userId = await getCurrentUser();
    if (!userId) {
      throw new Error('No user session');
    }
    
    // 🔒 Validate post belongs to current user
    if (post.userId && post.userId !== userId) {
      throw new Error('Security: Post does not belong to current user');
    }
    
    await notifyWebapp('postStarted', { 
      postId: post.id, 
      trackingId: post.trackingId,
      userId: userId
    });
    
    await syncPostStatus(post.id, post.trackingId, userId, 'posting');
    
    let linkedinTab = await findLinkedInTab();
    
    if (!linkedinTab) {
      linkedinTab = await chrome.tabs.create({
        url: 'https://www.linkedin.com/feed/',
        active: true
      });
      await waitForTabLoad(linkedinTab.id);
      await sleep(3000);
    } else {
      await chrome.tabs.update(linkedinTab.id, { active: true });
      await sleep(1000);
    }
    
    await ensureContentScriptLoaded(linkedinTab.id);
    
    const postResult = await sendMessageToTab(linkedinTab.id, {
      action: 'createPost',
      content: post.content,
      imageUrl: post.imageUrl
    });
    
    if (!postResult || !postResult.success) {
      throw new Error(postResult?.error || 'Failed to create post');
    }
    
    console.log('✅ Post created successfully');
    
    await sleep(5000);
    
    const urlResult = await sendMessageToTab(linkedinTab.id, {
      action: 'getLastPostUrl'
    });
    
    const linkedinUrl = urlResult?.url || null;
    const linkedinPostId = linkedinUrl ? extractPostIdFromUrl(linkedinUrl) : null;
    
    if (!linkedinUrl) {
      console.warn('⚠️ Could not retrieve post URL');
    }
    
    // 🔒 Include userId in all sync calls
    await syncPostStatus(post.id, post.trackingId, userId, 'posted', linkedinUrl, linkedinPostId);
    
    const trackingKey = getPostTrackingKey(userId);
    await storePostTracking({
      trackingId: post.trackingId,
      userId: userId, // 🔒 Store userId
      postId: post.id,
      linkedinUrl: linkedinUrl,
      linkedinPostId: linkedinPostId,
      postedAt: new Date().toISOString(),
      status: 'posted'
    });
    
    await notifyWebapp('postSuccess', {
      postId: post.id,
      trackingId: post.trackingId,
      userId: userId,
      linkedinUrl: linkedinUrl,
      linkedinPostId: linkedinPostId
    });
    
    if (linkedinUrl) {
      setTimeout(() => trackPostAnalyticsByUrl(linkedinUrl, post.trackingId), 30000);
    }
    
    return { 
      success: true, 
      linkedinUrl, 
      linkedinPostId 
    };
    
  } catch (error) {
    console.error('❌ Post error:', error);
    
    const userId = await getCurrentUser();
    await syncPostStatus(post.id, post.trackingId, userId, 'failed', null, null, error.message);
    
    await notifyWebapp('postFailed', {
      postId: post.id,
      trackingId: post.trackingId,
      userId: userId,
      error: error.message
    });
    
    return { 
      success: false, 
      error: error.message 
    };
  }
}

// ============================================================================
// 🔒 SYNC POST STATUS (WITH MANDATORY USERID)
// ============================================================================

async function syncPostStatus(postId, trackingId, userId, status, linkedinUrl = null, linkedinPostId = null, error = null) {
  // 🔒 CRITICAL: Reject if userId is missing
  if (!userId) {
    console.error('❌ SECURITY: Cannot sync post without userId');
    return false;
  }
  
  try {
    console.log(`🔄 Syncing status to backend: ${status}`, {
      postId,
      trackingId,
      userId
    });
    
    const payload = {
      userId: userId, // 🔒 ALWAYS include userId
      postId: postId,
      trackingId: trackingId,
      status: status
    };
    
    if (linkedinUrl) payload.linkedinUrl = linkedinUrl;
    if (linkedinPostId) payload.linkedinPostId = linkedinPostId;
    if (error) payload.error = error;
    
    const response = await fetch(API_ENDPOINTS.syncPost, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    
    if (!response.ok) {
      const errorText = await response.text();
      console.error('❌ Sync API error:', errorText);
      throw new Error(`API returned ${response.status}`);
    }
    
    const data = await response.json();
    console.log('✅ Status synced:', data);
    
    return data.success;
    
  } catch (error) {
    console.error('❌ Sync error:', error);
    return false;
  }
}

// ============================================================================
// ANALYTICS SYNCING
// ============================================================================

async function syncAnalyticsToWebsite(trackingId, analytics) {
  try {
    const userId = await getCurrentUser();
    if (!userId) {
      console.warn('⚠️ No current user - cannot sync analytics');
      return false;
    }
    
    console.log('📊 Syncing analytics to backend');

    const response = await fetch(API_ENDPOINTS.syncAnalytics, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        userId: userId, // 🔒 Include userId
        trackingId: trackingId,
        postLink: analytics.postLink,
        views: analytics.views,
        likes: analytics.likes,
        comments: analytics.comments,
        shares: analytics.shares
      })
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('❌ Analytics API error:', errorText);
      throw new Error(`API returned ${response.status}`);
    }

    const data = await response.json();
    
    if (data.success) {
      console.log('✅ Analytics synced to backend');
      
      await notifyWebapp('analyticsUpdated', {
        trackingId,
        userId: userId,
        analytics: {
          postLink: analytics.postLink,
          views: analytics.views,
          likes: analytics.likes,
          comments: analytics.comments,
          shares: analytics.shares,
          updatedAt: new Date().toISOString()
        }
      });
    }
    
    return data.success;

  } catch (error) {
    console.error('❌ Analytics sync error:', error);
    return false;
  }
}

// ============================================================================
// ANALYTICS TRACKING
// ============================================================================

async function trackPostAnalyticsByUrl(linkedinUrl, trackingId) {
  try {
    console.log('📊 Tracking:', linkedinUrl);

    const userId = await getCurrentUser();
    if (!userId) {
      console.warn('⚠️ No current user - skipping analytics');
      return;
    }

    const trackingKey = getPostTrackingKey(userId);
    const result = await chrome.storage.local.get(trackingKey);
    const allTracking = result[trackingKey] || [];
    const tracking = allTracking.find(t => t.trackingId === trackingId);

    if (!tracking) {
      console.warn('⚠️ Tracking not found for:', trackingId);
      return;
    }

    let linkedinTab = await findLinkedInTab();
    
    if (!linkedinTab) {
      linkedinTab = await chrome.tabs.create({
        url: linkedinUrl,
        active: false
      });
      await waitForTabLoad(linkedinTab.id);
      await sleep(3000);
    } else {
      await chrome.tabs.update(linkedinTab.id, { url: linkedinUrl });
      await sleep(5000);
    }

    await ensureAnalyticsScriptLoaded(linkedinTab.id);

    const analytics = await sendMessageToTab(linkedinTab.id, {
      action: 'extractAnalyticsByUrl',
      url: linkedinUrl
    });

    if (analytics?.found) {
      console.log('✅ Analytics extracted:', analytics);

      await syncAnalyticsToWebsite(trackingId, {
        postLink: linkedinUrl,
        views: analytics.views,
        likes: analytics.likes,
        comments: analytics.comments,
        shares: analytics.shares
      });

      tracking.lastSynced = new Date().toISOString();
      tracking.lastAnalytics = {
        views: analytics.views,
        likes: analytics.likes,
        comments: analytics.comments,
        shares: analytics.shares
      };
      await storePostTracking(tracking);

      console.log('✅ Analytics will be tracked again in 30 minutes');
    } else {
      console.warn('⚠️ Analytics not found, will retry in 5 minutes');
      setTimeout(() => trackPostAnalyticsByUrl(linkedinUrl, trackingId), 5 * 60 * 1000);
    }

  } catch (error) {
    console.error('❌ Analytics error:', error);
    setTimeout(() => trackPostAnalyticsByUrl(linkedinUrl, trackingId), 5 * 60 * 1000);
  }
}

// ============================================================================
// STORAGE
// ============================================================================

async function storePostTracking(tracking) {
  const userId = await getCurrentUser();
  if (!userId) {
    console.warn('⚠️ No current user - cannot store tracking');
    return;
  }
  
  const trackingKey = getPostTrackingKey(userId);
  const result = await chrome.storage.local.get(trackingKey);
  const allTracking = result[trackingKey] || [];
  
  const existingIndex = allTracking.findIndex(t => t.trackingId === tracking.trackingId);
  
  if (existingIndex >= 0) {
    allTracking[existingIndex] = { ...allTracking[existingIndex], ...tracking };
  } else {
    allTracking.push(tracking);
  }

  await chrome.storage.local.set({ [trackingKey]: allTracking });
}

// ============================================================================
// HELPERS
// ============================================================================

async function publishPostToLinkedIn(post) {
  return postToLinkedIn({
    id: post.id,
    trackingId: post.id,
    userId: post.user_id,
    content: post.content,
    imageUrl: post.photo_url,
    scheduledTime: new Date().toISOString()
  });
}

async function scrapeLinkedInAnalytics() {
  const linkedinTab = await findLinkedInTab();
  if (!linkedinTab) throw new Error('No LinkedIn tab');

  await ensureAnalyticsScriptLoaded(linkedinTab.id);

  const result = await sendMessageToTab(linkedinTab.id, {
    action: 'scrapeProfileAnalytics'
  });

  if (result?.success) return { success: true, data: result.data };
  throw new Error(result?.error || 'Analytics failed');
}

async function scanAllUserPosts() {
  const linkedinTab = await findLinkedInTab();
  if (!linkedinTab) throw new Error('No LinkedIn tab');

  await ensureAnalyticsScriptLoaded(linkedinTab.id);

  const result = await sendMessageToTab(linkedinTab.id, {
    action: 'scanAllPosts'
  });

  if (result?.success) return { success: true, data: result.data };
  throw new Error(result?.error || 'Scan failed');
}

async function getLastPostedUrl() {
  const linkedinTab = await findLinkedInTab();
  if (!linkedinTab) throw new Error('No LinkedIn tab');

  await ensureAnalyticsScriptLoaded(linkedinTab.id);

  const result = await sendMessageToTab(linkedinTab.id, {
    action: 'getLastPostUrl'
  });

  if (result?.success) return { success: true, url: result.url };
  return { success: false, url: null };
}

async function ensureContentScriptLoaded(tabId) {
  try {
    await chrome.tabs.sendMessage(tabId, { action: 'ping' });
  } catch {
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ['linkedin-content.js']
    });
    await sleep(1500);
  }
}

async function ensureAnalyticsScriptLoaded(tabId) {
  try {
    await chrome.tabs.sendMessage(tabId, { action: 'pingAnalytics' });
  } catch {
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ['linkedin-analytics.js']
    });
    await sleep(1500);
  }
}

async function sendMessageToTab(tabId, message, retries = 3) {
  for (let i = 0; i < retries; i++) {
    try {
      await chrome.tabs.get(tabId);
      const response = await chrome.tabs.sendMessage(tabId, message);
      return response || { success: false };
    } catch (error) {
      if (i === retries - 1) return { success: false, error: error.message };
      await sleep(1000);
    }
  }
}

async function notifyWebapp(event, data) {
  try {
    const tabs = await chrome.tabs.query({ url: 'https://linkedbot4.lovable.app/*' });
    for (const tab of tabs) {
      try {
        await chrome.tabs.sendMessage(tab.id, {
          action: 'extensionEvent',
          event,
          data
        });
        console.log(`📡 Notified webapp: ${event}`);
      } catch (err) {
        // Tab closed or not ready
      }
    }
  } catch (error) {
    console.error('Notify error:', error);
  }
}

async function findLinkedInTab() {
  const tabs = await chrome.tabs.query({ url: 'https://www.linkedin.com/*' });
  return tabs.length > 0 ? tabs[0] : null;
}

function extractPostIdFromUrl(url) {
  const match = url.match(/activity[:-](\d+)/);
  return match ? match[1] : null;
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function waitForTabLoad(tabId) {
  return new Promise((resolve) => {
    const listener = (id, info) => {
      if (id === tabId && info.status === 'complete') {
        chrome.tabs.onUpdated.removeListener(listener);
        resolve();
      }
    };
    chrome.tabs.onUpdated.addListener(listener);
    setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(listener);
      resolve();
    }, 15000);
  });
}

console.log('✅ LinkedBot Background Ready (SECURITY FIXED WITH USER ISOLATION)');