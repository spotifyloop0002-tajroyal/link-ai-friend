// ============================================================================
// LINKEDBOT WEBAPP CONTENT SCRIPT - PRODUCTION FIXED VERSION
// ============================================================================

console.log('🌐 LinkedBot webapp content script loaded');

// Inject bridge script
const script = document.createElement('script');
script.src = chrome.runtime.getURL('injected.js');
script.onload = function() {
  this.remove();
};
(document.head || document.documentElement).appendChild(script);

// ============================================================================
// SAFE MESSAGE SENDING WITH AUTO-WAKE (MV3 PRODUCTION)
// ============================================================================

async function safeSendMessage(message, retries = 3) {
  for (let i = 0; i < retries; i++) {
    try {
      // 🔑 CRITICAL: Always wake the service worker FIRST (except for wakeUp itself)
      if (message.action !== 'wakeUp') {
        try {
          await chrome.runtime.sendMessage({ action: 'wakeUp' });
          // Give service worker time to fully initialize
          await new Promise(resolve => setTimeout(resolve, 100));
        } catch (wakeError) {
          console.warn('Wake-up attempt failed, but continuing...', wakeError.message);
        }
      }

      // Send the actual message
      const response = await chrome.runtime.sendMessage(message);
      return { success: true, data: response };
      
    } catch (error) {
      const isLastAttempt = i === retries - 1;
      console.warn(`Message send attempt ${i + 1}/${retries} failed:`, error.message);

      // Handle "Extension context invalidated" - this is NORMAL in MV3
      if (error.message.includes('Extension context invalidated') || 
          error.message.includes('Extension context')) {
        
        if (isLastAttempt) {
          return { 
            success: false, 
            error: 'Extension connection lost. Please refresh the page to reconnect.' 
          };
        }
        
        // Wait longer for Chrome to respawn the service worker
        await new Promise(resolve => setTimeout(resolve, 800));
        continue;
      }

      // Handle other errors
      if (isLastAttempt) {
        return { success: false, error: error.message };
      }
      
      await new Promise(resolve => setTimeout(resolve, 500));
    }
  }
  
  return { 
    success: false, 
    error: 'Extension not responding after multiple attempts. Please refresh the page.' 
  };
}

// ============================================================================
// LISTEN FOR MESSAGES FROM EXTENSION BACKGROUND
// ============================================================================

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'extensionEvent') {
    console.log('📨 Extension event:', request.event, request.data);
    
    window.postMessage({
      type: 'EXTENSION_EVENT',
      event: request.event,
      data: request.data
    }, '*');
    
    sendResponse({ success: true, received: true });
  }
  
  return true;
});

// ============================================================================
// LISTEN FOR MESSAGES FROM WEBPAGE
// ============================================================================

window.addEventListener('message', async (event) => {
  if (event.source !== window) return;

  const message = event.data;

  // ========== CONNECTION ==========
  if (message.type === 'CONNECT_EXTENSION') {
    console.log('🔌 Connecting to extension...');
    
    // Wake up the extension
    await safeSendMessage({ action: 'wakeUp' });
    
    // Get extension ID
    const result = await safeSendMessage({ action: 'getExtensionId' });
    
    if (result.success) {
      window.postMessage({
        type: 'EXTENSION_CONNECTED',
        extensionId: result.data.extensionId
      }, '*');
      
      await safeSendMessage({ action: 'setConnected' });
      console.log('✅ Extension connected successfully');
    } else {
      window.postMessage({
        type: 'EXTENSION_CONNECTED',
        extensionId: null,
        error: result.error
      }, '*');
      console.error('❌ Extension connection failed:', result.error);
    }
  }

  if (message.type === 'DISCONNECT_EXTENSION') {
    await safeSendMessage({ action: 'setDisconnected' });
    window.postMessage({
      type: 'EXTENSION_DISCONNECTED',
      reason: 'manual'
    }, '*');
  }

  if (message.type === 'CHECK_EXTENSION') {
    const result = await safeSendMessage({ action: 'getStatus' });
    
    if (result.success) {
      window.postMessage({
        type: 'EXTENSION_STATUS',
        connected: result.data.connected,
        extensionId: result.data.extensionId
      }, '*');
    } else {
      window.postMessage({
        type: 'EXTENSION_STATUS',
        connected: false,
        extensionId: null,
        error: result.error
      }, '*');
    }
  }

  // ========== SCHEDULE POSTS ==========
  if (message.type === 'SCHEDULE_POSTS') {
    console.log('📥 Webapp received SCHEDULE_POSTS:', message.posts?.length || 0, 'posts');
    
    const result = await safeSendMessage({
      action: 'schedulePosts',
      posts: message.posts
    });

    if (result.success) {
      window.postMessage({
        type: 'SCHEDULE_RESULT',
        success: true,
        queueLength: result.data.queueLength,
        nextScheduled: result.data.nextScheduled,
        message: result.data.message
      }, '*');
      console.log('✅ Posts scheduled successfully');
    } else {
      window.postMessage({
        type: 'SCHEDULE_RESULT',
        success: false,
        error: result.error
      }, '*');
      console.error('❌ Schedule failed:', result.error);
    }
  }

  // ========== POST NOW ==========
  if (message.type === 'POST_NOW') {
    console.log('📤 Webapp received POST_NOW:', message.post?.id);
    
    const result = await safeSendMessage({
      action: 'postNow',
      post: message.post
    });

    if (result.success) {
      window.postMessage({
        type: 'POST_RESULT',
        success: true,
        postId: message.post.id,
        linkedinPostId: result.data.linkedinPostId,
        linkedinUrl: result.data.linkedinUrl
      }, '*');
      console.log('✅ Post published successfully');
    } else {
      window.postMessage({
        type: 'POST_RESULT',
        success: false,
        postId: message.post.id,
        error: result.error
      }, '*');
      console.error('❌ Post failed:', result.error);
    }
  }

  // ========== ANALYTICS ==========
  if (message.type === 'SCRAPE_ANALYTICS') {
    console.log('📊 Scraping analytics...');
    
    const result = await safeSendMessage({ action: 'scrapeAnalytics' });
    
    window.postMessage({
      type: 'ANALYTICS_RESULT',
      success: result.success,
      data: result.success ? result.data.data : null,
      error: result.success ? null : result.error
    }, '*');
  }

  // ========== POST SCANNING ==========
  if (message.type === 'SCAN_POSTS') {
    console.log('🔍 Scanning user posts...');
    
    const result = await safeSendMessage({
      action: 'scanUserPosts',
      limit: message.limit || 50
    });

    window.postMessage({
      type: 'SCAN_RESULT',
      success: result.success,
      data: result.success ? result.data.data : { posts: [], writingStyle: {} },
      error: result.success ? null : result.error
    }, '*');
  }

  // ========== PROFILE URL ==========
  if (message.type === 'SAVE_PROFILE_URL') {
    console.log('💾 Saving profile URL...');
    
    const result = await safeSendMessage({
      action: 'saveProfileUrl',
      url: message.url
    });

    window.postMessage({
      type: 'PROFILE_URL_SAVED',
      success: result.success,
      url: result.success ? result.data.url : null,
      error: result.success ? null : result.error
    }, '*');
  }
});

// ============================================================================
// AUTO-CHECK EXTENSION ON LOAD
// ============================================================================

window.addEventListener('load', () => {
  setTimeout(async () => {
    console.log('🔍 Auto-checking extension status...');
    
    // Wake up the extension first
    await safeSendMessage({ action: 'wakeUp' });
    
    // Then check status
    window.postMessage({ type: 'CHECK_EXTENSION' }, '*');
  }, 1000);
});

console.log('✅ Webapp content script ready (PRODUCTION FIXED VERSION)');