// ============================================================================
// LINKEDBOT BRIDGE SCRIPT - WITH SCHEDULING
// ============================================================================

(function() {
  console.log('🌉 LinkedBot bridge injected');
  
  window.LinkedBotExtension = {
    isInstalled: true,
    isConnected: false,
    extensionId: null,
    
    // CONNECTION
    connect: function() {
      return new Promise((resolve) => {
        window.postMessage({ type: 'CONNECT_EXTENSION' }, '*');
        
        const handler = (event) => {
          if (event.data.type === 'EXTENSION_CONNECTED') {
            this.isConnected = true;
            this.extensionId = event.data.extensionId;
            window.removeEventListener('message', handler);
            resolve({ success: true, extensionId: event.data.extensionId });
          }
        };
        
        window.addEventListener('message', handler);
        setTimeout(() => {
          window.removeEventListener('message', handler);
          resolve({ success: false, error: 'Connection timeout' });
        }, 5000);
      });
    },
    
    disconnect: function() {
      return new Promise((resolve) => {
        window.postMessage({ type: 'DISCONNECT_EXTENSION' }, '*');
        
        const handler = (event) => {
          if (event.data.type === 'EXTENSION_DISCONNECTED') {
            this.isConnected = false;
            this.extensionId = null;
            window.removeEventListener('message', handler);
            resolve({ success: true });
          }
        };
        
        window.addEventListener('message', handler);
        setTimeout(() => {
          window.removeEventListener('message', handler);
          resolve({ success: true });
        }, 2000);
      });
    },
    
    checkStatus: function() {
      return new Promise((resolve) => {
        window.postMessage({ type: 'CHECK_EXTENSION' }, '*');
        
        const handler = (event) => {
          if (event.data.type === 'EXTENSION_STATUS') {
            this.isConnected = event.data.connected;
            this.extensionId = event.data.extensionId;
            window.removeEventListener('message', handler);
            resolve({
              connected: event.data.connected,
              extensionId: event.data.extensionId
            });
          }
        };
        
        window.addEventListener('message', handler);
        setTimeout(() => {
          window.removeEventListener('message', handler);
          resolve({ connected: false });
        }, 2000);
      });
    },
    
    // 🔥 SCHEDULE POSTS (NEW - Main method for scheduling)
    schedulePosts: function(posts) {
      return new Promise((resolve) => {
        console.log(`📥 Scheduling ${posts.length} posts...`);
        
        window.postMessage({
          type: 'SCHEDULE_POSTS',
          posts: posts
        }, '*');
        
        const handler = (event) => {
          if (event.data.type === 'SCHEDULE_RESULT') {
            window.removeEventListener('message', handler);
            console.log('✅ Schedule result:', event.data);
            resolve({
              success: event.data.success,
              queueLength: event.data.queueLength,
              nextScheduled: event.data.nextScheduled,
              error: event.data.error
            });
          }
        };
        
        window.addEventListener('message', handler);
        
        setTimeout(() => {
          window.removeEventListener('message', handler);
          resolve({ success: false, error: 'Scheduling timeout (10s)' });
        }, 10000);
      });
    },
    
    // POST NOW (Immediate posting)
    postNow: function(post) {
      return new Promise((resolve) => {
        window.postMessage({
          type: 'POST_NOW',
          post: post
        }, '*');
        
        const handler = (event) => {
          if (event.data.type === 'POST_RESULT' && event.data.postId === post.id) {
            window.removeEventListener('message', handler);
            resolve(event.data);
          }
        };
        
        window.addEventListener('message', handler);
        setTimeout(() => {
          window.removeEventListener('message', handler);
          resolve({ success: false, error: 'Posting timeout' });
        }, 30000);
      });
    },
    
    // ANALYTICS
    scrapeAnalytics: function() {
      return new Promise((resolve) => {
        console.log('📊 Requesting analytics...');
        
        window.postMessage({ type: 'SCRAPE_ANALYTICS' }, '*');
        
        const handler = (event) => {
          if (event.data.type === 'ANALYTICS_RESULT') {
            window.removeEventListener('message', handler);
            resolve({
              success: event.data.success,
              data: event.data.data,
              error: event.data.error
            });
          }
        };
        
        window.addEventListener('message', handler);
        
        setTimeout(() => {
          window.removeEventListener('message', handler);
          resolve({ success: false, error: 'Analytics timeout (60s)' });
        }, 60000);
      });
    },
    
    // POST SCANNING
    scanPosts: function(limit = 50) {
      return new Promise((resolve) => {
        console.log(`📚 Requesting post scan (limit: ${limit})...`);
        
        window.postMessage({ 
          type: 'SCAN_POSTS',
          limit: limit 
        }, '*');
        
        const handler = (event) => {
          if (event.data.type === 'SCAN_RESULT') {
            window.removeEventListener('message', handler);
            resolve({
              success: event.data.success,
              data: event.data.data,
              error: event.data.error
            });
          }
        };
        
        window.addEventListener('message', handler);
        
        setTimeout(() => {
          window.removeEventListener('message', handler);
          resolve({ success: false, error: 'Post scan timeout (90s)' });
        }, 90000);
      });
    },
    
    // PROFILE URL
    saveProfileUrl: function(url) {
      return new Promise((resolve) => {
        window.postMessage({
          type: 'SAVE_PROFILE_URL',
          url: url
        }, '*');
        
        const handler = (event) => {
          if (event.data.type === 'PROFILE_URL_SAVED') {
            window.removeEventListener('message', handler);
            resolve({
              success: event.data.success,
              url: event.data.url,
              error: event.data.error
            });
          }
        };
        
        window.addEventListener('message', handler);
        
        setTimeout(() => {
          window.removeEventListener('message', handler);
          resolve({ success: false, error: 'Save timeout' });
        }, 5000);
      });
    },
    
    // EVENT LISTENERS
    onEvent: function(callback) {
      window.addEventListener('message', (event) => {
        if (event.data.type === 'EXTENSION_EVENT') {
          callback(event.data.event, event.data.data);
        }
      });
    },
    
    onPostHistoryScanned: function(callback) {
      window.addEventListener('message', (event) => {
        if (event.data.type === 'EXTENSION_EVENT' && 
            event.data.event === 'postHistoryScanned') {
          callback(event.data.data);
        }
      });
    },
    
    onPostPublished: function(callback) {
      window.addEventListener('message', (event) => {
        if (event.data.type === 'EXTENSION_EVENT' && 
            event.data.event === 'postPublished') {
          callback(event.data.data);
        }
      });
    }
  };
  
  // Notify page that bridge is ready
  window.dispatchEvent(new CustomEvent('linkedbot-extension-ready'));
  
  // Auto-check status
  setTimeout(() => {
    window.LinkedBotExtension.checkStatus();
  }, 500);
})();

console.log('✅ LinkedBot bridge ready');